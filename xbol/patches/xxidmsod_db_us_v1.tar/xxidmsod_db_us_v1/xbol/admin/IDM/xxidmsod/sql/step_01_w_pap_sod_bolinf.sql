SPOOL step_01_w_pap_sod_bolinf.log

PROMPT =====================================================================
PROMPT Script step_01_w_pap_sod_bolinf.sql
PROMPT =====================================================================

-- ===================================================================
--
-- EN BOLINF
--
-- ===================================================================
prompt Creando bolinf.xx_sod_applications

CREATE TABLE bolinf.xx_sod_applications
(appl_id             NUMBER(15)   NOT NULL
,appl_name           VARCHAR2(30) NOT NULL
,appl_description    VARCHAR2(80)
,owner_person_id     NUMBER(15)
,enabled_flag        VARCHAR2(1)  NOT NULL
,creation_date       DATE         NOT NULL
,created_by          NUMBER(15)   NOT NULL
,last_update_date    DATE         NOT NULL
,last_updated_by     NUMBER(15)   NOT NULL
)
/

prompt Creando bolinf.xx_sod_roles

CREATE TABLE bolinf.xx_sod_roles
(appl_id             NUMBER(15)    NOT NULL
,role_id             NUMBER(15)    NOT NULL
,role_name           VARCHAR2(240) NOT NULL
,role_description    VARCHAR2(240)
,original_role_id    NUMBER(15)
,approval_type       VARCHAR2(1)   NOT NULL --> (A)utomatic Approval;(W)orkflow Approval; (R)eject
,approver_id         NUMBER(15)
,enabled_flag        VARCHAR2(1)   NOT NULL
,creation_date       DATE          NOT NULL
,created_by          NUMBER(15)    NOT NULL
,last_update_date    DATE          NOT NULL
,last_updated_by     NUMBER(15)    NOT NULL
)
/

prompt Creando bolinf.xx_sod_approvers

CREATE TABLE bolinf.xx_sod_approvers
(approver_id         NUMBER(15)   NOT NULL
,person_id           NUMBER(15)   NOT NULL
,backup_person_id    NUMBER(15)   NOT NULL
,backup_from_date    DATE
,backup_to_date      DATE
,second_person_id    NUMBER(15)
,enabled_flag        VARCHAR2(1)  NOT NULL
,creation_date       DATE         NOT NULL
,created_by          NUMBER(15)   NOT NULL
,last_update_date    DATE         NOT NULL
,last_updated_by          NUMBER(15)   NOT NULL
)
/

prompt Creando bolinf.xx_sod_matrix

CREATE TABLE bolinf.xx_sod_matrix
(sod_id             NUMBER(15)  NOT NULL
,appl_id            NUMBER(15)  NOT NULL
,role_id            NUMBER(15)  NOT NULL
,incomp_appl_id     NUMBER(15)  NOT NULL
,incomp_role_id     NUMBER(15)  NOT NULL
,enabled_flag       VARCHAR2(1) NOT NULL
,creation_date      DATE        NOT NULL
,created_by         NUMBER(15)  NOT NULL
,last_update_date   DATE        NOT NULL
,last_updated_by    NUMBER(15)  NOT NULL 
)
/

prompt Asignando permisos bolinf.xx_sod_applications a apps

GRANT ALL ON bolinf.xx_sod_applications TO apps
/

prompt Asignando permisos bolinf.xx_sod_roles a apps

GRANT ALL ON bolinf.xx_sod_roles TO apps
/

prompt Asignando permisos bolinf.xx_sod_approvers a apps

GRANT ALL ON bolinf.xx_sod_approvers TO apps
/

prompt Asignando permisos xx_sod_matrix a apps

GRANT ALL ON xx_sod_matrix TO apps
/

SHOW ERRORS

SPOOL OFF

EXIT
