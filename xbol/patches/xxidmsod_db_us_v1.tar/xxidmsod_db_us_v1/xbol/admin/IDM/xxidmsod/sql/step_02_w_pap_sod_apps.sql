SPOOL step_02_w_pap_sod_apps.log

PROMPT =====================================================================
PROMPT Script step_02_w_pap_sod_apps.sql
PROMPT =====================================================================

-- ===================================================================
--
-- EN APPS
--
-- ===================================================================
CREATE SYNONYM XX_SOD_APPLICATIONS FOR BOLINF.XX_SOD_APPLICATIONS
/

CREATE SYNONYM XX_SOD_ROLES FOR BOLINF.XX_SOD_ROLES
/

CREATE SYNONYM XX_SOD_APPROVERS FOR BOLINF.XX_SOD_APPROVERS
/

CREATE SYNONYM XX_SOD_MATRIX FOR BOLINF.XX_SOD_MATRIX
/

CREATE OR REPLACE VIEW xx_sod_approvers_v
AS
SELECT ap.approver_id
      ,pa.full_name     approver_name
      ,pa.email_address approver_email
      ,pb.full_name     backup_approver_name
      ,pb.email_address backup_email
      ,ap.backup_from_date
      ,ap.backup_to_date
      ,ap.second_person_id
      ,ap.enabled_flag
      ,(SELECT COUNT(1) FROM xx_sod_roles r WHERE r.approver_id = ap.approver_id) k_roles
      ,ap.person_id, ap.backup_person_id
      ,ap.creation_date, ap.created_by, ap.last_update_date, ap.last_updated_by 
  FROM per_people_v7    pa
      ,per_people_v7    pb
      ,xx_sod_approvers ap 
 WHERE pa.person_id = ap.person_id 
   AND pb.person_id(+) = ap.backup_person_id
   AND ap.enabled_flag = 'Y'
/

SHOW ERRORS

SPOOL OFF

EXIT
