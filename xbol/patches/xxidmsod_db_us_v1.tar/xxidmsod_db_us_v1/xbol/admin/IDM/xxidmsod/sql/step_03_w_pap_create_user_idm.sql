SPOOL step_03_w_pap_create_user_idm.log

PROMPT =====================================================================
PROMPT Script step_03_w_pap_create_user_idm.sql
PROMPT =====================================================================

BEGIN
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "APPS"';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_LANGUAGE = ''AMERICAN''';
    fnd_global.apps_initialize(4872,50955,1);
  END;
  DBMS_OUTPUT.PUT_LINE('+ Creando usuario IDM');
  fnd_user_pkg.CreateUser ( x_user_name              => 'IDM'
                           ,x_owner                  => NULL
                           ,x_unencrypted_password   => 'despegar123'
                           ,x_start_date             => SYSDATE
                           ,x_end_date               => NULL
                           ,x_description            => 'Usuario para el IdM'
                           ,x_password_lifespan_days => NULL
                           ,x_employee_id            => NULL
                           ,x_email_address          => NULL );
  DBMS_OUTPUT.PUT_LINE('- Creando usuario IDM');                           
EXCEPTION
  WHEN OTHERS THEN
       RAISE_APPLICATION_ERROR(-20001,'ERROR al generar el Usuario IdM; '||SQLERRM);
END;
/

SHOW ERRORS

SPOOL OFF

EXIT
