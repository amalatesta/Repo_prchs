SPOOL step_04_w_adecuacion_tabla_xx_adi.log

PROMPT =====================================================================
PROMPT Script step_04_w_adecuacion_tabla_xx_adi.sql
PROMPT =====================================================================

-- ---------------------------------------------------------
-- Adecuaci�n de la tabla XX_ADI al nuevo proceso.
-- ---------------------------------------------------------
BEGIN
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi MODIFY (full_name VARCHAR2(240))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi MODIFY (depto VARCHAR2(240))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (last_name VARCHAR2(150))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (first_name VARCHAR2(150))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (superv_email VARCHAR2(80))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (user_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (assignment_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (worker_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (operation VARCHAR2(1))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (operation_user VARCHAR2(1))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (status_user VARCHAR2(7))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (email_address VARCHAR2(240))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (country VARCHAR2(30))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (depto_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (puesto_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (superv_worker_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (job_family_id NUMBER(15))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (job_family VARCHAR2(80))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (pci_flag VARCHAR2(1))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (location VARCHAR2(80))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (user_type VARCHAR2(1))';
  EXECUTE IMMEDIATE 'ALTER TABLE bolinf.xx_adi ADD (entidad_legal VARCHAR2(70))';
END;
/

SHOW ERRORS

SPOOL OFF

EXIT
