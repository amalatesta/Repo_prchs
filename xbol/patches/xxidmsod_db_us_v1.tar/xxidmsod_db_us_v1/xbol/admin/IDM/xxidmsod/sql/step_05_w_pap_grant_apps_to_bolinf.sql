SPOOL step_05_w_pap_grant_apps_to_bolinf.log

PROMPT =====================================================================
PROMPT Script step_05_w_pap_grant_apps_to_bolinf.sql
PROMPT =====================================================================

-- ===================================================================
--
-- EN APPS
--
-- ===================================================================
prompt Asignando permisos XX_IDM_PKG a bolinf

GRANT EXECUTE ON XX_IDM_PKG TO BOLINF
/

SHOW ERRORS

SPOOL OFF

EXIT
