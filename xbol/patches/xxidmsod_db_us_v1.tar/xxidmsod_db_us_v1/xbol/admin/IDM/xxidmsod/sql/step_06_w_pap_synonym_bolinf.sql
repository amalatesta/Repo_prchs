SPOOL step_06_w_pap_synonym_bolinf.log

PROMPT =====================================================================
PROMPT Script step_06_w_pap_synonym_bolinf.sql
PROMPT =====================================================================

-- ===================================================================
--
-- EN BOLINF
--
-- ===================================================================
prompt Creando sinonimos para XX_IDM_PKG en bolinf

CREATE PUBLIC SYNONYM XX_IDM_PKG FOR APPS.XX_IDM_PKG
/

SHOW ERRORS

SPOOL OFF

EXIT
