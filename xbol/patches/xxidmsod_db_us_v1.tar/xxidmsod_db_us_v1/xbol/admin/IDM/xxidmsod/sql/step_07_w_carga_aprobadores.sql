SPOOL step_07_w_carga_aprobadores.log

PROMPT =====================================================================
PROMPT Script step_07_w_carga_aprobadores.sql
PROMPT =====================================================================

--******************************************************************************\
-- Purpose: Cargar responsabilidades y sus aprobadores en XX_SOD_ROLES.
-- Notes  : USA ARRAYS NO CORRELATIVOS
--          HABILITAR EL DBMS_OUTPUT
-- Date   : 02/07/2018
--******************************************************************************/
DECLARE
  i                      INTEGER;
  l_k                    NUMBER := 0;
  l_id                   NUMBER(15);
  l_existe               NUMBER;
  l_person_id            NUMBER;
  l_backup_id            NUMBER;
  l_approver_id          NUMBER;
  l_resp_name            fnd_responsibility_tl.responsibility_name%TYPE;
  l_resp_description     fnd_responsibility_tl.description%TYPE;
  l_resp_id              fnd_responsibility_tl.responsibility_id%TYPE;  
  --
  TYPE r_tab IS RECORD ( resp_name      VARCHAR2(240)
                        ,approver_name  VARCHAR2(240)
                        ,backup_mail    VARCHAR2(240)
                        ,wf_type        VARCHAR2(1) );
  TYPE b_tab IS TABLE OF r_tab INDEX BY BINARY_INTEGER;  
  t_tab                  b_tab;  --> array de respos.
  --
-- ==========================================================================
--
-- PROCEDIMIENTO PRINCIPAL 
--
-- ==========================================================================
BEGIN
  DBMS_OUTPUT.ENABLE(1000000);
  DBMS_OUTPUT.PUT_LINE('*** INICIO ***');
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "APPS"';
--    apps.mo_global.set_policy_context('S', 101);
  EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_LANGUAGE = ''AMERICAN''';
    apps.fnd_global.apps_initialize(4872,50955,1); -- DANIEL.VARTABEDIAN/DSP Administrador de Personal
  END;  
  --
  DBMS_OUTPUT.PUT_LINE('+ Carga tabla');
t_tab(1).resp_name := 'Administraci�n de Sistema'; t_tab(1).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(1).backup_mail := ''; t_tab(1).wf_type := 'W';
t_tab(2).resp_name := 'Administraci�n HTML CRM'; t_tab(2).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(2).backup_mail := ''; t_tab(2).wf_type := 'W';
t_tab(3).resp_name := 'Administrador de Approvals MANAGEMENT'; t_tab(3).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(3).backup_mail := ''; t_tab(3).wf_type := 'W';
t_tab(4).resp_name := 'Administrador de Configuraci�n de Pagos'; t_tab(4).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(4).backup_mail := ''; t_tab(4).wf_type := 'W';
t_tab(5).resp_name := 'Administrador de Entidad Legal'; t_tab(5).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(5).backup_mail := ''; t_tab(5).wf_type := 'W';
t_tab(6).resp_name := 'Administrador de Entidad Legal(1)'; t_tab(6).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(6).backup_mail := ''; t_tab(6).wf_type := 'W';
t_tab(7).resp_name := 'Administrador de HRMS de EEUU'; t_tab(7).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(7).backup_mail := ''; t_tab(7).wf_type := 'W';
t_tab(8).resp_name := 'Administrador de Impuestos'; t_tab(8).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(8).backup_mail := ''; t_tab(8).wf_type := 'W';
t_tab(9).resp_name := 'Administrador de Oracle Sales'; t_tab(9).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(9).backup_mail := ''; t_tab(9).wf_type := 'W';
t_tab(10).resp_name := 'Administrador de Oracle Trade MANAGEMENT'; t_tab(10).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(10).backup_mail := ''; t_tab(10).wf_type := 'W';
t_tab(11).resp_name := 'Administrador de Sistema'; t_tab(11).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(11).backup_mail := ''; t_tab(11).wf_type := 'W';
t_tab(12).resp_name := 'Administrador de Trading Community'; t_tab(12).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(12).backup_mail := ''; t_tab(12).wf_type := 'W';
t_tab(13).resp_name := 'Administrador de Workflow'; t_tab(13).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(13).backup_mail := ''; t_tab(13).wf_type := 'W';
t_tab(14).resp_name := 'Administrador de XML Publisher'; t_tab(14).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(14).backup_mail := ''; t_tab(14).wf_type := 'W';
t_tab(15).resp_name := 'Administrador Funcional'; t_tab(15).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(15).backup_mail := ''; t_tab(15).wf_type := 'W';
t_tab(16).resp_name := 'Administrador US HR'; t_tab(16).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(16).backup_mail := ''; t_tab(16).wf_type := 'W';
t_tab(17).resp_name := 'Alert Manager'; t_tab(17).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(17).backup_mail := ''; t_tab(17).wf_type := 'W';
t_tab(18).resp_name := 'Analista de Negocios de Approvals MANAGEMENT'; t_tab(18).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(18).backup_mail := ''; t_tab(18).wf_type := 'W';
t_tab(19).resp_name := 'Art�culo Inventario'; t_tab(19).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(19).backup_mail := ''; t_tab(19).wf_type := 'W';
t_tab(20).resp_name := 'Configuraci�n de Cash MANAGEMENT'; t_tab(20).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(20).backup_mail := ''; t_tab(20).wf_type := 'W';
t_tab(21).resp_name := 'Configuraci�n y Administraci�n de Internet Expenses'; t_tab(21).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(21).backup_mail := ''; t_tab(21).wf_type := 'W';
t_tab(22).resp_name := 'Consulta de Payables'; t_tab(22).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(22).backup_mail := ''; t_tab(22).wf_type := 'W';
t_tab(23).resp_name := 'Consulta de Payables de Sector P�blico'; t_tab(23).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(23).backup_mail := ''; t_tab(23).wf_type := 'W';
t_tab(24).resp_name := 'Consulta de PROJECT Manufacturing'; t_tab(24).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(24).backup_mail := ''; t_tab(24).wf_type := 'W';
t_tab(25).resp_name := 'Consulta de Quality'; t_tab(25).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(25).backup_mail := ''; t_tab(25).wf_type := 'W';
t_tab(26).resp_name := 'COST MANAGEMENT - SLA'; t_tab(26).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(26).backup_mail := ''; t_tab(26).wf_type := 'W';
t_tab(27).resp_name := 'Desarrollador de Aplicaciones'; t_tab(27).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(27).backup_mail := ''; t_tab(27).wf_type := 'W';
t_tab(28).resp_name := 'Desarrollador Funcional'; t_tab(28).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(28).backup_mail := ''; t_tab(28).wf_type := 'W';
t_tab(29).resp_name := 'Desktop Integrator'; t_tab(29).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(29).backup_mail := ''; t_tab(29).wf_type := 'W';
t_tab(30).resp_name := 'DESTINOS AR GL CONSULTAS CORP'; t_tab(30).approver_name := ''; t_tab(30).backup_mail := ''; t_tab(30).wf_type := '1';
t_tab(31).resp_name := 'DESTINOS AR GL CONSULTAS USGAAP'; t_tab(31).approver_name := ''; t_tab(31).backup_mail := ''; t_tab(31).wf_type := '1';
t_tab(32).resp_name := 'DESTINOS AR GL REPORTES CORP'; t_tab(32).approver_name := ''; t_tab(32).backup_mail := ''; t_tab(32).wf_type := '1';
t_tab(33).resp_name := 'DESTINOS AR GL REPORTES USGAAP'; t_tab(33).approver_name := ''; t_tab(33).backup_mail := ''; t_tab(33).wf_type := '1';
t_tab(34).resp_name := 'Developer HTML CRM'; t_tab(34).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(34).backup_mail := ''; t_tab(34).wf_type := 'W';
t_tab(35).resp_name := 'Diagn�stico de Aplicaci�n'; t_tab(35).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(35).backup_mail := ''; t_tab(35).wf_type := 'W';
t_tab(36).resp_name := 'DSP ADM RESPONSABILIDADES'; t_tab(36).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(36).backup_mail := ''; t_tab(36).wf_type := 'W';
t_tab(37).resp_name := 'DSP ADMIN MAESTRO ARTICULOS'; t_tab(37).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(37).backup_mail := ''; t_tab(37).wf_type := 'W';
t_tab(38).resp_name := 'DSP Administrador de Personal'; t_tab(38).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(38).backup_mail := ''; t_tab(38).wf_type := 'W';
t_tab(39).resp_name := 'DSP ADMNISTRADOR ITEMS'; t_tab(39).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(39).backup_mail := ''; t_tab(39).wf_type := 'W';
t_tab(40).resp_name := 'DSP AR AP ABM BANCOS y CTAS BANCARIAS'; t_tab(40).approver_name := 'roman.richter@despegar.com'; t_tab(40).backup_mail := ''; t_tab(40).wf_type := 'W';
t_tab(41).resp_name := 'DSP AR AP ABM PROVEEDORES'; t_tab(41).approver_name := 'gbeloqui@despegar.com'; t_tab(41).backup_mail := ''; t_tab(41).wf_type := 'W';
t_tab(42).resp_name := 'DSP AR AP ANALISTA JR'; t_tab(42).approver_name := 'edeluca@despegar.com'; t_tab(42).backup_mail := ''; t_tab(42).wf_type := 'W';
t_tab(43).resp_name := 'DSP AR AP ANALISTA SR'; t_tab(43).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(43).backup_mail := 'florencia.hansen@despegar.com'; t_tab(43).wf_type := 'W';
t_tab(44).resp_name := 'DSP AR AP APROBADOR FC AME'; t_tab(44).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(44).backup_mail := 'florencia.hansen@despegar.com'; t_tab(44).wf_type := 'W';
t_tab(45).resp_name := 'DSP AR AP CONFIGURADOR'; t_tab(45).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(45).backup_mail := ''; t_tab(45).wf_type := 'W';
t_tab(46).resp_name := 'DSP AR AP CONSULTAS'; t_tab(46).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(46).backup_mail := 'florencia.hansen@despegar.com'; t_tab(46).wf_type := 'W';
t_tab(47).resp_name := 'DSP AR AP GERENTE'; t_tab(47).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(47).backup_mail := 'florencia.hansen@despegar.com'; t_tab(47).wf_type := 'W';
t_tab(48).resp_name := 'DSP AR AP SUPER USER'; t_tab(48).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(48).backup_mail := ''; t_tab(48).wf_type := 'W';
t_tab(49).resp_name := 'DSP AR AR ABM CLIENTES'; t_tab(49).approver_name := 'gbeloqui@despegar.com'; t_tab(49).backup_mail := ''; t_tab(49).wf_type := 'W';
t_tab(50).resp_name := 'DSP AR AR ANALISTA COBR'; t_tab(50).approver_name := 'edeluca@despegar.com'; t_tab(50).backup_mail := ''; t_tab(50).wf_type := 'W';
t_tab(51).resp_name := 'DSP AR AR ANALISTA COBR INTERCO'; t_tab(51).approver_name := 'edeluca@despegar.com'; t_tab(51).backup_mail := ''; t_tab(51).wf_type := 'W';
t_tab(52).resp_name := 'DSP AR AR ANALISTA FACT'; t_tab(52).approver_name := 'edeluca@despegar.com'; t_tab(52).backup_mail := ''; t_tab(52).wf_type := 'W';
t_tab(53).resp_name := 'DSP AR AR ANALISTA FACT INTERCO'; t_tab(53).approver_name := 'edeluca@despegar.com'; t_tab(53).backup_mail := ''; t_tab(53).wf_type := 'W';
t_tab(54).resp_name := 'DSP AR AR CONFIGURADOR'; t_tab(54).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(54).backup_mail := ''; t_tab(54).wf_type := 'W';
t_tab(55).resp_name := 'DSP AR AR CONSULTA'; t_tab(55).approver_name := 'edeluca@despegar.com'; t_tab(55).backup_mail := ''; t_tab(55).wf_type := 'W';
t_tab(56).resp_name := 'DSP AR AR SUPER USER'; t_tab(56).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(56).backup_mail := ''; t_tab(56).wf_type := 'W';
t_tab(57).resp_name := 'DSP AR AR SUPERV COBR'; t_tab(57).approver_name := 'edeluca@despegar.com'; t_tab(57).backup_mail := ''; t_tab(57).wf_type := 'W';
t_tab(58).resp_name := 'DSP AR AR SUPERV FACT'; t_tab(58).approver_name := 'edeluca@despegar.com'; t_tab(58).backup_mail := ''; t_tab(58).wf_type := 'W';
t_tab(59).resp_name := 'DSP AR CE CONCILIACIONES'; t_tab(59).approver_name := 'roman.richter@despegar.com'; t_tab(59).backup_mail := ''; t_tab(59).wf_type := 'W';
t_tab(60).resp_name := 'DSP AR CE CONFIGURADOR'; t_tab(60).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(60).backup_mail := ''; t_tab(60).wf_type := 'W';
t_tab(61).resp_name := 'DSP AR CE CONSULTAS'; t_tab(61).approver_name := 'roman.richter@despegar.com'; t_tab(61).backup_mail := ''; t_tab(61).wf_type := 'W';
t_tab(62).resp_name := 'DSP AR CE SUPER USER'; t_tab(62).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(62).backup_mail := ''; t_tab(62).wf_type := 'W';
t_tab(63).resp_name := 'DSP AR CE TESORERIA'; t_tab(63).approver_name := 'roman.richter@despegar.com'; t_tab(63).backup_mail := ''; t_tab(63).wf_type := 'W';
t_tab(64).resp_name := 'DSP AR CONC AMEX LOC ANA'; t_tab(64).approver_name := 'gbeloqui@despegar.com'; t_tab(64).backup_mail := ''; t_tab(64).wf_type := 'W';
t_tab(65).resp_name := 'DSP AR CONC AMEX LOC CONSULTA'; t_tab(65).approver_name := 'gbeloqui@despegar.com'; t_tab(65).backup_mail := ''; t_tab(65).wf_type := 'W';
t_tab(66).resp_name := 'DSP AR CONC AMEX LOC SUPERVISOR'; t_tab(66).approver_name := 'gbeloqui@despegar.com'; t_tab(66).backup_mail := ''; t_tab(66).wf_type := 'W';
t_tab(67).resp_name := 'DSP AR CONC CABAL LOC ANA'; t_tab(67).approver_name := 'gbeloqui@despegar.com'; t_tab(67).backup_mail := ''; t_tab(67).wf_type := 'W';
t_tab(68).resp_name := 'DSP AR CONC CABAL LOC CONSULTA'; t_tab(68).approver_name := 'gbeloqui@despegar.com'; t_tab(68).backup_mail := ''; t_tab(68).wf_type := 'W';
t_tab(69).resp_name := 'DSP AR CONC CABAL SUPERVISOR'; t_tab(69).approver_name := 'gbeloqui@despegar.com'; t_tab(69).backup_mail := ''; t_tab(69).wf_type := 'W';
t_tab(70).resp_name := 'DSP AR CONC FDATA LOC ANA'; t_tab(70).approver_name := 'gbeloqui@despegar.com'; t_tab(70).backup_mail := ''; t_tab(70).wf_type := 'W';
t_tab(71).resp_name := 'DSP AR CONC FDATA LOC CONSULTA'; t_tab(71).approver_name := 'gbeloqui@despegar.com'; t_tab(71).backup_mail := ''; t_tab(71).wf_type := 'W';
t_tab(72).resp_name := 'DSP AR CONC FDATA LOC SUPERVISOR'; t_tab(72).approver_name := 'gbeloqui@despegar.com'; t_tab(72).backup_mail := ''; t_tab(72).wf_type := 'W';
t_tab(73).resp_name := 'DSP AR CONC MERCADO PAGO SUPERVISOR'; t_tab(73).approver_name := 'gbeloqui@despegar.com'; t_tab(73).backup_mail := ''; t_tab(73).wf_type := 'W';
t_tab(74).resp_name := 'DSP AR CONC NARANJA ANALISTA'; t_tab(74).approver_name := 'gbeloqui@despegar.com'; t_tab(74).backup_mail := ''; t_tab(74).wf_type := 'W';
t_tab(75).resp_name := 'DSP AR CONC NARANJA CONSULTA'; t_tab(75).approver_name := 'gbeloqui@despegar.com'; t_tab(75).backup_mail := ''; t_tab(75).wf_type := 'W';
t_tab(76).resp_name := 'DSP AR CONC NARANJA SUPERVISOR'; t_tab(76).approver_name := 'gbeloqui@despegar.com'; t_tab(76).backup_mail := ''; t_tab(76).wf_type := 'W';
t_tab(77).resp_name := 'DSP AR CONC NEVADA CONSULTA'; t_tab(77).approver_name := 'gbeloqui@despegar.com'; t_tab(77).backup_mail := ''; t_tab(77).wf_type := 'W';
t_tab(78).resp_name := 'DSP AR CONC NEVADA SUPERVISOR'; t_tab(78).approver_name := 'gbeloqui@despegar.com'; t_tab(78).backup_mail := ''; t_tab(78).wf_type := 'W';
t_tab(79).resp_name := 'DSP AR CONC PAYU SUPERVISOR'; t_tab(79).approver_name := 'gbeloqui@despegar.com'; t_tab(79).backup_mail := ''; t_tab(79).wf_type := 'W';
t_tab(80).resp_name := 'DSP AR CONC SHOPPING ANALISTA'; t_tab(80).approver_name := 'gbeloqui@despegar.com'; t_tab(80).backup_mail := ''; t_tab(80).wf_type := 'W';
t_tab(81).resp_name := 'DSP AR CONC SHOPPING CONSULTA'; t_tab(81).approver_name := 'gbeloqui@despegar.com'; t_tab(81).backup_mail := ''; t_tab(81).wf_type := 'W';
t_tab(82).resp_name := 'DSP AR CONC SHOPPING SUPERVISOR'; t_tab(82).approver_name := 'gbeloqui@despegar.com'; t_tab(82).backup_mail := ''; t_tab(82).wf_type := 'W';
t_tab(83).resp_name := 'DSP AR CONC TODO PAGO SUPERVISOR'; t_tab(83).approver_name := 'gbeloqui@despegar.com'; t_tab(83).backup_mail := ''; t_tab(83).wf_type := 'W';
t_tab(84).resp_name := 'DSP AR CONC VCC ENETT CONSULTA'; t_tab(84).approver_name := ''; t_tab(84).backup_mail := ''; t_tab(84).wf_type := '1';
t_tab(85).resp_name := 'DSP AR CONC VCC WEX CONSULTA'; t_tab(85).approver_name := 'mtrigo@despegar.com'; t_tab(85).backup_mail := ''; t_tab(85).wf_type := 'W';
t_tab(86).resp_name := 'DSP AR CONC VISA LOC ANA'; t_tab(86).approver_name := 'gbeloqui@despegar.com'; t_tab(86).backup_mail := ''; t_tab(86).wf_type := 'W';
t_tab(87).resp_name := 'DSP AR CONC VISA LOC CONSULTA'; t_tab(87).approver_name := 'gbeloqui@despegar.com'; t_tab(87).backup_mail := ''; t_tab(87).wf_type := 'W';
t_tab(88).resp_name := 'DSP AR CONC VISA LOC SUPERVISOR'; t_tab(88).approver_name := 'gbeloqui@despegar.com'; t_tab(88).backup_mail := ''; t_tab(88).wf_type := 'W';
t_tab(89).resp_name := 'DSP AR FA ANALISTA'; t_tab(89).approver_name := 'pimperiale@despegar.com'; t_tab(89).backup_mail := ''; t_tab(89).wf_type := 'W';
t_tab(90).resp_name := 'DSP AR FA CONFIGURADOR'; t_tab(90).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(90).backup_mail := ''; t_tab(90).wf_type := 'W';
t_tab(91).resp_name := 'DSP AR FA CONSULTA'; t_tab(91).approver_name := 'pimperiale@despegar.com'; t_tab(91).backup_mail := ''; t_tab(91).wf_type := 'W';
t_tab(92).resp_name := 'DSP AR FA SUPER USER'; t_tab(92).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(92).backup_mail := ''; t_tab(92).wf_type := 'W';
t_tab(93).resp_name := 'DSP AR GL ANALISTA CORP'; t_tab(93).approver_name := 'pimperiale@despegar.com'; t_tab(93).backup_mail := ''; t_tab(93).wf_type := 'W';
t_tab(94).resp_name := 'DSP AR GL ANALISTA INTERCO'; t_tab(94).approver_name := 'pimperiale@despegar.com'; t_tab(94).backup_mail := ''; t_tab(94).wf_type := 'W';
t_tab(95).resp_name := 'DSP AR GL CONFIGURADOR'; t_tab(95).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(95).backup_mail := ''; t_tab(95).wf_type := 'W';
t_tab(96).resp_name := 'DSP AR GL CONSULTAS CORP'; t_tab(96).approver_name := 'pimperiale@despegar.com'; t_tab(96).backup_mail := ''; t_tab(96).wf_type := 'W';
t_tab(97).resp_name := 'DSP AR GL CONSULTAS LOCAL'; t_tab(97).approver_name := 'pimperiale@despegar.com'; t_tab(97).backup_mail := ''; t_tab(97).wf_type := 'W';
t_tab(98).resp_name := 'DSP AR GL CONSULTAS USGAAP'; t_tab(98).approver_name := 'pimperiale@despegar.com'; t_tab(98).backup_mail := ''; t_tab(98).wf_type := 'W';
t_tab(99).resp_name := 'DSP AR GL GERENTE CORP'; t_tab(99).approver_name := 'pimperiale@despegar.com'; t_tab(99).backup_mail := ''; t_tab(99).wf_type := 'W';
t_tab(100).resp_name := 'DSP AR GL REPORTES CORP'; t_tab(100).approver_name := 'pimperiale@despegar.com'; t_tab(100).backup_mail := ''; t_tab(100).wf_type := 'W';
t_tab(101).resp_name := 'DSP AR GL REPORTES LOCAL'; t_tab(101).approver_name := 'pimperiale@despegar.com'; t_tab(101).backup_mail := ''; t_tab(101).wf_type := 'W';
t_tab(102).resp_name := 'DSP AR GL SUPER USER'; t_tab(102).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(102).backup_mail := ''; t_tab(102).wf_type := 'W';
t_tab(103).resp_name := 'DSP AR OIE AUDITOR DE GASTOS'; t_tab(103).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(103).backup_mail := 'florencia.hansen@despegar.com'; t_tab(103).wf_type := 'W';
t_tab(104).resp_name := 'DSP AR OIE RENDICION DE GASTOS'; t_tab(104).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(104).backup_mail := 'florencia.hansen@despegar.com'; t_tab(104).wf_type := 'W';
t_tab(105).resp_name := 'DSP AR OIE RENDICION DE GASTOS CC'; t_tab(105).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(105).backup_mail := 'florencia.hansen@despegar.com'; t_tab(105).wf_type := 'W';
t_tab(106).resp_name := 'DSP AR OM CONFIGURADOR(1)'; t_tab(106).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(106).backup_mail := ''; t_tab(106).wf_type := 'W';
t_tab(107).resp_name := 'DSP AR OM CONSULTA'; t_tab(107).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(107).backup_mail := ''; t_tab(107).wf_type := 'W';
t_tab(108).resp_name := 'DSP AR OM PEDIDOS VENTA'; t_tab(108).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(108).backup_mail := ''; t_tab(108).wf_type := 'W';
t_tab(109).resp_name := 'DSP AR OM SUPER USER'; t_tab(109).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(109).backup_mail := ''; t_tab(109).wf_type := 'W';
t_tab(110).resp_name := 'DSP AR OM SUPERV'; t_tab(110).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(110).backup_mail := ''; t_tab(110).wf_type := 'W';
t_tab(111).resp_name := 'DSP AR PO ADMINISTRADOR CONTABLE'; t_tab(111).approver_name := 'rocastro@despegar.com'; t_tab(111).backup_mail := ''; t_tab(111).wf_type := 'W';
t_tab(112).resp_name := 'DSP AR PO APROBADOR'; t_tab(112).approver_name := 'rocastro@despegar.com'; t_tab(112).backup_mail := ''; t_tab(112).wf_type := 'W';
t_tab(113).resp_name := 'DSP AR PO COMPRADOR NO TURISTICO'; t_tab(113).approver_name := 'rocastro@despegar.com'; t_tab(113).backup_mail := ''; t_tab(113).wf_type := 'W';
t_tab(114).resp_name := 'DSP AR PO CONFIG EMPLOYEES'; t_tab(114).approver_name := 'rocastro@despegar.com'; t_tab(114).backup_mail := ''; t_tab(114).wf_type := 'W';
t_tab(115).resp_name := 'DSP AR PO CONFIGURADOR'; t_tab(115).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(115).backup_mail := ''; t_tab(115).wf_type := 'W';
t_tab(116).resp_name := 'DSP AR PO CONFIGURADOR JERARQUIA'; t_tab(116).approver_name := 'rocastro@despegar.com'; t_tab(116).backup_mail := ''; t_tab(116).wf_type := 'W';
t_tab(117).resp_name := 'DSP AR PO CONSULTA'; t_tab(117).approver_name := 'rocastro@despegar.com'; t_tab(117).backup_mail := ''; t_tab(117).wf_type := 'W';
t_tab(118).resp_name := 'DSP AR PO DESPACHOS MKT'; t_tab(118).approver_name := 'rocastro@despegar.com'; t_tab(118).backup_mail := ''; t_tab(118).wf_type := 'W';
t_tab(119).resp_name := 'DSP AR PO RECEPCION'; t_tab(119).approver_name := 'rocastro@despegar.com'; t_tab(119).backup_mail := ''; t_tab(119).wf_type := 'W';
t_tab(120).resp_name := 'DSP AR PO SOLICITANTE DE COMPRA'; t_tab(120).approver_name := 'rocastro@despegar.com'; t_tab(120).backup_mail := ''; t_tab(120).wf_type := 'W';
t_tab(121).resp_name := 'DSP AR PO SUPER USER'; t_tab(121).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(121).backup_mail := ''; t_tab(121).wf_type := 'W';
t_tab(122).resp_name := 'DSP AR XX FLIGHTS CONSULTA'; t_tab(122).approver_name := 'ncabezas@despegar.com'; t_tab(122).backup_mail := ''; t_tab(122).wf_type := 'W';
t_tab(123).resp_name := 'DSP AR XX FLIGHTS SUPERVISOR'; t_tab(123).approver_name := 'ncabezas@despegar.com'; t_tab(123).backup_mail := ''; t_tab(123).wf_type := 'W';
t_tab(124).resp_name := 'DSP BB GL CONSULTAS CORP'; t_tab(124).approver_name := ''; t_tab(124).backup_mail := ''; t_tab(124).wf_type := '1';
t_tab(125).resp_name := 'DSP BB GL CONSULTAS USGAAP'; t_tab(125).approver_name := ''; t_tab(125).backup_mail := ''; t_tab(125).wf_type := '1';
t_tab(126).resp_name := 'DSP BB GL REPORTES CORP'; t_tab(126).approver_name := ''; t_tab(126).backup_mail := ''; t_tab(126).wf_type := '1';
t_tab(127).resp_name := 'DSP BR AP ABM PROVEEDORES'; t_tab(127).approver_name := 'gbeloqui@despegar.com'; t_tab(127).backup_mail := ''; t_tab(127).wf_type := 'W';
t_tab(128).resp_name := 'DSP BR AP ANALISTA HOLD PREPAGO'; t_tab(128).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(128).backup_mail := ''; t_tab(128).wf_type := 'W';
t_tab(129).resp_name := 'DSP BR AP ANALISTA I'; t_tab(129).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(129).backup_mail := ''; t_tab(129).wf_type := 'W';
t_tab(130).resp_name := 'DSP BR AP ANALISTA II'; t_tab(130).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(130).backup_mail := ''; t_tab(130).wf_type := 'W';
t_tab(131).resp_name := 'DSP BR AP CONFIGURADOR'; t_tab(131).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(131).backup_mail := ''; t_tab(131).wf_type := 'W';
t_tab(132).resp_name := 'DSP BR AP CONSULTA'; t_tab(132).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(132).backup_mail := ''; t_tab(132).wf_type := 'W';
t_tab(133).resp_name := 'DSP BR AP GERENTE'; t_tab(133).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(133).backup_mail := ''; t_tab(133).wf_type := 'W';
t_tab(134).resp_name := 'DSP BR AP SUPER USER'; t_tab(134).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(134).backup_mail := ''; t_tab(134).wf_type := 'W';
t_tab(135).resp_name := 'DSP BR AR ABM CLIENTES'; t_tab(135).approver_name := 'gbeloqui@despegar.com'; t_tab(135).backup_mail := ''; t_tab(135).wf_type := 'W';
t_tab(136).resp_name := 'DSP BR AR ANALISTA'; t_tab(136).approver_name := 'mlombardi@decolar.com'; t_tab(136).backup_mail := ''; t_tab(136).wf_type := 'W';
t_tab(137).resp_name := 'DSP BR AR ANALISTA DT'; t_tab(137).approver_name := 'mlombardi@decolar.com'; t_tab(137).backup_mail := ''; t_tab(137).wf_type := 'W';
t_tab(138).resp_name := 'DSP BR AR ANALISTA DT 01'; t_tab(138).approver_name := 'mlombardi@decolar.com'; t_tab(138).backup_mail := ''; t_tab(138).wf_type := 'W';
t_tab(139).resp_name := 'DSP BR AR ANALISTA FAT'; t_tab(139).approver_name := 'mlombardi@decolar.com'; t_tab(139).backup_mail := ''; t_tab(139).wf_type := 'W';
t_tab(140).resp_name := 'DSP BR AR CALENDARIOS'; t_tab(140).approver_name := 'mlombardi@decolar.com'; t_tab(140).backup_mail := ''; t_tab(140).wf_type := 'W';
t_tab(141).resp_name := 'DSP BR AR CONFIGURADOR'; t_tab(141).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(141).backup_mail := ''; t_tab(141).wf_type := 'W';
t_tab(142).resp_name := 'DSP BR AR CONSULTA'; t_tab(142).approver_name := 'mlombardi@decolar.com'; t_tab(142).backup_mail := ''; t_tab(142).wf_type := 'W';
t_tab(143).resp_name := 'DSP BR AR SUPER USER'; t_tab(143).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(143).backup_mail := ''; t_tab(143).wf_type := 'W';
t_tab(144).resp_name := 'DSP BR AR SUPERV FAT'; t_tab(144).approver_name := 'mlombardi@decolar.com'; t_tab(144).backup_mail := ''; t_tab(144).wf_type := 'W';
t_tab(145).resp_name := 'DSP BR CE CONCILIA��ES'; t_tab(145).approver_name := 'roman.richter@despegar.com'; t_tab(145).backup_mail := ''; t_tab(145).wf_type := 'W';
t_tab(146).resp_name := 'DSP BR CE CONFIGURADOR'; t_tab(146).approver_name := 'roman.richter@despegar.com'; t_tab(146).backup_mail := ''; t_tab(146).wf_type := 'W';
t_tab(147).resp_name := 'DSP BR CE CONSULTA'; t_tab(147).approver_name := 'roman.richter@despegar.com'; t_tab(147).backup_mail := ''; t_tab(147).wf_type := 'W';
t_tab(148).resp_name := 'DSP BR CONC AMEX ANALISTA'; t_tab(148).approver_name := 'gleite@decolar.com'; t_tab(148).backup_mail := ''; t_tab(148).wf_type := 'W';
t_tab(149).resp_name := 'DSP BR CONC BOLETO ANALISTA'; t_tab(149).approver_name := 'gleite@decolar.com'; t_tab(149).backup_mail := ''; t_tab(149).wf_type := 'W';
t_tab(150).resp_name := 'DSP BR CONC CIELO ANALISTA'; t_tab(150).approver_name := 'gleite@decolar.com'; t_tab(150).backup_mail := ''; t_tab(150).wf_type := 'W';
t_tab(151).resp_name := 'DSP BR CONC GETNET SUPERVISOR'; t_tab(151).approver_name := 'gleite@decolar.com'; t_tab(151).backup_mail := ''; t_tab(151).wf_type := 'W';
t_tab(152).resp_name := 'DSP BR CONC REDECAR ANALISTA'; t_tab(152).approver_name := 'gleite@decolar.com'; t_tab(152).backup_mail := ''; t_tab(152).wf_type := 'W';
t_tab(153).resp_name := 'DSP BR CONC SAFETY ANALISTA'; t_tab(153).approver_name := 'gleite@decolar.com'; t_tab(153).backup_mail := ''; t_tab(153).wf_type := 'W';
t_tab(154).resp_name := 'DSP BR CONC VCC UNIK ANALISTA'; t_tab(154).approver_name := 'fstripoli@decolar.com'; t_tab(154).backup_mail := ''; t_tab(154).wf_type := 'W';
t_tab(155).resp_name := 'DSP BR CONC VCC UNIK SUPERVISOR'; t_tab(155).approver_name := 'fstripoli@decolar.com'; t_tab(155).backup_mail := ''; t_tab(155).wf_type := 'W';
t_tab(156).resp_name := 'DSP BR FA ANALISTA'; t_tab(156).approver_name := 'humberto.fonseca@decolar.com'; t_tab(156).backup_mail := ''; t_tab(156).wf_type := 'W';
t_tab(157).resp_name := 'DSP BR FA BAJAS'; t_tab(157).approver_name := 'humberto.fonseca@decolar.com'; t_tab(157).backup_mail := ''; t_tab(157).wf_type := 'W';
t_tab(158).resp_name := 'DSP BR FA CONFIGURADOR'; t_tab(158).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(158).backup_mail := ''; t_tab(158).wf_type := 'W';
t_tab(159).resp_name := 'DSP BR FA SUPER USER'; t_tab(159).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(159).backup_mail := ''; t_tab(159).wf_type := 'W';
t_tab(160).resp_name := 'DSP BR GL ANALISTA CORP'; t_tab(160).approver_name := 'humberto.fonseca@decolar.com'; t_tab(160).backup_mail := ''; t_tab(160).wf_type := 'W';
t_tab(161).resp_name := 'DSP BR GL ANALISTA INTERCOMPANY'; t_tab(161).approver_name := 'humberto.fonseca@decolar.com'; t_tab(161).backup_mail := ''; t_tab(161).wf_type := 'W';
t_tab(162).resp_name := 'DSP BR GL ANALISTA LOCAL'; t_tab(162).approver_name := 'humberto.fonseca@decolar.com'; t_tab(162).backup_mail := ''; t_tab(162).wf_type := 'W';
t_tab(163).resp_name := 'DSP BR GL CONFIGURADOR'; t_tab(163).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(163).backup_mail := ''; t_tab(163).wf_type := 'W';
t_tab(164).resp_name := 'DSP BR GL CONSULTAS CORP'; t_tab(164).approver_name := 'humberto.fonseca@decolar.com'; t_tab(164).backup_mail := ''; t_tab(164).wf_type := 'W';
t_tab(165).resp_name := 'DSP BR GL CONSULTAS LOCAL'; t_tab(165).approver_name := 'humberto.fonseca@decolar.com'; t_tab(165).backup_mail := ''; t_tab(165).wf_type := 'W';
t_tab(166).resp_name := 'DSP BR GL CONSULTAS LOCAL HIST'; t_tab(166).approver_name := 'humberto.fonseca@decolar.com'; t_tab(166).backup_mail := ''; t_tab(166).wf_type := 'W';
t_tab(167).resp_name := 'DSP BR GL CONSULTAS USGAAP'; t_tab(167).approver_name := 'humberto.fonseca@decolar.com'; t_tab(167).backup_mail := ''; t_tab(167).wf_type := 'W';
t_tab(168).resp_name := 'DSP BR GL GERENTE CORP'; t_tab(168).approver_name := 'humberto.fonseca@decolar.com'; t_tab(168).backup_mail := ''; t_tab(168).wf_type := 'W';
t_tab(169).resp_name := 'DSP BR GL GERENTE LOCAL'; t_tab(169).approver_name := 'humberto.fonseca@decolar.com'; t_tab(169).backup_mail := ''; t_tab(169).wf_type := 'W';
t_tab(170).resp_name := 'DSP BR GL LOCAL CONFIGURADOR'; t_tab(170).approver_name := 'humberto.fonseca@decolar.com'; t_tab(170).backup_mail := ''; t_tab(170).wf_type := 'W';
t_tab(171).resp_name := 'DSP BR GL REPORTES CORP'; t_tab(171).approver_name := 'humberto.fonseca@decolar.com'; t_tab(171).backup_mail := ''; t_tab(171).wf_type := 'W';
t_tab(172).resp_name := 'DSP BR GL REPORTES LOCAL'; t_tab(172).approver_name := 'humberto.fonseca@decolar.com'; t_tab(172).backup_mail := ''; t_tab(172).wf_type := 'W';
t_tab(173).resp_name := 'DSP BR GL SUPER USER'; t_tab(173).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(173).backup_mail := ''; t_tab(173).wf_type := 'W';
t_tab(174).resp_name := 'DSP BR GL SUPERVISOR CORP'; t_tab(174).approver_name := 'humberto.fonseca@decolar.com'; t_tab(174).backup_mail := ''; t_tab(174).wf_type := 'W';
t_tab(175).resp_name := 'DSP BR GL SUPERVISOR LOCAL'; t_tab(175).approver_name := 'humberto.fonseca@decolar.com'; t_tab(175).backup_mail := ''; t_tab(175).wf_type := 'W';
t_tab(176).resp_name := 'DSP BR OIE AUDITOR DE GASTOS'; t_tab(176).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(176).backup_mail := ''; t_tab(176).wf_type := 'W';
t_tab(177).resp_name := 'DSP BR OIE Configuraci�n y Administraci�n'; t_tab(177).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(177).backup_mail := ''; t_tab(177).wf_type := 'W';
t_tab(178).resp_name := 'DSP BR OIE REEMBOLSO'; t_tab(178).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(178).backup_mail := ''; t_tab(178).wf_type := 'W';
t_tab(179).resp_name := 'DSP BR OM ANALISTA'; t_tab(179).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(179).backup_mail := ''; t_tab(179).wf_type := 'W';
t_tab(180).resp_name := 'DSP BR OM CONFIGURADOR(1)'; t_tab(180).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(180).backup_mail := ''; t_tab(180).wf_type := 'W';
t_tab(181).resp_name := 'DSP BR OM CONSULTA'; t_tab(181).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(181).backup_mail := ''; t_tab(181).wf_type := 'W';
t_tab(182).resp_name := 'DSP BR OM SUPER USER'; t_tab(182).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(182).backup_mail := ''; t_tab(182).wf_type := 'W';
t_tab(183).resp_name := 'DSP BR OM SUPERV'; t_tab(183).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(183).backup_mail := ''; t_tab(183).wf_type := 'W';
t_tab(184).resp_name := 'DSP BR PO ADMINISTRADOR CONTABLE'; t_tab(184).approver_name := 'gleite@decolar.com'; t_tab(184).backup_mail := ''; t_tab(184).wf_type := 'W';
t_tab(185).resp_name := 'DSP BR PO COMPRADOR N�O TURISTICO'; t_tab(185).approver_name := 'gleite@decolar.com'; t_tab(185).backup_mail := ''; t_tab(185).wf_type := 'W';
t_tab(186).resp_name := 'DSP BR PO CONFIG EMPLOYEES'; t_tab(186).approver_name := 'gleite@decolar.com'; t_tab(186).backup_mail := ''; t_tab(186).wf_type := 'W';
t_tab(187).resp_name := 'DSP BR PO CONFIGURADOR'; t_tab(187).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(187).backup_mail := ''; t_tab(187).wf_type := 'W';
t_tab(188).resp_name := 'DSP BR PO CONSULTA'; t_tab(188).approver_name := 'gleite@decolar.com'; t_tab(188).backup_mail := ''; t_tab(188).wf_type := 'W';
t_tab(189).resp_name := 'DSP BR PO DESPACHOS MKT'; t_tab(189).approver_name := 'gleite@decolar.com'; t_tab(189).backup_mail := ''; t_tab(189).wf_type := 'W';
t_tab(190).resp_name := 'DSP BR PO SOLICITANTE DE COMPRA'; t_tab(190).approver_name := 'gleite@decolar.com'; t_tab(190).backup_mail := ''; t_tab(190).wf_type := 'W';
t_tab(191).resp_name := 'DSP BR PO SUPER USER'; t_tab(191).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(191).backup_mail := ''; t_tab(191).wf_type := 'W';
t_tab(192).resp_name := 'DSP BR RI ANALISTA'; t_tab(192).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(192).backup_mail := ''; t_tab(192).wf_type := 'W';
t_tab(193).resp_name := 'DSP BR RI CONFIGURADOR'; t_tab(193).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(193).backup_mail := ''; t_tab(193).wf_type := 'W';
t_tab(194).resp_name := 'DSP BR RI CONSULTA'; t_tab(194).approver_name := 'valquiria.carmelo@decolar.com'; t_tab(194).backup_mail := ''; t_tab(194).wf_type := 'W';
t_tab(195).resp_name := 'DSP BR RI SUPER USER'; t_tab(195).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(195).backup_mail := ''; t_tab(195).wf_type := 'W';
t_tab(196).resp_name := 'DSP BR XX FLIGHTS CONSULTA'; t_tab(196).approver_name := 'icartes@decolar.com'; t_tab(196).backup_mail := ''; t_tab(196).wf_type := 'W';
t_tab(197).resp_name := 'DSP BR XX FLIGHTS SUPERVISOR'; t_tab(197).approver_name := 'icartes@decolar.com'; t_tab(197).backup_mail := ''; t_tab(197).wf_type := 'W';
t_tab(198).resp_name := 'DSP CL AP ABM BANCOS y CTAS BANCARIAS'; t_tab(198).approver_name := 'roman.richter@despegar.com'; t_tab(198).backup_mail := ''; t_tab(198).wf_type := 'W';
t_tab(199).resp_name := 'DSP CL AP ABM PROVEEDORES'; t_tab(199).approver_name := 'gbeloqui@despegar.com'; t_tab(199).backup_mail := ''; t_tab(199).wf_type := 'W';
t_tab(200).resp_name := 'DSP CL AP ANALISTA JR'; t_tab(200).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(200).backup_mail := 'florencia.hansen@despegar.com'; t_tab(200).wf_type := 'W';
t_tab(201).resp_name := 'DSP CL AP ANALISTA SR'; t_tab(201).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(201).backup_mail := 'florencia.hansen@despegar.com'; t_tab(201).wf_type := 'W';
t_tab(202).resp_name := 'DSP CL AP APROBADOR FC AME'; t_tab(202).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(202).backup_mail := 'florencia.hansen@despegar.com'; t_tab(202).wf_type := 'W';
t_tab(203).resp_name := 'DSP CL AP CONFIGURADOR'; t_tab(203).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(203).backup_mail := ''; t_tab(203).wf_type := 'W';
t_tab(204).resp_name := 'DSP CL AP CONSULTAS'; t_tab(204).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(204).backup_mail := 'florencia.hansen@despegar.com'; t_tab(204).wf_type := 'W';
t_tab(205).resp_name := 'DSP CL AP GERENTE'; t_tab(205).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(205).backup_mail := 'florencia.hansen@despegar.com'; t_tab(205).wf_type := 'W';
t_tab(206).resp_name := 'DSP CL AP SUPER USER'; t_tab(206).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(206).backup_mail := ''; t_tab(206).wf_type := 'W';
t_tab(207).resp_name := 'DSP CL AR ABM CLIENTES'; t_tab(207).approver_name := 'gbeloqui@despegar.com'; t_tab(207).backup_mail := ''; t_tab(207).wf_type := 'W';
t_tab(208).resp_name := 'DSP CL AR ANALISTA COBR'; t_tab(208).approver_name := 'edeluca@despegar.com'; t_tab(208).backup_mail := ''; t_tab(208).wf_type := 'W';
t_tab(209).resp_name := 'DSP CL AR ANALISTA COBR INTERCO'; t_tab(209).approver_name := 'edeluca@despegar.com'; t_tab(209).backup_mail := ''; t_tab(209).wf_type := 'W';
t_tab(210).resp_name := 'DSP CL AR ANALISTA FACT'; t_tab(210).approver_name := 'edeluca@despegar.com'; t_tab(210).backup_mail := ''; t_tab(210).wf_type := 'W';
t_tab(211).resp_name := 'DSP CL AR ANALISTA FACT INTERCO'; t_tab(211).approver_name := 'edeluca@despegar.com'; t_tab(211).backup_mail := ''; t_tab(211).wf_type := 'W';
t_tab(212).resp_name := 'DSP CL AR CONFIGURADOR'; t_tab(212).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(212).backup_mail := ''; t_tab(212).wf_type := 'W';
t_tab(213).resp_name := 'DSP CL AR CONSULTA'; t_tab(213).approver_name := 'edeluca@despegar.com'; t_tab(213).backup_mail := ''; t_tab(213).wf_type := 'W';
t_tab(214).resp_name := 'DSP CL AR SUPER USER'; t_tab(214).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(214).backup_mail := ''; t_tab(214).wf_type := 'W';
t_tab(215).resp_name := 'DSP CL AR SUPERV COBR'; t_tab(215).approver_name := 'edeluca@despegar.com'; t_tab(215).backup_mail := ''; t_tab(215).wf_type := 'W';
t_tab(216).resp_name := 'DSP CL AR SUPERV FACT'; t_tab(216).approver_name := 'edeluca@despegar.com'; t_tab(216).backup_mail := ''; t_tab(216).wf_type := 'W';
t_tab(217).resp_name := 'DSP CL CE CONCILIACIONES'; t_tab(217).approver_name := 'roman.richter@despegar.com'; t_tab(217).backup_mail := ''; t_tab(217).wf_type := 'W';
t_tab(218).resp_name := 'DSP CL CE CONFIGURADOR'; t_tab(218).approver_name := 'roman.richter@despegar.com'; t_tab(218).backup_mail := ''; t_tab(218).wf_type := 'W';
t_tab(219).resp_name := 'DSP CL CE SUPER USER'; t_tab(219).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(219).backup_mail := ''; t_tab(219).wf_type := 'W';
t_tab(220).resp_name := 'DSP CL CE TESORERIA'; t_tab(220).approver_name := 'roman.richter@despegar.com'; t_tab(220).backup_mail := ''; t_tab(220).wf_type := 'W';
t_tab(221).resp_name := 'DSP CL CONC SAFETY CONSULTA'; t_tab(221).approver_name := 'fpais@despegar.com'; t_tab(221).backup_mail := ''; t_tab(221).wf_type := 'W';
t_tab(222).resp_name := 'DSP CL CONC SAFETY SUPERVISOR'; t_tab(222).approver_name := 'fpais@despegar.com'; t_tab(222).backup_mail := ''; t_tab(222).wf_type := 'W';
t_tab(223).resp_name := 'DSP CL CONC TRB CONSULTA'; t_tab(223).approver_name := 'fpais@despegar.com'; t_tab(223).backup_mail := ''; t_tab(223).wf_type := 'W';
t_tab(224).resp_name := 'DSP CL CONC TRB SUPERVISOR'; t_tab(224).approver_name := 'fpais@despegar.com'; t_tab(224).backup_mail := ''; t_tab(224).wf_type := 'W';
t_tab(225).resp_name := 'DSP CL GL ANALISTA CORP'; t_tab(225).approver_name := 'nquezada@despegar.com'; t_tab(225).backup_mail := ''; t_tab(225).wf_type := 'W';
t_tab(226).resp_name := 'DSP CL GL ANALISTA INTERCO'; t_tab(226).approver_name := 'nquezada@despegar.com'; t_tab(226).backup_mail := ''; t_tab(226).wf_type := 'W';
t_tab(227).resp_name := 'DSP CL GL CONFIGURADOR'; t_tab(227).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(227).backup_mail := ''; t_tab(227).wf_type := 'W';
t_tab(228).resp_name := 'DSP CL GL CONSULTAS AXI'; t_tab(228).approver_name := 'nquezada@despegar.com'; t_tab(228).backup_mail := ''; t_tab(228).wf_type := 'W';
t_tab(229).resp_name := 'DSP CL GL CONSULTAS CORP'; t_tab(229).approver_name := 'nquezada@despegar.com'; t_tab(229).backup_mail := ''; t_tab(229).wf_type := 'W';
t_tab(230).resp_name := 'DSP CL GL CONSULTAS LOCAL'; t_tab(230).approver_name := 'nquezada@despegar.com'; t_tab(230).backup_mail := ''; t_tab(230).wf_type := 'W';
t_tab(231).resp_name := 'DSP CL GL CONSULTAS USGAAP'; t_tab(231).approver_name := 'nquezada@despegar.com'; t_tab(231).backup_mail := ''; t_tab(231).wf_type := 'W';
t_tab(232).resp_name := 'DSP CL GL GERENTE CORP'; t_tab(232).approver_name := 'nquezada@despegar.com'; t_tab(232).backup_mail := ''; t_tab(232).wf_type := 'W';
t_tab(233).resp_name := 'DSP CL GL SUPER USER'; t_tab(233).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(233).backup_mail := ''; t_tab(233).wf_type := 'W';
t_tab(234).resp_name := 'DSP CL OIE AUDITOR DE GASTOS'; t_tab(234).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(234).backup_mail := 'florencia.hansen@despegar.com'; t_tab(234).wf_type := 'W';
t_tab(235).resp_name := 'DSP CL OIE RENDICION DE GASTOS'; t_tab(235).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(235).backup_mail := 'florencia.hansen@despegar.com'; t_tab(235).wf_type := 'W';
t_tab(236).resp_name := 'DSP CL OM CONFIGURADOR'; t_tab(236).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(236).backup_mail := ''; t_tab(236).wf_type := 'W';
t_tab(237).resp_name := 'DSP CL OM CONSULTA'; t_tab(237).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(237).backup_mail := ''; t_tab(237).wf_type := 'W';
t_tab(238).resp_name := 'DSP CL OM SUPER USER'; t_tab(238).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(238).backup_mail := ''; t_tab(238).wf_type := 'W';
t_tab(239).resp_name := 'DSP CL OM SUPERV'; t_tab(239).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(239).backup_mail := ''; t_tab(239).wf_type := 'W';
t_tab(240).resp_name := 'DSP CL PO ADMINISTRADOR CONTABLE'; t_tab(240).approver_name := 'nquezada@despegar.com'; t_tab(240).backup_mail := ''; t_tab(240).wf_type := 'W';
t_tab(241).resp_name := 'DSP CL PO APROBADOR'; t_tab(241).approver_name := 'nquezada@despegar.com'; t_tab(241).backup_mail := ''; t_tab(241).wf_type := 'W';
t_tab(242).resp_name := 'DSP CL PO COMPRADOR NO TURISTICO'; t_tab(242).approver_name := 'nquezada@despegar.com'; t_tab(242).backup_mail := ''; t_tab(242).wf_type := 'W';
t_tab(243).resp_name := 'DSP CL PO CONFIG EMPLOYEES'; t_tab(243).approver_name := 'nquezada@despegar.com'; t_tab(243).backup_mail := ''; t_tab(243).wf_type := 'W';
t_tab(244).resp_name := 'DSP CL PO CONFIGURADOR'; t_tab(244).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(244).backup_mail := ''; t_tab(244).wf_type := 'W';
t_tab(245).resp_name := 'DSP CL PO CONSULTA'; t_tab(245).approver_name := 'nquezada@despegar.com'; t_tab(245).backup_mail := ''; t_tab(245).wf_type := 'W';
t_tab(246).resp_name := 'DSP CL PO DESPACHOS MKT'; t_tab(246).approver_name := 'nquezada@despegar.com'; t_tab(246).backup_mail := ''; t_tab(246).wf_type := 'W';
t_tab(247).resp_name := 'DSP CL PO RECEPCION'; t_tab(247).approver_name := 'nquezada@despegar.com'; t_tab(247).backup_mail := ''; t_tab(247).wf_type := 'W';
t_tab(248).resp_name := 'DSP CL PO SOLICITANTE DE COMPRA'; t_tab(248).approver_name := 'nquezada@despegar.com'; t_tab(248).backup_mail := ''; t_tab(248).wf_type := 'W';
t_tab(249).resp_name := 'DSP CL PO SUPER USER'; t_tab(249).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(249).backup_mail := ''; t_tab(249).wf_type := 'W';
t_tab(250).resp_name := 'DSP CL XX FLIGHTS CONSULTA'; t_tab(250).approver_name := 'ncabezas@despegar.com'; t_tab(250).backup_mail := ''; t_tab(250).wf_type := 'W';
t_tab(251).resp_name := 'DSP CL XX FLIGHTS SUPERVISOR'; t_tab(251).approver_name := 'ncabezas@despegar.com'; t_tab(251).backup_mail := ''; t_tab(251).wf_type := 'W';
t_tab(252).resp_name := 'DSP CO AP CONFIGURADOR(1)'; t_tab(252).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(252).backup_mail := ''; t_tab(252).wf_type := 'W';
t_tab(253).resp_name := 'DSP CO CONC BOG CONSULTA'; t_tab(253).approver_name := 'fpais@despegar.com'; t_tab(253).backup_mail := ''; t_tab(253).wf_type := 'W';
t_tab(254).resp_name := 'DSP CO CONC BOG SUPERVISOR'; t_tab(254).approver_name := 'fpais@despegar.com'; t_tab(254).backup_mail := ''; t_tab(254).wf_type := 'W';
t_tab(255).resp_name := 'DSP CO CONC DAV CONSULTA'; t_tab(255).approver_name := 'fpais@despegar.com'; t_tab(255).backup_mail := ''; t_tab(255).wf_type := 'W';
t_tab(256).resp_name := 'DSP CO CONC DAV SUPERVISOR'; t_tab(256).approver_name := 'fpais@despegar.com'; t_tab(256).backup_mail := ''; t_tab(256).wf_type := 'W';
t_tab(257).resp_name := 'DSP CO CONC PAYU CONSULTA'; t_tab(257).approver_name := 'fpais@despegar.com'; t_tab(257).backup_mail := ''; t_tab(257).wf_type := 'W';
t_tab(258).resp_name := 'DSP CO CONC PAYU SUPERVISOR'; t_tab(258).approver_name := 'fpais@despegar.com'; t_tab(258).backup_mail := ''; t_tab(258).wf_type := 'W';
t_tab(259).resp_name := 'DSP CO CONC SAFETY CONSULTA'; t_tab(259).approver_name := 'fpais@despegar.com'; t_tab(259).backup_mail := ''; t_tab(259).wf_type := 'W';
t_tab(260).resp_name := 'DSP CO CONC SAFETY SUPERVISOR'; t_tab(260).approver_name := 'fpais@despegar.com'; t_tab(260).backup_mail := ''; t_tab(260).wf_type := 'W';
t_tab(261).resp_name := 'DSP CO CONC WPAY SUPERVISOR'; t_tab(261).approver_name := 'fpais@despegar.com'; t_tab(261).backup_mail := ''; t_tab(261).wf_type := 'W';
t_tab(262).resp_name := 'DSP CO GL ANALISTA CORP'; t_tab(262).approver_name := 'gutierrezl@despegar.com'; t_tab(262).backup_mail := ''; t_tab(262).wf_type := 'W';
t_tab(263).resp_name := 'DSP CO GL CONSULTAS CORP'; t_tab(263).approver_name := 'gutierrezl@despegar.com'; t_tab(263).backup_mail := ''; t_tab(263).wf_type := 'W';
t_tab(264).resp_name := 'DSP CO GL CONSULTAS LOCAL'; t_tab(264).approver_name := 'gutierrezl@despegar.com'; t_tab(264).backup_mail := ''; t_tab(264).wf_type := 'W';
t_tab(265).resp_name := 'DSP CO GL CONSULTAS USGAAP'; t_tab(265).approver_name := 'gutierrezl@despegar.com'; t_tab(265).backup_mail := ''; t_tab(265).wf_type := 'W';
t_tab(266).resp_name := 'DSP CO GL GERENTE LOCAL'; t_tab(266).approver_name := 'gutierrezl@despegar.com'; t_tab(266).backup_mail := ''; t_tab(266).wf_type := 'W';
t_tab(267).resp_name := 'DSP CO GL REPORTES CORP'; t_tab(267).approver_name := 'gutierrezl@despegar.com'; t_tab(267).backup_mail := ''; t_tab(267).wf_type := 'W';
t_tab(268).resp_name := 'DSP CO SAS AP ABM BANCOS y CTAS BANCARIAS'; t_tab(268).approver_name := 'roman.richter@despegar.com'; t_tab(268).backup_mail := ''; t_tab(268).wf_type := 'W';
t_tab(269).resp_name := 'DSP CO SAS AP ABM PROVEEDORES'; t_tab(269).approver_name := 'gbeloqui@despegar.com'; t_tab(269).backup_mail := ''; t_tab(269).wf_type := 'W';
t_tab(270).resp_name := 'DSP CO SAS AP ANALISTA JR'; t_tab(270).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(270).backup_mail := 'florencia.hansen@despegar.com'; t_tab(270).wf_type := 'W';
t_tab(271).resp_name := 'DSP CO SAS AP ANALISTA SR'; t_tab(271).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(271).backup_mail := 'florencia.hansen@despegar.com'; t_tab(271).wf_type := 'W';
t_tab(272).resp_name := 'DSP CO SAS AP CONSULTAS'; t_tab(272).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(272).backup_mail := 'florencia.hansen@despegar.com'; t_tab(272).wf_type := 'W';
t_tab(273).resp_name := 'DSP CO SAS AP GERENTE'; t_tab(273).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(273).backup_mail := 'florencia.hansen@despegar.com'; t_tab(273).wf_type := 'W';
t_tab(274).resp_name := 'DSP CO SAS AP SUPER USER'; t_tab(274).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(274).backup_mail := ''; t_tab(274).wf_type := 'W';
t_tab(275).resp_name := 'DSP CO SAS AR ABM CLIENTES'; t_tab(275).approver_name := 'gbeloqui@despegar.com'; t_tab(275).backup_mail := ''; t_tab(275).wf_type := 'W';
t_tab(276).resp_name := 'DSP CO SAS AR ANALISTA COBR'; t_tab(276).approver_name := 'edeluca@despegar.com'; t_tab(276).backup_mail := ''; t_tab(276).wf_type := 'W';
t_tab(277).resp_name := 'DSP CO SAS AR ANALISTA COBR INTERCO'; t_tab(277).approver_name := 'edeluca@despegar.com'; t_tab(277).backup_mail := ''; t_tab(277).wf_type := 'W';
t_tab(278).resp_name := 'DSP CO SAS AR ANALISTA FACT'; t_tab(278).approver_name := 'edeluca@despegar.com'; t_tab(278).backup_mail := ''; t_tab(278).wf_type := 'W';
t_tab(279).resp_name := 'DSP CO SAS AR ANALISTA FACT INTERCO'; t_tab(279).approver_name := 'edeluca@despegar.com'; t_tab(279).backup_mail := ''; t_tab(279).wf_type := 'W';
t_tab(280).resp_name := 'DSP CO SAS AR CONFIGURADOR'; t_tab(280).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(280).backup_mail := ''; t_tab(280).wf_type := 'W';
t_tab(281).resp_name := 'DSP CO SAS AR CONSULTA'; t_tab(281).approver_name := 'edeluca@despegar.com'; t_tab(281).backup_mail := ''; t_tab(281).wf_type := 'W';
t_tab(282).resp_name := 'DSP CO SAS AR SUPER USER'; t_tab(282).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(282).backup_mail := ''; t_tab(282).wf_type := 'W';
t_tab(283).resp_name := 'DSP CO SAS AR SUPERV COBR'; t_tab(283).approver_name := 'edeluca@despegar.com'; t_tab(283).backup_mail := ''; t_tab(283).wf_type := 'W';
t_tab(284).resp_name := 'DSP CO SAS AR SUPERV FACT'; t_tab(284).approver_name := 'edeluca@despegar.com'; t_tab(284).backup_mail := ''; t_tab(284).wf_type := 'W';
t_tab(285).resp_name := 'DSP CO SAS CE CONCILIACIONES'; t_tab(285).approver_name := 'roman.richter@despegar.com'; t_tab(285).backup_mail := ''; t_tab(285).wf_type := 'W';
t_tab(286).resp_name := 'DSP CO SAS CE CONFIGURADOR'; t_tab(286).approver_name := 'roman.richter@despegar.com'; t_tab(286).backup_mail := ''; t_tab(286).wf_type := 'W';
t_tab(287).resp_name := 'DSP CO SAS CE SUPER USER'; t_tab(287).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(287).backup_mail := ''; t_tab(287).wf_type := 'W';
t_tab(288).resp_name := 'DSP CO SAS CE TESORERIA'; t_tab(288).approver_name := 'roman.richter@despegar.com'; t_tab(288).backup_mail := ''; t_tab(288).wf_type := 'W';
t_tab(289).resp_name := 'DSP CO SAS GL ANALISTA CORP'; t_tab(289).approver_name := 'gutierrezl@despegar.com'; t_tab(289).backup_mail := ''; t_tab(289).wf_type := 'W';
t_tab(290).resp_name := 'DSP CO SAS GL ANALISTA INTERCO'; t_tab(290).approver_name := 'gutierrezl@despegar.com'; t_tab(290).backup_mail := ''; t_tab(290).wf_type := 'W';
t_tab(291).resp_name := 'DSP CO SAS GL CONFIGURADOR'; t_tab(291).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(291).backup_mail := ''; t_tab(291).wf_type := 'W';
t_tab(292).resp_name := 'DSP CO SAS GL CONSULTA CORP'; t_tab(292).approver_name := 'gutierrezl@despegar.com'; t_tab(292).backup_mail := ''; t_tab(292).wf_type := 'W';
t_tab(293).resp_name := 'DSP CO SAS GL GERENTE CORP'; t_tab(293).approver_name := 'gutierrezl@despegar.com'; t_tab(293).backup_mail := ''; t_tab(293).wf_type := 'W';
t_tab(294).resp_name := 'DSP CO SAS GL SUPER USER'; t_tab(294).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(294).backup_mail := ''; t_tab(294).wf_type := 'W';
t_tab(295).resp_name := 'DSP CO SAS GL TERCEROS'; t_tab(295).approver_name := 'gutierrezl@despegar.com'; t_tab(295).backup_mail := ''; t_tab(295).wf_type := 'W';
t_tab(296).resp_name := 'DSP CO SAS OIE AUDITOR DE GASTOS'; t_tab(296).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(296).backup_mail := 'florencia.hansen@despegar.com'; t_tab(296).wf_type := 'W';
t_tab(297).resp_name := 'DSP CO SAS OIE Configuraci�n y Administraci�n'; t_tab(297).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(297).backup_mail := 'florencia.hansen@despegar.com'; t_tab(297).wf_type := 'W';
t_tab(298).resp_name := 'DSP CO SAS OIE RENDICION DE GASTOS'; t_tab(298).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(298).backup_mail := 'florencia.hansen@despegar.com'; t_tab(298).wf_type := 'W';
t_tab(299).resp_name := 'DSP CO SAS OM CONFIGURADOR'; t_tab(299).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(299).backup_mail := ''; t_tab(299).wf_type := 'W';
t_tab(300).resp_name := 'DSP CO SAS OM CONSULTA'; t_tab(300).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(300).backup_mail := ''; t_tab(300).wf_type := 'W';
t_tab(301).resp_name := 'DSP CO SAS OM SUPER USER'; t_tab(301).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(301).backup_mail := ''; t_tab(301).wf_type := 'W';
t_tab(302).resp_name := 'DSP CO SAS OM SUPERV'; t_tab(302).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(302).backup_mail := ''; t_tab(302).wf_type := 'W';
t_tab(303).resp_name := 'DSP CO SAS PO ADMINISTRADOR CONTABLE'; t_tab(303).approver_name := 'gutierrezl@despegar.com'; t_tab(303).backup_mail := ''; t_tab(303).wf_type := 'W';
t_tab(304).resp_name := 'DSP CO SAS PO APROBADOR'; t_tab(304).approver_name := 'gutierrezl@despegar.com'; t_tab(304).backup_mail := ''; t_tab(304).wf_type := 'W';
t_tab(305).resp_name := 'DSP CO SAS PO COMPRADOR NO TURISTICO'; t_tab(305).approver_name := 'gutierrezl@despegar.com'; t_tab(305).backup_mail := ''; t_tab(305).wf_type := 'W';
t_tab(306).resp_name := 'DSP CO SAS PO CONFIG EMPLOYEES'; t_tab(306).approver_name := 'gutierrezl@despegar.com'; t_tab(306).backup_mail := ''; t_tab(306).wf_type := 'W';
t_tab(307).resp_name := 'DSP CO SAS PO CONFIGURADOR'; t_tab(307).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(307).backup_mail := ''; t_tab(307).wf_type := 'W';
t_tab(308).resp_name := 'DSP CO SAS PO CONSULTA'; t_tab(308).approver_name := 'gutierrezl@despegar.com'; t_tab(308).backup_mail := ''; t_tab(308).wf_type := 'W';
t_tab(309).resp_name := 'DSP CO SAS PO DESPACHOS MKT'; t_tab(309).approver_name := 'gutierrezl@despegar.com'; t_tab(309).backup_mail := ''; t_tab(309).wf_type := 'W';
t_tab(310).resp_name := 'DSP CO SAS PO RECEPCION'; t_tab(310).approver_name := 'gutierrezl@despegar.com'; t_tab(310).backup_mail := ''; t_tab(310).wf_type := 'W';
t_tab(311).resp_name := 'DSP CO SAS PO SOLICITANTE DE COMPRA'; t_tab(311).approver_name := 'gutierrezl@despegar.com'; t_tab(311).backup_mail := ''; t_tab(311).wf_type := 'W';
t_tab(312).resp_name := 'DSP CO SAS PO SUPER USER'; t_tab(312).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(312).backup_mail := ''; t_tab(312).wf_type := 'W';
t_tab(313).resp_name := 'DSP CO SAS XX FLIGHTS CONSULTA'; t_tab(313).approver_name := 'ncabezas@despegar.com'; t_tab(313).backup_mail := ''; t_tab(313).wf_type := 'W';
t_tab(314).resp_name := 'DSP CO SAS XX FLIGHTS SUPERVISOR'; t_tab(314).approver_name := 'ncabezas@despegar.com'; t_tab(314).backup_mail := ''; t_tab(314).wf_type := 'W';
t_tab(315).resp_name := 'DSP CO2 GL ANALISTA CORP'; t_tab(315).approver_name := 'gutierrezl@despegar.com'; t_tab(315).backup_mail := ''; t_tab(315).wf_type := 'W';
t_tab(316).resp_name := 'DSP CO2 GL CONSULTAS CORP'; t_tab(316).approver_name := 'gutierrezl@despegar.com'; t_tab(316).backup_mail := ''; t_tab(316).wf_type := 'W';
t_tab(317).resp_name := 'DSP CO2 GL CONSULTAS USGAAP'; t_tab(317).approver_name := 'gutierrezl@despegar.com'; t_tab(317).backup_mail := ''; t_tab(317).wf_type := 'W';
t_tab(318).resp_name := 'DSP CO2 GL GERENTE CORP'; t_tab(318).approver_name := 'gutierrezl@despegar.com'; t_tab(318).backup_mail := ''; t_tab(318).wf_type := 'W';
t_tab(319).resp_name := 'DSP CO2 GL SUPER USER'; t_tab(319).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(319).backup_mail := ''; t_tab(319).wf_type := 'W';
t_tab(320).resp_name := 'DSP CO3 GL CONSULTAS CORP'; t_tab(320).approver_name := 'gutierrezl@despegar.com'; t_tab(320).backup_mail := ''; t_tab(320).wf_type := 'W';
t_tab(321).resp_name := 'DSP CO3 GL CONSULTAS USGAAP'; t_tab(321).approver_name := 'gutierrezl@despegar.com'; t_tab(321).backup_mail := ''; t_tab(321).wf_type := 'W';
t_tab(322).resp_name := 'DSP CONC AUTOS PAD CONSULTA'; t_tab(322).approver_name := ''; t_tab(322).backup_mail := ''; t_tab(322).wf_type := '1';
t_tab(323).resp_name := 'DSP CONC AUTOS PAD SUPERVISOR'; t_tab(323).approver_name := ''; t_tab(323).backup_mail := ''; t_tab(323).wf_type := '1';
t_tab(324).resp_name := 'DSP CONC AUTOS PP CONSULTA'; t_tab(324).approver_name := ''; t_tab(324).backup_mail := ''; t_tab(324).wf_type := '1';
t_tab(325).resp_name := 'DSP CONC AUTOS PP SUPERVISOR'; t_tab(325).approver_name := ''; t_tab(325).backup_mail := ''; t_tab(325).wf_type := '1';
t_tab(326).resp_name := 'DSP CONC COBERT SEGUROS PP ANA'; t_tab(326).approver_name := ''; t_tab(326).backup_mail := ''; t_tab(326).wf_type := '1';
t_tab(327).resp_name := 'DSP CONC COBERT SEGUROS PP CONSULTA'; t_tab(327).approver_name := ''; t_tab(327).backup_mail := ''; t_tab(327).wf_type := '1';
t_tab(328).resp_name := 'DSP CONC CRUCERO NCL PP ANA'; t_tab(328).approver_name := ''; t_tab(328).backup_mail := ''; t_tab(328).wf_type := '1';
t_tab(329).resp_name := 'DSP CONC CRUCERO PULLMAN PP ANA'; t_tab(329).approver_name := ''; t_tab(329).backup_mail := ''; t_tab(329).wf_type := '1';
t_tab(330).resp_name := 'DSP CONC CRUCERO ROYAL PP ANA'; t_tab(330).approver_name := ''; t_tab(330).backup_mail := ''; t_tab(330).wf_type := '1';
t_tab(331).resp_name := 'DSP CONC CRUCEROS PP CONSULTA'; t_tab(331).approver_name := 'mtrigo@despegar.com'; t_tab(331).backup_mail := ''; t_tab(331).wf_type := 'W';
t_tab(332).resp_name := 'DSP CONC HOTEL CONSOLIDADOR PP'; t_tab(332).approver_name := 'mtrigo@despegar.com'; t_tab(332).backup_mail := ''; t_tab(332).wf_type := 'W';
t_tab(333).resp_name := 'DSP CONC HOTEL DIR MX PP ANA'; t_tab(333).approver_name := 'mtrigo@despegar.com'; t_tab(333).backup_mail := ''; t_tab(333).wf_type := 'W';
t_tab(334).resp_name := 'DSP CONC HOTEL DIR OTROS PP ANA'; t_tab(334).approver_name := 'mtrigo@despegar.com'; t_tab(334).backup_mail := ''; t_tab(334).wf_type := 'W';
t_tab(335).resp_name := 'DSP CONC HOTEL DIR PP AR ANA'; t_tab(335).approver_name := 'mtrigo@despegar.com'; t_tab(335).backup_mail := ''; t_tab(335).wf_type := 'W';
t_tab(336).resp_name := 'DSP CONC HOTEL DIR PP BR ANA'; t_tab(336).approver_name := 'mtrigo@despegar.com'; t_tab(336).backup_mail := ''; t_tab(336).wf_type := 'W';
t_tab(337).resp_name := 'DSP CONC HOTEL DIR PP CO ANA'; t_tab(337).approver_name := 'mtrigo@despegar.com'; t_tab(337).backup_mail := ''; t_tab(337).wf_type := 'W';
t_tab(338).resp_name := 'DSP CONC HOTEL RIU PP ANA'; t_tab(338).approver_name := 'mtrigo@despegar.com'; t_tab(338).backup_mail := ''; t_tab(338).wf_type := 'W';
t_tab(339).resp_name := 'DSP CONC HOTELES PAD CONSULTA'; t_tab(339).approver_name := ''; t_tab(339).backup_mail := ''; t_tab(339).wf_type := '1';
t_tab(340).resp_name := 'DSP CONC HOTELES PP CONSULTA'; t_tab(340).approver_name := 'mtrigo@despegar.com'; t_tab(340).backup_mail := ''; t_tab(340).wf_type := 'W';
t_tab(341).resp_name := 'DSP CONC HOTELES PP SUPERVISOR'; t_tab(341).approver_name := 'mtrigo@despegar.com'; t_tab(341).backup_mail := ''; t_tab(341).wf_type := 'W';
t_tab(342).resp_name := 'DSP CONC ONA PP ANALISTA'; t_tab(342).approver_name := 'emilia.lema@despegar.com'; t_tab(342).backup_mail := ''; t_tab(342).wf_type := 'W';
t_tab(343).resp_name := 'DSP CONC ONA PP SUPERVISOR'; t_tab(343).approver_name := 'emilia.lema@despegar.com'; t_tab(343).backup_mail := ''; t_tab(343).wf_type := 'W';
t_tab(344).resp_name := 'DSP CONC SKI CATEDRAL PP ANA'; t_tab(344).approver_name := ''; t_tab(344).backup_mail := ''; t_tab(344).wf_type := '1';
t_tab(345).resp_name := 'DSP CONC SKI CAVIAHUE PP ANA'; t_tab(345).approver_name := ''; t_tab(345).backup_mail := ''; t_tab(345).wf_type := '1';
t_tab(346).resp_name := 'DSP CONC SKI CHAPELCO PP ANA'; t_tab(346).approver_name := ''; t_tab(346).backup_mail := ''; t_tab(346).wf_type := '1';
t_tab(347).resp_name := 'DSP CONC SKI COLORADO PP ANA'; t_tab(347).approver_name := ''; t_tab(347).backup_mail := ''; t_tab(347).wf_type := '1';
t_tab(348).resp_name := 'DSP CONC SKI HOYA PP ANA'; t_tab(348).approver_name := ''; t_tab(348).backup_mail := ''; t_tab(348).wf_type := '1';
t_tab(349).resp_name := 'DSP CONC SKI PARVA PP ANA'; t_tab(349).approver_name := ''; t_tab(349).backup_mail := ''; t_tab(349).wf_type := '1';
t_tab(350).resp_name := 'DSP CONC SKI PP CONSULTA'; t_tab(350).approver_name := ''; t_tab(350).backup_mail := ''; t_tab(350).wf_type := '1';
t_tab(351).resp_name := 'DSP CONC TICKET PP CONSULTA'; t_tab(351).approver_name := ''; t_tab(351).backup_mail := ''; t_tab(351).wf_type := '1';
t_tab(352).resp_name := 'DSP CONC TICKET UNI PP ANA'; t_tab(352).approver_name := ''; t_tab(352).backup_mail := ''; t_tab(352).wf_type := '1';
t_tab(353).resp_name := 'DSP CONC TRASLADO GRAYLINE PP ANA'; t_tab(353).approver_name := ''; t_tab(353).backup_mail := ''; t_tab(353).wf_type := '1';
t_tab(354).resp_name := 'DSP CONC TRASLADO PP CONSULTA'; t_tab(354).approver_name := ''; t_tab(354).backup_mail := ''; t_tab(354).wf_type := '1';
t_tab(355).resp_name := 'DSP CR GL CONSULTAS CORP'; t_tab(355).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(355).backup_mail := ''; t_tab(355).wf_type := 'W';
t_tab(356).resp_name := 'DSP CR GL CONSULTAS USGAAP'; t_tab(356).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(356).backup_mail := ''; t_tab(356).wf_type := 'W';
t_tab(357).resp_name := 'DSP Desarrollador de Aplicaciones Consulta'; t_tab(357).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(357).backup_mail := ''; t_tab(357).wf_type := 'W';
t_tab(358).resp_name := 'DSP EC AP ABM BANCOS y CTAS BANCARIAS'; t_tab(358).approver_name := 'roman.richter@despegar.com'; t_tab(358).backup_mail := ''; t_tab(358).wf_type := 'W';
t_tab(359).resp_name := 'DSP EC AP ABM PROVEEDORES'; t_tab(359).approver_name := 'gbeloqui@despegar.com'; t_tab(359).backup_mail := ''; t_tab(359).wf_type := 'W';
t_tab(360).resp_name := 'DSP EC AP ANALISTA JR'; t_tab(360).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(360).backup_mail := 'florencia.hansen@despegar.com'; t_tab(360).wf_type := 'W';
t_tab(361).resp_name := 'DSP EC AP ANALISTA SR'; t_tab(361).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(361).backup_mail := 'florencia.hansen@despegar.com'; t_tab(361).wf_type := 'W';
t_tab(362).resp_name := 'DSP EC AP CONFIGURADOR'; t_tab(362).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(362).backup_mail := ''; t_tab(362).wf_type := 'W';
t_tab(363).resp_name := 'DSP EC AP CONSULTAS'; t_tab(363).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(363).backup_mail := 'florencia.hansen@despegar.com'; t_tab(363).wf_type := 'W';
t_tab(364).resp_name := 'DSP EC AP GERENTE'; t_tab(364).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(364).backup_mail := 'florencia.hansen@despegar.com'; t_tab(364).wf_type := 'W';
t_tab(365).resp_name := 'DSP EC AP SUPER USER'; t_tab(365).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(365).backup_mail := ''; t_tab(365).wf_type := 'W';
t_tab(366).resp_name := 'DSP EC AR ABM CLIENTES'; t_tab(366).approver_name := 'gbeloqui@despegar.com'; t_tab(366).backup_mail := ''; t_tab(366).wf_type := 'W';
t_tab(367).resp_name := 'DSP EC AR ANALISTA COBR'; t_tab(367).approver_name := 'edeluca@despegar.com'; t_tab(367).backup_mail := ''; t_tab(367).wf_type := 'W';
t_tab(368).resp_name := 'DSP EC AR ANALISTA COBR INTERCO'; t_tab(368).approver_name := 'edeluca@despegar.com'; t_tab(368).backup_mail := ''; t_tab(368).wf_type := 'W';
t_tab(369).resp_name := 'DSP EC AR ANALISTA FACT'; t_tab(369).approver_name := 'edeluca@despegar.com'; t_tab(369).backup_mail := ''; t_tab(369).wf_type := 'W';
t_tab(370).resp_name := 'DSP EC AR ANALISTA FACT INTERCO'; t_tab(370).approver_name := 'edeluca@despegar.com'; t_tab(370).backup_mail := ''; t_tab(370).wf_type := 'W';
t_tab(371).resp_name := 'DSP EC AR CONFIGURADOR'; t_tab(371).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(371).backup_mail := ''; t_tab(371).wf_type := 'W';
t_tab(372).resp_name := 'DSP EC AR CONSULTA'; t_tab(372).approver_name := 'edeluca@despegar.com'; t_tab(372).backup_mail := ''; t_tab(372).wf_type := 'W';
t_tab(373).resp_name := 'DSP EC AR SUPER USER'; t_tab(373).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(373).backup_mail := ''; t_tab(373).wf_type := 'W';
t_tab(374).resp_name := 'DSP EC AR SUPERV COBR'; t_tab(374).approver_name := 'edeluca@despegar.com'; t_tab(374).backup_mail := ''; t_tab(374).wf_type := 'W';
t_tab(375).resp_name := 'DSP EC AR SUPERV FACT'; t_tab(375).approver_name := 'edeluca@despegar.com'; t_tab(375).backup_mail := ''; t_tab(375).wf_type := 'W';
t_tab(376).resp_name := 'DSP EC CE CONCILIACIONES'; t_tab(376).approver_name := 'roman.richter@despegar.com'; t_tab(376).backup_mail := ''; t_tab(376).wf_type := 'W';
t_tab(377).resp_name := 'DSP EC CE CONFIGURADOR'; t_tab(377).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(377).backup_mail := ''; t_tab(377).wf_type := 'W';
t_tab(378).resp_name := 'DSP EC CE SUPER USER'; t_tab(378).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(378).backup_mail := ''; t_tab(378).wf_type := 'W';
t_tab(379).resp_name := 'DSP EC CE TESORERIA'; t_tab(379).approver_name := 'roman.richter@despegar.com'; t_tab(379).backup_mail := ''; t_tab(379).wf_type := 'W';
t_tab(380).resp_name := 'DSP EC CONC GUAY SUPERVISOR'; t_tab(380).approver_name := 'aasitimbay@despegar.com'; t_tab(380).backup_mail := ''; t_tab(380).wf_type := 'W';
t_tab(381).resp_name := 'DSP EC GL ANALISTA CORP'; t_tab(381).approver_name := 'gutierrezl@despegar.com'; t_tab(381).backup_mail := ''; t_tab(381).wf_type := 'W';
t_tab(382).resp_name := 'DSP EC GL ANALISTA INTERCO'; t_tab(382).approver_name := 'gutierrezl@despegar.com'; t_tab(382).backup_mail := ''; t_tab(382).wf_type := 'W';
t_tab(383).resp_name := 'DSP EC GL CONFIGURADOR'; t_tab(383).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(383).backup_mail := ''; t_tab(383).wf_type := 'W';
t_tab(384).resp_name := 'DSP EC GL CONSULTAS CORP'; t_tab(384).approver_name := 'gutierrezl@despegar.com'; t_tab(384).backup_mail := ''; t_tab(384).wf_type := 'W';
t_tab(385).resp_name := 'DSP EC GL CONSULTAS LOCAL'; t_tab(385).approver_name := 'gutierrezl@despegar.com'; t_tab(385).backup_mail := ''; t_tab(385).wf_type := 'W';
t_tab(386).resp_name := 'DSP EC GL CONSULTAS USGAAP'; t_tab(386).approver_name := 'gutierrezl@despegar.com'; t_tab(386).backup_mail := ''; t_tab(386).wf_type := 'W';
t_tab(387).resp_name := 'DSP EC GL GERENTE CORP'; t_tab(387).approver_name := 'gutierrezl@despegar.com'; t_tab(387).backup_mail := ''; t_tab(387).wf_type := 'W';
t_tab(388).resp_name := 'DSP EC GL REPORTES CORP'; t_tab(388).approver_name := 'gutierrezl@despegar.com'; t_tab(388).backup_mail := ''; t_tab(388).wf_type := 'W';
t_tab(389).resp_name := 'DSP EC GL REPORTES LOCAL'; t_tab(389).approver_name := 'gutierrezl@despegar.com'; t_tab(389).backup_mail := ''; t_tab(389).wf_type := 'W';
t_tab(390).resp_name := 'DSP EC GL SUPER USER'; t_tab(390).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(390).backup_mail := ''; t_tab(390).wf_type := 'W';
t_tab(391).resp_name := 'DSP EC OIE AUDITOR DE GASTOS'; t_tab(391).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(391).backup_mail := 'florencia.hansen@despegar.com'; t_tab(391).wf_type := 'W';
t_tab(392).resp_name := 'DSP EC OIE RENDICION DE GASTOS'; t_tab(392).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(392).backup_mail := 'florencia.hansen@despegar.com'; t_tab(392).wf_type := 'W';
t_tab(393).resp_name := 'DSP EC OM CONFIGURADOR'; t_tab(393).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(393).backup_mail := ''; t_tab(393).wf_type := 'W';
t_tab(394).resp_name := 'DSP EC OM CONSULTA'; t_tab(394).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(394).backup_mail := ''; t_tab(394).wf_type := 'W';
t_tab(395).resp_name := 'DSP EC OM SUPER USER'; t_tab(395).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(395).backup_mail := ''; t_tab(395).wf_type := 'W';
t_tab(396).resp_name := 'DSP EC OM SUPERV'; t_tab(396).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(396).backup_mail := ''; t_tab(396).wf_type := 'W';
t_tab(397).resp_name := 'DSP EC PO ADMINISTRADOR CONTABLE'; t_tab(397).approver_name := 'gutierrezl@despegar.com'; t_tab(397).backup_mail := ''; t_tab(397).wf_type := 'W';
t_tab(398).resp_name := 'DSP EC PO APROBADOR'; t_tab(398).approver_name := 'gutierrezl@despegar.com'; t_tab(398).backup_mail := ''; t_tab(398).wf_type := 'W';
t_tab(399).resp_name := 'DSP EC PO COMPRADOR NO TURISTICO'; t_tab(399).approver_name := 'gutierrezl@despegar.com'; t_tab(399).backup_mail := ''; t_tab(399).wf_type := 'W';
t_tab(400).resp_name := 'DSP EC PO CONFIG EMPLOYEES'; t_tab(400).approver_name := 'gutierrezl@despegar.com'; t_tab(400).backup_mail := ''; t_tab(400).wf_type := 'W';
t_tab(401).resp_name := 'DSP EC PO CONFIGURADOR'; t_tab(401).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(401).backup_mail := ''; t_tab(401).wf_type := 'W';
t_tab(402).resp_name := 'DSP EC PO CONSULTA'; t_tab(402).approver_name := 'gutierrezl@despegar.com'; t_tab(402).backup_mail := ''; t_tab(402).wf_type := 'W';
t_tab(403).resp_name := 'DSP EC PO RECEPCION'; t_tab(403).approver_name := 'gutierrezl@despegar.com'; t_tab(403).backup_mail := ''; t_tab(403).wf_type := 'W';
t_tab(404).resp_name := 'DSP EC PO SOLICITANTE DE COMPRA'; t_tab(404).approver_name := 'gutierrezl@despegar.com'; t_tab(404).backup_mail := ''; t_tab(404).wf_type := 'W';
t_tab(405).resp_name := 'DSP EC PO SUPER USER'; t_tab(405).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(405).backup_mail := ''; t_tab(405).wf_type := 'W';
t_tab(406).resp_name := 'DSP EC XX FLIGHTS CONSULTA'; t_tab(406).approver_name := 'ncabezas@despegar.com'; t_tab(406).backup_mail := ''; t_tab(406).wf_type := 'W';
t_tab(407).resp_name := 'DSP EC XX FLIGHTS SUPERVISOR'; t_tab(407).approver_name := 'ncabezas@despegar.com'; t_tab(407).backup_mail := ''; t_tab(407).wf_type := 'W';
t_tab(408).resp_name := 'DSP ES GL CONSULTAS CORP'; t_tab(408).approver_name := 'nlozza@despegar.com'; t_tab(408).backup_mail := ''; t_tab(408).wf_type := 'W';
t_tab(409).resp_name := 'DSP ES GL CONSULTAS USGAAP'; t_tab(409).approver_name := 'nlozza@despegar.com'; t_tab(409).backup_mail := ''; t_tab(409).wf_type := 'W';
t_tab(410).resp_name := 'DSP ES2 GL CONSULTAS CORP'; t_tab(410).approver_name := 'nlozza@despegar.com'; t_tab(410).backup_mail := ''; t_tab(410).wf_type := 'W';
t_tab(411).resp_name := 'DSP ES2 GL CONSULTAS USGAAP'; t_tab(411).approver_name := 'nlozza@despegar.com'; t_tab(411).backup_mail := ''; t_tab(411).wf_type := 'W';
t_tab(412).resp_name := 'DSP ES3 GL CONSULTAS CORP'; t_tab(412).approver_name := 'nlozza@despegar.com'; t_tab(412).backup_mail := ''; t_tab(412).wf_type := 'W';
t_tab(413).resp_name := 'DSP ES3 GL CONSULTAS USGAAP'; t_tab(413).approver_name := 'nlozza@despegar.com'; t_tab(413).backup_mail := ''; t_tab(413).wf_type := 'W';
t_tab(414).resp_name := 'DSP GL ADMINISTRADOR PDC'; t_tab(414).approver_name := 'gbeloqui@despegar.com'; t_tab(414).backup_mail := ''; t_tab(414).wf_type := 'W';
t_tab(415).resp_name := 'DSP GL ANALISTA CONSOLIDADO'; t_tab(415).approver_name := 'joalopez@despegar.com'; t_tab(415).backup_mail := ''; t_tab(415).wf_type := 'W';
t_tab(416).resp_name := 'DSP GL CONSULTAS CONSOLIDADO'; t_tab(416).approver_name := 'joalopez@despegar.com'; t_tab(416).backup_mail := ''; t_tab(416).wf_type := 'W';
t_tab(417).resp_name := 'DSP GL REPORTES CONSOLIDADO'; t_tab(417).approver_name := 'joalopez@despegar.com'; t_tab(417).backup_mail := ''; t_tab(417).wf_type := 'W';
t_tab(418).resp_name := 'DSP GL SUPER USER'; t_tab(418).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(418).backup_mail := ''; t_tab(418).wf_type := 'W';
t_tab(419).resp_name := 'DSP INV ABRIR PERIODOS CONTABLES'; t_tab(419).approver_name := 'joalopez@despegar.com'; t_tab(419).backup_mail := ''; t_tab(419).wf_type := 'W';
t_tab(420).resp_name := 'DSP INV ADM DE ITEMS'; t_tab(420).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(420).backup_mail := ''; t_tab(420).wf_type := 'W';
t_tab(421).resp_name := 'DSP INV CONFIGURADOR'; t_tab(421).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(421).backup_mail := ''; t_tab(421).wf_type := 'W';
t_tab(422).resp_name := 'DSP INV SUPER USER'; t_tab(422).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(422).backup_mail := ''; t_tab(422).wf_type := 'W';
t_tab(423).resp_name := 'DSP MX AP ABM BANCOS y CTAS BANCARIAS'; t_tab(423).approver_name := 'roman.richter@despegar.com'; t_tab(423).backup_mail := ''; t_tab(423).wf_type := 'W';
t_tab(424).resp_name := 'DSP MX AP ABM PROVEEDORES'; t_tab(424).approver_name := 'gbeloqui@despegar.com'; t_tab(424).backup_mail := ''; t_tab(424).wf_type := 'W';
t_tab(425).resp_name := 'DSP MX AP ANALISTA JR'; t_tab(425).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(425).backup_mail := 'florencia.hansen@despegar.com'; t_tab(425).wf_type := 'W';
t_tab(426).resp_name := 'DSP MX AP ANALISTA SR'; t_tab(426).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(426).backup_mail := 'florencia.hansen@despegar.com'; t_tab(426).wf_type := 'W';
t_tab(427).resp_name := 'DSP MX AP CONFIGURADOR'; t_tab(427).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(427).backup_mail := ''; t_tab(427).wf_type := 'W';
t_tab(428).resp_name := 'DSP MX AP CONSULTAS'; t_tab(428).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(428).backup_mail := 'florencia.hansen@despegar.com'; t_tab(428).wf_type := 'W';
t_tab(429).resp_name := 'DSP MX AP GERENTE'; t_tab(429).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(429).backup_mail := 'florencia.hansen@despegar.com'; t_tab(429).wf_type := 'W';
t_tab(430).resp_name := 'DSP MX AP SUPER USER'; t_tab(430).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(430).backup_mail := ''; t_tab(430).wf_type := 'W';
t_tab(431).resp_name := 'DSP MX AR ABM CLIENTES'; t_tab(431).approver_name := 'gbeloqui@despegar.com'; t_tab(431).backup_mail := ''; t_tab(431).wf_type := 'W';
t_tab(432).resp_name := 'DSP MX AR ANALISTA COBR'; t_tab(432).approver_name := 'edeluca@despegar.com'; t_tab(432).backup_mail := ''; t_tab(432).wf_type := 'W';
t_tab(433).resp_name := 'DSP MX AR ANALISTA COBR INTERCO'; t_tab(433).approver_name := 'edeluca@despegar.com'; t_tab(433).backup_mail := ''; t_tab(433).wf_type := 'W';
t_tab(434).resp_name := 'DSP MX AR ANALISTA FACT'; t_tab(434).approver_name := 'edeluca@despegar.com'; t_tab(434).backup_mail := ''; t_tab(434).wf_type := 'W';
t_tab(435).resp_name := 'DSP MX AR ANALISTA FACT INTERCO'; t_tab(435).approver_name := 'edeluca@despegar.com'; t_tab(435).backup_mail := ''; t_tab(435).wf_type := 'W';
t_tab(436).resp_name := 'DSP MX AR CONFIGURADOR'; t_tab(436).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(436).backup_mail := ''; t_tab(436).wf_type := 'W';
t_tab(437).resp_name := 'DSP MX AR CONSULTA'; t_tab(437).approver_name := 'edeluca@despegar.com'; t_tab(437).backup_mail := ''; t_tab(437).wf_type := 'W';
t_tab(438).resp_name := 'DSP MX AR SUPER USER'; t_tab(438).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(438).backup_mail := ''; t_tab(438).wf_type := 'W';
t_tab(439).resp_name := 'DSP MX AR SUPERV COBR'; t_tab(439).approver_name := 'edeluca@despegar.com'; t_tab(439).backup_mail := ''; t_tab(439).wf_type := 'W';
t_tab(440).resp_name := 'DSP MX AR SUPERV FACT'; t_tab(440).approver_name := 'edeluca@despegar.com'; t_tab(440).backup_mail := ''; t_tab(440).wf_type := 'W';
t_tab(441).resp_name := 'DSP MX CE CONCILIACIONES'; t_tab(441).approver_name := 'roman.richter@despegar.com'; t_tab(441).backup_mail := ''; t_tab(441).wf_type := 'W';
t_tab(442).resp_name := 'DSP MX CE CONFIGURADOR'; t_tab(442).approver_name := 'roman.richter@despegar.com'; t_tab(442).backup_mail := ''; t_tab(442).wf_type := 'W';
t_tab(443).resp_name := 'DSP MX CE SUPER USER'; t_tab(443).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(443).backup_mail := ''; t_tab(443).wf_type := 'W';
t_tab(444).resp_name := 'DSP MX CE TESORERIA'; t_tab(444).approver_name := 'roman.richter@despegar.com'; t_tab(444).backup_mail := ''; t_tab(444).wf_type := 'W';
t_tab(445).resp_name := 'DSP MX CONC ADQUIRA CONSULTA'; t_tab(445).approver_name := 'fpais@despegar.com'; t_tab(445).backup_mail := ''; t_tab(445).wf_type := 'W';
t_tab(446).resp_name := 'DSP MX CONC ADQUIRA SUPERVISOR'; t_tab(446).approver_name := 'fpais@despegar.com'; t_tab(446).backup_mail := ''; t_tab(446).wf_type := 'W';
t_tab(447).resp_name := 'DSP MX CONC AMEX CONSULTA'; t_tab(447).approver_name := 'fpais@despegar.com'; t_tab(447).backup_mail := ''; t_tab(447).wf_type := 'W';
t_tab(448).resp_name := 'DSP MX CONC AMEX SUPERVISOR'; t_tab(448).approver_name := 'fpais@despegar.com'; t_tab(448).backup_mail := ''; t_tab(448).wf_type := 'W';
t_tab(449).resp_name := 'DSP MX CONC BANORTE CONSULTA'; t_tab(449).approver_name := 'fpais@despegar.com'; t_tab(449).backup_mail := ''; t_tab(449).wf_type := 'W';
t_tab(450).resp_name := 'DSP MX CONC BANORTE SUPERVISOR'; t_tab(450).approver_name := 'fpais@despegar.com'; t_tab(450).backup_mail := ''; t_tab(450).wf_type := 'W';
t_tab(451).resp_name := 'DSP MX CONC PAYPAL SUPERVISOR'; t_tab(451).approver_name := 'fpais@despegar.com'; t_tab(451).backup_mail := ''; t_tab(451).wf_type := 'W';
t_tab(452).resp_name := 'DSP MX CONC SAFETYPAY CONSULTA'; t_tab(452).approver_name := 'fpais@despegar.com'; t_tab(452).backup_mail := ''; t_tab(452).wf_type := 'W';
t_tab(453).resp_name := 'DSP MX CONC SAFETYPAY SUPERVISOR'; t_tab(453).approver_name := 'fpais@despegar.com'; t_tab(453).backup_mail := ''; t_tab(453).wf_type := 'W';
t_tab(454).resp_name := 'DSP MX GL ANALISTA CORP'; t_tab(454).approver_name := 'andres.vecino@despegar.com'; t_tab(454).backup_mail := ''; t_tab(454).wf_type := 'W';
t_tab(455).resp_name := 'DSP MX GL ANALISTA INTERCO'; t_tab(455).approver_name := 'andres.vecino@despegar.com'; t_tab(455).backup_mail := ''; t_tab(455).wf_type := 'W';
t_tab(456).resp_name := 'DSP MX GL ANALISTAS INTERCO'; t_tab(456).approver_name := 'andres.vecino@despegar.com'; t_tab(456).backup_mail := ''; t_tab(456).wf_type := 'W';
t_tab(457).resp_name := 'DSP MX GL CONFIGURADOR'; t_tab(457).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(457).backup_mail := ''; t_tab(457).wf_type := 'W';
t_tab(458).resp_name := 'DSP MX GL CONSULTAS CORP'; t_tab(458).approver_name := 'andres.vecino@despegar.com'; t_tab(458).backup_mail := ''; t_tab(458).wf_type := 'W';
t_tab(459).resp_name := 'DSP MX GL GERENTE CORP'; t_tab(459).approver_name := 'andres.vecino@despegar.com'; t_tab(459).backup_mail := ''; t_tab(459).wf_type := 'W';
t_tab(460).resp_name := 'DSP MX GL MAPEO DE CUENTAS'; t_tab(460).approver_name := 'andres.vecino@despegar.com'; t_tab(460).backup_mail := ''; t_tab(460).wf_type := 'W';
t_tab(461).resp_name := 'DSP MX GL SUPER USER'; t_tab(461).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(461).backup_mail := ''; t_tab(461).wf_type := 'W';
t_tab(462).resp_name := 'DSP MX NOM GL CONSULTAS CORP'; t_tab(462).approver_name := 'andres.vecino@despegar.com'; t_tab(462).backup_mail := ''; t_tab(462).wf_type := 'W';
t_tab(463).resp_name := 'DSP MX NOM GL CONSULTAS USGAAP'; t_tab(463).approver_name := 'andres.vecino@despegar.com'; t_tab(463).backup_mail := ''; t_tab(463).wf_type := 'W';
t_tab(464).resp_name := 'DSP MX OM CONFIGURADOR'; t_tab(464).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(464).backup_mail := ''; t_tab(464).wf_type := 'W';
t_tab(465).resp_name := 'DSP MX OM CONSULTA'; t_tab(465).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(465).backup_mail := ''; t_tab(465).wf_type := 'W';
t_tab(466).resp_name := 'DSP MX OM SUPER USER'; t_tab(466).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(466).backup_mail := ''; t_tab(466).wf_type := 'W';
t_tab(467).resp_name := 'DSP MX OM SUPERV'; t_tab(467).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(467).backup_mail := ''; t_tab(467).wf_type := 'W';
t_tab(468).resp_name := 'DSP MX OPER GL ANALISTA CORP'; t_tab(468).approver_name := 'andres.vecino@despegar.com'; t_tab(468).backup_mail := ''; t_tab(468).wf_type := 'W';
t_tab(469).resp_name := 'DSP MX OPER GL CONSULTAS CORP'; t_tab(469).approver_name := 'andres.vecino@despegar.com'; t_tab(469).backup_mail := ''; t_tab(469).wf_type := 'W';
t_tab(470).resp_name := 'DSP MX OPER GL CONSULTAS USGAAP'; t_tab(470).approver_name := 'andres.vecino@despegar.com'; t_tab(470).backup_mail := ''; t_tab(470).wf_type := 'W';
t_tab(471).resp_name := 'DSP MX OPER GL GERENTE CORP'; t_tab(471).approver_name := 'andres.vecino@despegar.com'; t_tab(471).backup_mail := ''; t_tab(471).wf_type := 'W';
t_tab(472).resp_name := 'DSP MX PO ADMINISTRADOR CONTABLE'; t_tab(472).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(472).backup_mail := ''; t_tab(472).wf_type := 'W';
t_tab(473).resp_name := 'DSP MX PO APROBADOR'; t_tab(473).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(473).backup_mail := ''; t_tab(473).wf_type := 'W';
t_tab(474).resp_name := 'DSP MX PO COMPRADOR NO TURISTICO'; t_tab(474).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(474).backup_mail := ''; t_tab(474).wf_type := 'W';
t_tab(475).resp_name := 'DSP MX PO CONFIG EMPLOYEES'; t_tab(475).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(475).backup_mail := ''; t_tab(475).wf_type := 'W';
t_tab(476).resp_name := 'DSP MX PO CONFIGURADOR'; t_tab(476).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(476).backup_mail := ''; t_tab(476).wf_type := 'W';
t_tab(477).resp_name := 'DSP MX PO CONSULTA'; t_tab(477).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(477).backup_mail := ''; t_tab(477).wf_type := 'W';
t_tab(478).resp_name := 'DSP MX PO DESPACHOS MKT'; t_tab(478).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(478).backup_mail := ''; t_tab(478).wf_type := 'W';
t_tab(479).resp_name := 'DSP MX PO RECEPCION'; t_tab(479).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(479).backup_mail := ''; t_tab(479).wf_type := 'W';
t_tab(480).resp_name := 'DSP MX PO SOLICITANTE DE COMPRA'; t_tab(480).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(480).backup_mail := ''; t_tab(480).wf_type := 'W';
t_tab(481).resp_name := 'DSP MX PO SUPER USER'; t_tab(481).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(481).backup_mail := ''; t_tab(481).wf_type := 'W';
t_tab(482).resp_name := 'DSP MX SERV AP ABM PROVEEDORES'; t_tab(482).approver_name := 'gbeloqui@despegar.com'; t_tab(482).backup_mail := ''; t_tab(482).wf_type := 'W';
t_tab(483).resp_name := 'DSP MX SERV AP ANALISTA JR'; t_tab(483).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(483).backup_mail := 'florencia.hansen@despegar.com'; t_tab(483).wf_type := 'W';
t_tab(484).resp_name := 'DSP MX SERV AP ANALISTA SR'; t_tab(484).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(484).backup_mail := 'florencia.hansen@despegar.com'; t_tab(484).wf_type := 'W';
t_tab(485).resp_name := 'DSP MX SERV AP CONFIGURADOR'; t_tab(485).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(485).backup_mail := ''; t_tab(485).wf_type := 'W';
t_tab(486).resp_name := 'DSP MX SERV AP CONSULTAS'; t_tab(486).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(486).backup_mail := 'florencia.hansen@despegar.com'; t_tab(486).wf_type := 'W';
t_tab(487).resp_name := 'DSP MX SERV AP GERENTE'; t_tab(487).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(487).backup_mail := 'florencia.hansen@despegar.com'; t_tab(487).wf_type := 'W';
t_tab(488).resp_name := 'DSP MX SERV AP SUPER USER'; t_tab(488).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(488).backup_mail := ''; t_tab(488).wf_type := 'W';
t_tab(489).resp_name := 'DSP MX SERV AR ABM CLIENTES'; t_tab(489).approver_name := 'gbeloqui@despegar.com'; t_tab(489).backup_mail := ''; t_tab(489).wf_type := 'W';
t_tab(490).resp_name := 'DSP MX SERV AR CONFIGURADOR'; t_tab(490).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(490).backup_mail := ''; t_tab(490).wf_type := 'W';
t_tab(491).resp_name := 'DSP MX SERV AR SUPER USER'; t_tab(491).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(491).backup_mail := ''; t_tab(491).wf_type := 'W';
t_tab(492).resp_name := 'DSP MX SERV AR SUPERV COBR'; t_tab(492).approver_name := 'edeluca@despegar.com'; t_tab(492).backup_mail := ''; t_tab(492).wf_type := 'W';
t_tab(493).resp_name := 'DSP MX SERV AR SUPERV FACT'; t_tab(493).approver_name := 'edeluca@despegar.com'; t_tab(493).backup_mail := ''; t_tab(493).wf_type := 'W';
t_tab(494).resp_name := 'DSP MX SERV CE CONCILIACIONES'; t_tab(494).approver_name := 'roman.richter@despegar.com'; t_tab(494).backup_mail := ''; t_tab(494).wf_type := 'W';
t_tab(495).resp_name := 'DSP MX SERV CE CONFIGURADOR'; t_tab(495).approver_name := 'roman.richter@despegar.com'; t_tab(495).backup_mail := ''; t_tab(495).wf_type := 'W';
t_tab(496).resp_name := 'DSP MX SERV CE SUPER USER'; t_tab(496).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(496).backup_mail := ''; t_tab(496).wf_type := 'W';
t_tab(497).resp_name := 'DSP MX SERV GL ANALISTA CORP'; t_tab(497).approver_name := 'andres.vecino@despegar.com'; t_tab(497).backup_mail := ''; t_tab(497).wf_type := 'W';
t_tab(498).resp_name := 'DSP MX SERV GL CONFIGURADOR'; t_tab(498).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(498).backup_mail := ''; t_tab(498).wf_type := 'W';
t_tab(499).resp_name := 'DSP MX SERV GL CONSULTAS CORP'; t_tab(499).approver_name := 'andres.vecino@despegar.com'; t_tab(499).backup_mail := ''; t_tab(499).wf_type := 'W';
t_tab(500).resp_name := 'DSP MX SERV GL GERENTE CORP'; t_tab(500).approver_name := 'andres.vecino@despegar.com'; t_tab(500).backup_mail := ''; t_tab(500).wf_type := 'W';
t_tab(501).resp_name := 'DSP MX SERV GL SUPER USER'; t_tab(501).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(501).backup_mail := ''; t_tab(501).wf_type := 'W';
t_tab(502).resp_name := 'DSP MX SERV OIE AUDITOR DE GASTOS'; t_tab(502).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(502).backup_mail := 'florencia.hansen@despegar.com'; t_tab(502).wf_type := 'W';
t_tab(503).resp_name := 'DSP MX SERV OIE RENDICION DE GASTOS'; t_tab(503).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(503).backup_mail := 'florencia.hansen@despegar.com'; t_tab(503).wf_type := 'W';
t_tab(504).resp_name := 'DSP MX SERV PO ADMINISTRADOR CONTABLE'; t_tab(504).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(504).backup_mail := ''; t_tab(504).wf_type := 'W';
t_tab(505).resp_name := 'DSP MX SERV PO APROBADOR'; t_tab(505).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(505).backup_mail := ''; t_tab(505).wf_type := 'W';
t_tab(506).resp_name := 'DSP MX SERV PO COMPRADOR NO TURISTICO'; t_tab(506).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(506).backup_mail := ''; t_tab(506).wf_type := 'W';
t_tab(507).resp_name := 'DSP MX SERV PO CONFIGURADOR'; t_tab(507).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(507).backup_mail := ''; t_tab(507).wf_type := 'W';
t_tab(508).resp_name := 'DSP MX SERV PO CONSULTA'; t_tab(508).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(508).backup_mail := ''; t_tab(508).wf_type := 'W';
t_tab(509).resp_name := 'DSP MX SERV PO DESPACHOS MKT'; t_tab(509).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(509).backup_mail := ''; t_tab(509).wf_type := 'W';
t_tab(510).resp_name := 'DSP MX SERV PO RECEPCION'; t_tab(510).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(510).backup_mail := ''; t_tab(510).wf_type := 'W';
t_tab(511).resp_name := 'DSP MX SERV PO SOLICITANTE DE COMPRA'; t_tab(511).approver_name := 'mauricio.arroyo@despegar.com'; t_tab(511).backup_mail := ''; t_tab(511).wf_type := 'W';
t_tab(512).resp_name := 'DSP MX XX FLIGHTS ANALISTA'; t_tab(512).approver_name := 'ncabezas@despegar.com'; t_tab(512).backup_mail := ''; t_tab(512).wf_type := 'W';
t_tab(513).resp_name := 'DSP MX XX FLIGHTS CONSULTA'; t_tab(513).approver_name := 'ncabezas@despegar.com'; t_tab(513).backup_mail := ''; t_tab(513).wf_type := 'W';
t_tab(514).resp_name := 'DSP MX XX FLIGHTS SUPERVISOR'; t_tab(514).approver_name := 'ncabezas@despegar.com'; t_tab(514).backup_mail := ''; t_tab(514).wf_type := 'W';
t_tab(515).resp_name := 'DSP PA GL CONSULTAS CORP'; t_tab(515).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(515).backup_mail := ''; t_tab(515).wf_type := 'W';
t_tab(516).resp_name := 'DSP PA GL CONSULTAS USGAAP'; t_tab(516).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(516).backup_mail := ''; t_tab(516).wf_type := 'W';
t_tab(517).resp_name := 'DSP PE AP ABM BANCOS y CTAS BANCARIAS'; t_tab(517).approver_name := 'roman.richter@despegar.com'; t_tab(517).backup_mail := ''; t_tab(517).wf_type := 'W';
t_tab(518).resp_name := 'DSP PE AP ABM PROVEEDORES'; t_tab(518).approver_name := 'gbeloqui@despegar.com'; t_tab(518).backup_mail := ''; t_tab(518).wf_type := 'W';
t_tab(519).resp_name := 'DSP PE AP ANALISTA JR'; t_tab(519).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(519).backup_mail := 'florencia.hansen@despegar.com'; t_tab(519).wf_type := 'W';
t_tab(520).resp_name := 'DSP PE AP ANALISTA SR'; t_tab(520).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(520).backup_mail := 'florencia.hansen@despegar.com'; t_tab(520).wf_type := 'W';
t_tab(521).resp_name := 'DSP PE AP CONFIGURADOR'; t_tab(521).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(521).backup_mail := ''; t_tab(521).wf_type := 'W';
t_tab(522).resp_name := 'DSP PE AP CONSULTAS'; t_tab(522).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(522).backup_mail := 'florencia.hansen@despegar.com'; t_tab(522).wf_type := 'W';
t_tab(523).resp_name := 'DSP PE AP GERENTE'; t_tab(523).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(523).backup_mail := 'florencia.hansen@despegar.com'; t_tab(523).wf_type := 'W';
t_tab(524).resp_name := 'DSP PE AP SUPER USER'; t_tab(524).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(524).backup_mail := ''; t_tab(524).wf_type := 'W';
t_tab(525).resp_name := 'DSP PE AR ABM CLIENTES'; t_tab(525).approver_name := 'gbeloqui@despegar.com'; t_tab(525).backup_mail := ''; t_tab(525).wf_type := 'W';
t_tab(526).resp_name := 'DSP PE AR ANALISTA COBR'; t_tab(526).approver_name := 'edeluca@despegar.com'; t_tab(526).backup_mail := ''; t_tab(526).wf_type := 'W';
t_tab(527).resp_name := 'DSP PE AR ANALISTA COBR INTERCO'; t_tab(527).approver_name := 'edeluca@despegar.com'; t_tab(527).backup_mail := ''; t_tab(527).wf_type := 'W';
t_tab(528).resp_name := 'DSP PE AR ANALISTA FACT'; t_tab(528).approver_name := 'edeluca@despegar.com'; t_tab(528).backup_mail := ''; t_tab(528).wf_type := 'W';
t_tab(529).resp_name := 'DSP PE AR ANALISTA FACT INTERCO'; t_tab(529).approver_name := 'edeluca@despegar.com'; t_tab(529).backup_mail := ''; t_tab(529).wf_type := 'W';
t_tab(530).resp_name := 'DSP PE AR CONFIGURADOR'; t_tab(530).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(530).backup_mail := ''; t_tab(530).wf_type := 'W';
t_tab(531).resp_name := 'DSP PE AR CONSULTA'; t_tab(531).approver_name := 'edeluca@despegar.com'; t_tab(531).backup_mail := ''; t_tab(531).wf_type := 'W';
t_tab(532).resp_name := 'DSP PE AR SUPER USER'; t_tab(532).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(532).backup_mail := ''; t_tab(532).wf_type := 'W';
t_tab(533).resp_name := 'DSP PE AR SUPERV COBR'; t_tab(533).approver_name := 'edeluca@despegar.com'; t_tab(533).backup_mail := ''; t_tab(533).wf_type := 'W';
t_tab(534).resp_name := 'DSP PE AR SUPERV FACT'; t_tab(534).approver_name := 'edeluca@despegar.com'; t_tab(534).backup_mail := ''; t_tab(534).wf_type := 'W';
t_tab(535).resp_name := 'DSP PE CE CONCILIACIONES'; t_tab(535).approver_name := 'roman.richter@despegar.com'; t_tab(535).backup_mail := ''; t_tab(535).wf_type := 'W';
t_tab(536).resp_name := 'DSP PE CE CONFIGURADOR'; t_tab(536).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(536).backup_mail := ''; t_tab(536).wf_type := 'W';
t_tab(537).resp_name := 'DSP PE CE SUPER USER'; t_tab(537).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(537).backup_mail := ''; t_tab(537).wf_type := 'W';
t_tab(538).resp_name := 'DSP PE CE TESORERIA'; t_tab(538).approver_name := 'roman.richter@despegar.com'; t_tab(538).backup_mail := ''; t_tab(538).wf_type := 'W';
t_tab(539).resp_name := 'DSP PE CONC DINERS SUPERVISOR'; t_tab(539).approver_name := 'fpais@despegar.com'; t_tab(539).backup_mail := ''; t_tab(539).wf_type := 'W';
t_tab(540).resp_name := 'DSP PE CONC MCP SUPERVISOR'; t_tab(540).approver_name := 'fpais@despegar.com'; t_tab(540).backup_mail := ''; t_tab(540).wf_type := 'W';
t_tab(541).resp_name := 'DSP PE CONC SAFETY SUPERVISOR'; t_tab(541).approver_name := 'fpais@despegar.com'; t_tab(541).backup_mail := ''; t_tab(541).wf_type := 'W';
t_tab(542).resp_name := 'DSP PE CONC VNET SUPERVISOR'; t_tab(542).approver_name := 'fpais@despegar.com'; t_tab(542).backup_mail := ''; t_tab(542).wf_type := 'W';
t_tab(543).resp_name := 'DSP PE GL ANALISTA CORP'; t_tab(543).approver_name := 'andres.vecino@despegar.com'; t_tab(543).backup_mail := ''; t_tab(543).wf_type := 'W';
t_tab(544).resp_name := 'DSP PE GL ANALISTA INTERCO'; t_tab(544).approver_name := 'andres.vecino@despegar.com'; t_tab(544).backup_mail := ''; t_tab(544).wf_type := 'W';
t_tab(545).resp_name := 'DSP PE GL ANALISTA LOCAL'; t_tab(545).approver_name := 'andres.vecino@despegar.com'; t_tab(545).backup_mail := ''; t_tab(545).wf_type := 'W';
t_tab(546).resp_name := 'DSP PE GL ANALISTA USGAAP'; t_tab(546).approver_name := 'andres.vecino@despegar.com'; t_tab(546).backup_mail := ''; t_tab(546).wf_type := 'W';
t_tab(547).resp_name := 'DSP PE GL CONFIGURADOR'; t_tab(547).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(547).backup_mail := ''; t_tab(547).wf_type := 'W';
t_tab(548).resp_name := 'DSP PE GL CONSULTAS CORP'; t_tab(548).approver_name := 'andres.vecino@despegar.com'; t_tab(548).backup_mail := ''; t_tab(548).wf_type := 'W';
t_tab(549).resp_name := 'DSP PE GL CONSULTAS LOCAL'; t_tab(549).approver_name := 'andres.vecino@despegar.com'; t_tab(549).backup_mail := ''; t_tab(549).wf_type := 'W';
t_tab(550).resp_name := 'DSP PE GL CONSULTAS USGAAP'; t_tab(550).approver_name := 'andres.vecino@despegar.com'; t_tab(550).backup_mail := ''; t_tab(550).wf_type := 'W';
t_tab(551).resp_name := 'DSP PE GL GERENTE CORP'; t_tab(551).approver_name := 'andres.vecino@despegar.com'; t_tab(551).backup_mail := ''; t_tab(551).wf_type := 'W';
t_tab(552).resp_name := 'DSP PE GL GERENTE LOCAL'; t_tab(552).approver_name := 'andres.vecino@despegar.com'; t_tab(552).backup_mail := ''; t_tab(552).wf_type := 'W';
t_tab(553).resp_name := 'DSP PE GL GERENTE USGAAP'; t_tab(553).approver_name := 'andres.vecino@despegar.com'; t_tab(553).backup_mail := ''; t_tab(553).wf_type := 'W';
t_tab(554).resp_name := 'DSP PE GL SUPER USER'; t_tab(554).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(554).backup_mail := ''; t_tab(554).wf_type := 'W';
t_tab(555).resp_name := 'DSP PE OIE AUDITOR DE GASTOS'; t_tab(555).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(555).backup_mail := 'florencia.hansen@despegar.com'; t_tab(555).wf_type := 'W';
t_tab(556).resp_name := 'DSP PE OIE RENDICION DE GASTOS'; t_tab(556).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(556).backup_mail := 'florencia.hansen@despegar.com'; t_tab(556).wf_type := 'W';
t_tab(557).resp_name := 'DSP PE OM CONFIGURADOR'; t_tab(557).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(557).backup_mail := ''; t_tab(557).wf_type := 'W';
t_tab(558).resp_name := 'DSP PE OM CONSULTA'; t_tab(558).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(558).backup_mail := ''; t_tab(558).wf_type := 'W';
t_tab(559).resp_name := 'DSP PE OM SUPER USER'; t_tab(559).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(559).backup_mail := ''; t_tab(559).wf_type := 'W';
t_tab(560).resp_name := 'DSP PE OM SUPERV'; t_tab(560).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(560).backup_mail := ''; t_tab(560).wf_type := 'W';
t_tab(561).resp_name := 'DSP PE PO ADMINISTRADOR CONTABLE'; t_tab(561).approver_name := 'jpantoja@despegar.com'; t_tab(561).backup_mail := ''; t_tab(561).wf_type := 'W';
t_tab(562).resp_name := 'DSP PE PO COMPRADOR NO TURISTICO'; t_tab(562).approver_name := 'jpantoja@despegar.com'; t_tab(562).backup_mail := ''; t_tab(562).wf_type := 'W';
t_tab(563).resp_name := 'DSP PE PO CONFIG EMPLOYEES'; t_tab(563).approver_name := 'jpantoja@despegar.com'; t_tab(563).backup_mail := ''; t_tab(563).wf_type := 'W';
t_tab(564).resp_name := 'DSP PE PO CONFIGURADOR'; t_tab(564).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(564).backup_mail := ''; t_tab(564).wf_type := 'W';
t_tab(565).resp_name := 'DSP PE PO CONSULTA'; t_tab(565).approver_name := 'jpantoja@despegar.com'; t_tab(565).backup_mail := ''; t_tab(565).wf_type := 'W';
t_tab(566).resp_name := 'DSP PE PO RECEPCION'; t_tab(566).approver_name := 'jpantoja@despegar.com'; t_tab(566).backup_mail := ''; t_tab(566).wf_type := 'W';
t_tab(567).resp_name := 'DSP PE PO SOLICITANTE DE COMPRA'; t_tab(567).approver_name := 'jpantoja@despegar.com'; t_tab(567).backup_mail := ''; t_tab(567).wf_type := 'W';
t_tab(568).resp_name := 'DSP PE PO SUPER USER'; t_tab(568).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(568).backup_mail := ''; t_tab(568).wf_type := 'W';
t_tab(569).resp_name := 'DSP PE XX FLIGHTS CONSULTA'; t_tab(569).approver_name := 'ncabezas@despegar.com'; t_tab(569).backup_mail := ''; t_tab(569).wf_type := 'W';
t_tab(570).resp_name := 'DSP PE XX FLIGHTS SUPERVISOR'; t_tab(570).approver_name := 'ncabezas@despegar.com'; t_tab(570).backup_mail := ''; t_tab(570).wf_type := 'W';
t_tab(571).resp_name := 'DSP SYS Reportes Auditor�a'; t_tab(571).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(571).backup_mail := ''; t_tab(571).wf_type := 'W';
t_tab(572).resp_name := 'DSP UK BVI GL ANALISTA CORP'; t_tab(572).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(572).backup_mail := ''; t_tab(572).wf_type := 'W';
t_tab(573).resp_name := 'DSP UK BVI GL CONSULTAS CORP'; t_tab(573).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(573).backup_mail := ''; t_tab(573).wf_type := 'W';
t_tab(574).resp_name := 'DSP UK BVI GL GERENTE CORP'; t_tab(574).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(574).backup_mail := ''; t_tab(574).wf_type := 'W';
t_tab(575).resp_name := 'DSP US GL ANALISTA CORP'; t_tab(575).approver_name := 'albano.vespoli@despegar.com '; t_tab(575).backup_mail := ''; t_tab(575).wf_type := 'W';
t_tab(576).resp_name := 'DSP US GL CONSULTAS CORP'; t_tab(576).approver_name := 'albano.vespoli@despegar.com '; t_tab(576).backup_mail := ''; t_tab(576).wf_type := 'W';
t_tab(577).resp_name := 'DSP US GL CONSULTAS USGAAP'; t_tab(577).approver_name := 'albano.vespoli@despegar.com '; t_tab(577).backup_mail := ''; t_tab(577).wf_type := 'W';
t_tab(578).resp_name := 'DSP US GL GERENTE CORP'; t_tab(578).approver_name := 'albano.vespoli@despegar.com '; t_tab(578).backup_mail := ''; t_tab(578).wf_type := 'W';
t_tab(579).resp_name := 'DSP UY AP ABM BANCOS y CTAS BANCARIAS'; t_tab(579).approver_name := 'roman.richter@despegar.com'; t_tab(579).backup_mail := ''; t_tab(579).wf_type := 'W';
t_tab(580).resp_name := 'DSP UY AP ABM PROVEEDORES'; t_tab(580).approver_name := 'gbeloqui@despegar.com'; t_tab(580).backup_mail := ''; t_tab(580).wf_type := 'W';
t_tab(581).resp_name := 'DSP UY AP ANALISTA JR'; t_tab(581).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(581).backup_mail := 'florencia.hansen@despegar.com'; t_tab(581).wf_type := 'W';
t_tab(582).resp_name := 'DSP UY AP ANALISTA SR'; t_tab(582).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(582).backup_mail := 'florencia.hansen@despegar.com'; t_tab(582).wf_type := 'W';
t_tab(583).resp_name := 'DSP UY AP APROBADOR FC AME'; t_tab(583).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(583).backup_mail := 'florencia.hansen@despegar.com'; t_tab(583).wf_type := 'W';
t_tab(584).resp_name := 'DSP UY AP CONFIGURADOR'; t_tab(584).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(584).backup_mail := ''; t_tab(584).wf_type := 'W';
t_tab(585).resp_name := 'DSP UY AP CONSULTA'; t_tab(585).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(585).backup_mail := 'florencia.hansen@despegar.com'; t_tab(585).wf_type := 'W';
t_tab(586).resp_name := 'DSP UY AP GERENTE'; t_tab(586).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(586).backup_mail := 'florencia.hansen@despegar.com'; t_tab(586).wf_type := 'W';
t_tab(587).resp_name := 'DSP UY AP SUPER USER'; t_tab(587).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(587).backup_mail := ''; t_tab(587).wf_type := 'W';
t_tab(588).resp_name := 'DSP UY AR ABM CLIENTES'; t_tab(588).approver_name := 'gbeloqui@despegar.com'; t_tab(588).backup_mail := ''; t_tab(588).wf_type := 'W';
t_tab(589).resp_name := 'DSP UY AR ANALISTA COBR'; t_tab(589).approver_name := 'edeluca@despegar.com'; t_tab(589).backup_mail := ''; t_tab(589).wf_type := 'W';
t_tab(590).resp_name := 'DSP UY AR ANALISTA COBR INTERCO'; t_tab(590).approver_name := 'edeluca@despegar.com'; t_tab(590).backup_mail := ''; t_tab(590).wf_type := 'W';
t_tab(591).resp_name := 'DSP UY AR ANALISTA FACT'; t_tab(591).approver_name := 'edeluca@despegar.com'; t_tab(591).backup_mail := ''; t_tab(591).wf_type := 'W';
t_tab(592).resp_name := 'DSP UY AR ANALISTA FACT INTERCO'; t_tab(592).approver_name := 'edeluca@despegar.com'; t_tab(592).backup_mail := ''; t_tab(592).wf_type := 'W';
t_tab(593).resp_name := 'DSP UY AR CONFIGURADOR'; t_tab(593).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(593).backup_mail := ''; t_tab(593).wf_type := 'W';
t_tab(594).resp_name := 'DSP UY AR CONSULTA'; t_tab(594).approver_name := 'edeluca@despegar.com'; t_tab(594).backup_mail := ''; t_tab(594).wf_type := 'W';
t_tab(595).resp_name := 'DSP UY AR SUPERV COBR'; t_tab(595).approver_name := 'edeluca@despegar.com'; t_tab(595).backup_mail := ''; t_tab(595).wf_type := 'W';
t_tab(596).resp_name := 'DSP UY AR SUPERVISOR FACT'; t_tab(596).approver_name := 'edeluca@despegar.com'; t_tab(596).backup_mail := ''; t_tab(596).wf_type := 'W';
t_tab(597).resp_name := 'DSP UY CE CONCILIACIONES'; t_tab(597).approver_name := 'roman.richter@despegar.com'; t_tab(597).backup_mail := ''; t_tab(597).wf_type := 'W';
t_tab(598).resp_name := 'DSP UY CE CONFIGURADOR'; t_tab(598).approver_name := 'roman.richter@despegar.com'; t_tab(598).backup_mail := ''; t_tab(598).wf_type := 'W';
t_tab(599).resp_name := 'DSP UY CE CONSULTA'; t_tab(599).approver_name := 'roman.richter@despegar.com'; t_tab(599).backup_mail := ''; t_tab(599).wf_type := 'W';
t_tab(600).resp_name := 'DSP UY CE PRONOSTICOS'; t_tab(600).approver_name := 'roman.richter@despegar.com'; t_tab(600).backup_mail := ''; t_tab(600).wf_type := 'W';
t_tab(601).resp_name := 'DSP UY CE TESORERIA'; t_tab(601).approver_name := 'roman.richter@despegar.com'; t_tab(601).backup_mail := ''; t_tab(601).wf_type := 'W';
t_tab(602).resp_name := 'DSP UY CONC GC INT ANA'; t_tab(602).approver_name := ''; t_tab(602).backup_mail := ''; t_tab(602).wf_type := '1';
t_tab(603).resp_name := 'DSP UY CONC GC INT CONSULTA'; t_tab(603).approver_name := ''; t_tab(603).backup_mail := ''; t_tab(603).wf_type := '1';
t_tab(604).resp_name := 'DSP UY CONC GC INT SUPERVISOR'; t_tab(604).approver_name := ''; t_tab(604).backup_mail := ''; t_tab(604).wf_type := '1';
t_tab(605).resp_name := 'DSP UY CONC VCC ENETT ANA'; t_tab(605).approver_name := ''; t_tab(605).backup_mail := ''; t_tab(605).wf_type := '1';
t_tab(606).resp_name := 'DSP UY CONC VCC ENETT CONSULTA'; t_tab(606).approver_name := ''; t_tab(606).backup_mail := ''; t_tab(606).wf_type := '1';
t_tab(607).resp_name := 'DSP UY CONC VCC ENETT SUPERVISOR'; t_tab(607).approver_name := ''; t_tab(607).backup_mail := ''; t_tab(607).wf_type := '1';
t_tab(608).resp_name := 'DSP UY CONC VCC WEX ANA'; t_tab(608).approver_name := 'mtrigo@despegar.com'; t_tab(608).backup_mail := ''; t_tab(608).wf_type := 'W';
t_tab(609).resp_name := 'DSP UY CONC VCC WEX CONSULTA'; t_tab(609).approver_name := 'mtrigo@despegar.com'; t_tab(609).backup_mail := ''; t_tab(609).wf_type := 'W';
t_tab(610).resp_name := 'DSP UY CONC VCC WEX SUPERVISOR'; t_tab(610).approver_name := 'mtrigo@despegar.com'; t_tab(610).backup_mail := ''; t_tab(610).wf_type := 'W';
t_tab(611).resp_name := 'DSP UY CONC WPAY LOC ANA'; t_tab(611).approver_name := 'fpais@despegar.com'; t_tab(611).backup_mail := ''; t_tab(611).wf_type := 'W';
t_tab(612).resp_name := 'DSP UY CONC WPAY LOC CONSULTA'; t_tab(612).approver_name := 'fpais@despegar.com'; t_tab(612).backup_mail := ''; t_tab(612).wf_type := 'W';
t_tab(613).resp_name := 'DSP UY CONC WPAY SUPERVISOR'; t_tab(613).approver_name := 'fpais@despegar.com'; t_tab(613).backup_mail := ''; t_tab(613).wf_type := 'W';
t_tab(614).resp_name := 'DSP UY FA ANALISTA'; t_tab(614).approver_name := 'juahernandez@despegar.com'; t_tab(614).backup_mail := ''; t_tab(614).wf_type := 'W';
t_tab(615).resp_name := 'DSP UY FA CONFIGURADOR'; t_tab(615).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(615).backup_mail := ''; t_tab(615).wf_type := 'W';
t_tab(616).resp_name := 'DSP UY FA SUPER USER'; t_tab(616).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(616).backup_mail := ''; t_tab(616).wf_type := 'W';
t_tab(617).resp_name := 'DSP UY GL ANALISTA CORP'; t_tab(617).approver_name := 'idiez@despegar.com'; t_tab(617).backup_mail := ''; t_tab(617).wf_type := 'W';
t_tab(618).resp_name := 'DSP UY GL ANALISTA INTERCO'; t_tab(618).approver_name := 'idiez@despegar.com'; t_tab(618).backup_mail := ''; t_tab(618).wf_type := 'W';
t_tab(619).resp_name := 'DSP UY GL CONSULTAS CORP'; t_tab(619).approver_name := 'idiez@despegar.com'; t_tab(619).backup_mail := ''; t_tab(619).wf_type := 'W';
t_tab(620).resp_name := 'DSP UY GL CONSULTAS LOCAL'; t_tab(620).approver_name := 'idiez@despegar.com'; t_tab(620).backup_mail := ''; t_tab(620).wf_type := 'W';
t_tab(621).resp_name := 'DSP UY GL CONSULTAS USGAAP'; t_tab(621).approver_name := 'idiez@despegar.com'; t_tab(621).backup_mail := ''; t_tab(621).wf_type := 'W';
t_tab(622).resp_name := 'DSP UY GL GERENTE CORP'; t_tab(622).approver_name := 'idiez@despegar.com'; t_tab(622).backup_mail := ''; t_tab(622).wf_type := 'W';
t_tab(623).resp_name := 'DSP UY GL REPORTES CORP'; t_tab(623).approver_name := 'idiez@despegar.com'; t_tab(623).backup_mail := ''; t_tab(623).wf_type := 'W';
t_tab(624).resp_name := 'DSP UY GL REPORTES LOCAL'; t_tab(624).approver_name := 'idiez@despegar.com'; t_tab(624).backup_mail := ''; t_tab(624).wf_type := 'W';
t_tab(625).resp_name := 'DSP UY HLD GL ANALISTA CORP'; t_tab(625).approver_name := 'idiez@despegar.com'; t_tab(625).backup_mail := ''; t_tab(625).wf_type := 'W';
t_tab(626).resp_name := 'DSP UY HLD GL CONSULTAS CORP'; t_tab(626).approver_name := 'idiez@despegar.com'; t_tab(626).backup_mail := ''; t_tab(626).wf_type := 'W';
t_tab(627).resp_name := 'DSP UY HLD GL GERENTE CORP'; t_tab(627).approver_name := 'idiez@despegar.com'; t_tab(627).backup_mail := ''; t_tab(627).wf_type := 'W';
t_tab(628).resp_name := 'DSP UY OIE AUDITOR DE GASTOS'; t_tab(628).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(628).backup_mail := 'florencia.hansen@despegar.com'; t_tab(628).wf_type := 'W';
t_tab(629).resp_name := 'DSP UY OIE RENDICION DE GASTOS'; t_tab(629).approver_name := 'vanesa.llamedo@despegar.com'; t_tab(629).backup_mail := 'florencia.hansen@despegar.com'; t_tab(629).wf_type := 'W';
t_tab(630).resp_name := 'DSP UY OM CONSULTA'; t_tab(630).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(630).backup_mail := ''; t_tab(630).wf_type := 'W';
t_tab(631).resp_name := 'DSP UY OM PEDIDOS VENTA'; t_tab(631).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(631).backup_mail := ''; t_tab(631).wf_type := 'W';
t_tab(632).resp_name := 'DSP UY OM SUPERV'; t_tab(632).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(632).backup_mail := ''; t_tab(632).wf_type := 'W';
t_tab(633).resp_name := 'DSP UY OPER AR SUPER USER'; t_tab(633).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(633).backup_mail := ''; t_tab(633).wf_type := 'W';
t_tab(634).resp_name := 'DSP UY OPER CE SUPER USER'; t_tab(634).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(634).backup_mail := ''; t_tab(634).wf_type := 'W';
t_tab(635).resp_name := 'DSP UY OPER GL ANALISTA CORP'; t_tab(635).approver_name := 'idiez@despegar.com'; t_tab(635).backup_mail := ''; t_tab(635).wf_type := 'W';
t_tab(636).resp_name := 'DSP UY OPER GL CONFIGURADOR'; t_tab(636).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(636).backup_mail := ''; t_tab(636).wf_type := 'W';
t_tab(637).resp_name := 'DSP UY OPER GL CONSULTAS CORP'; t_tab(637).approver_name := 'idiez@despegar.com'; t_tab(637).backup_mail := ''; t_tab(637).wf_type := 'W';
t_tab(638).resp_name := 'DSP UY OPER GL CONSULTAS USGAAP'; t_tab(638).approver_name := 'idiez@despegar.com'; t_tab(638).backup_mail := ''; t_tab(638).wf_type := 'W';
t_tab(639).resp_name := 'DSP UY OPER GL GERENTE CORP'; t_tab(639).approver_name := 'idiez@despegar.com'; t_tab(639).backup_mail := ''; t_tab(639).wf_type := 'W';
t_tab(640).resp_name := 'DSP UY OPER GL SUPER USER'; t_tab(640).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(640).backup_mail := ''; t_tab(640).wf_type := 'W';
t_tab(641).resp_name := 'DSP UY OPER OM CONFIGURADOR'; t_tab(641).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(641).backup_mail := ''; t_tab(641).wf_type := 'W';
t_tab(642).resp_name := 'DSP UY OPER OM SUPER USER'; t_tab(642).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(642).backup_mail := ''; t_tab(642).wf_type := 'W';
t_tab(643).resp_name := 'DSP UY PO ADMINISTRADOR CONTABLE'; t_tab(643).approver_name := 'rocastro@despegar.com'; t_tab(643).backup_mail := ''; t_tab(643).wf_type := 'W';
t_tab(644).resp_name := 'DSP UY PO APROBADOR'; t_tab(644).approver_name := 'rocastro@despegar.com'; t_tab(644).backup_mail := ''; t_tab(644).wf_type := 'W';
t_tab(645).resp_name := 'DSP UY PO COMPRADOR NO TURISTICO'; t_tab(645).approver_name := 'rocastro@despegar.com'; t_tab(645).backup_mail := ''; t_tab(645).wf_type := 'W';
t_tab(646).resp_name := 'DSP UY PO CONFIG EMPLOYEES'; t_tab(646).approver_name := 'rocastro@despegar.com'; t_tab(646).backup_mail := ''; t_tab(646).wf_type := 'W';
t_tab(647).resp_name := 'DSP UY PO CONFIGURADOR'; t_tab(647).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(647).backup_mail := ''; t_tab(647).wf_type := 'W';
t_tab(648).resp_name := 'DSP UY PO CONFIGURADOR JERARQUIA'; t_tab(648).approver_name := 'rocastro@despegar.com'; t_tab(648).backup_mail := ''; t_tab(648).wf_type := 'W';
t_tab(649).resp_name := 'DSP UY PO CONSULTA'; t_tab(649).approver_name := 'rocastro@despegar.com'; t_tab(649).backup_mail := ''; t_tab(649).wf_type := 'W';
t_tab(650).resp_name := 'DSP UY PO DESPACHOS MKT'; t_tab(650).approver_name := 'rocastro@despegar.com'; t_tab(650).backup_mail := ''; t_tab(650).wf_type := 'W';
t_tab(651).resp_name := 'DSP UY PO RECEPCION'; t_tab(651).approver_name := 'rocastro@despegar.com'; t_tab(651).backup_mail := ''; t_tab(651).wf_type := 'W';
t_tab(652).resp_name := 'DSP UY PO SOLICITANTE DE COMPRA'; t_tab(652).approver_name := 'rocastro@despegar.com'; t_tab(652).backup_mail := ''; t_tab(652).wf_type := 'W';
t_tab(653).resp_name := 'DSP UY PO SUPERUSER'; t_tab(653).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(653).backup_mail := ''; t_tab(653).wf_type := 'W';
t_tab(654).resp_name := 'DSP VE GL CONSULTAS AXI'; t_tab(654).approver_name := 'nlozza@despegar.com'; t_tab(654).backup_mail := ''; t_tab(654).wf_type := 'W';
t_tab(655).resp_name := 'DSP VE GL CONSULTAS CORP'; t_tab(655).approver_name := 'nlozza@despegar.com'; t_tab(655).backup_mail := ''; t_tab(655).wf_type := 'W';
t_tab(656).resp_name := 'DSP VE GL CONSULTAS LOCAL'; t_tab(656).approver_name := 'nlozza@despegar.com'; t_tab(656).backup_mail := ''; t_tab(656).wf_type := 'W';
t_tab(657).resp_name := 'DSP VE GL CONSULTAS USGAAP'; t_tab(657).approver_name := 'nlozza@despegar.com'; t_tab(657).backup_mail := ''; t_tab(657).wf_type := 'W';
t_tab(658).resp_name := 'DSP VE SOL GL ANALISTA CORP'; t_tab(658).approver_name := 'nlozza@despegar.com'; t_tab(658).backup_mail := ''; t_tab(658).wf_type := 'W';
t_tab(659).resp_name := 'DSP VE SOL GL CONSULTAS CORP'; t_tab(659).approver_name := 'nlozza@despegar.com'; t_tab(659).backup_mail := ''; t_tab(659).wf_type := 'W';
t_tab(660).resp_name := 'DSP VE SOL GL CONSULTAS USGAAP'; t_tab(660).approver_name := 'nlozza@despegar.com'; t_tab(660).backup_mail := ''; t_tab(660).wf_type := 'W';
t_tab(661).resp_name := 'DSP VE SOL GL GERENTE CORP'; t_tab(661).approver_name := 'nlozza@despegar.com'; t_tab(661).backup_mail := ''; t_tab(661).wf_type := 'W';
t_tab(662).resp_name := 'Gerente de Auditor�a'; t_tab(662).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(662).backup_mail := ''; t_tab(662).wf_type := 'W';
t_tab(663).resp_name := 'Gerente de Ventas de Cotizaci�n'; t_tab(663).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(663).backup_mail := ''; t_tab(663).wf_type := 'W';
t_tab(664).resp_name := 'Human Resources Intelligence - Administrador (OLTP)'; t_tab(664).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(664).backup_mail := ''; t_tab(664).wf_type := 'W';
t_tab(665).resp_name := 'INC US GL ANALISTA CORP'; t_tab(665).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(665).backup_mail := ''; t_tab(665).wf_type := 'W';
t_tab(666).resp_name := 'INC US GL ANALISTA LOCAL'; t_tab(666).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(666).backup_mail := ''; t_tab(666).wf_type := 'W';
t_tab(667).resp_name := 'INC US GL ANALISTA USGAAP'; t_tab(667).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(667).backup_mail := ''; t_tab(667).wf_type := 'W';
t_tab(668).resp_name := 'INC US GL CONSULTAS CORP'; t_tab(668).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(668).backup_mail := ''; t_tab(668).wf_type := 'W';
t_tab(669).resp_name := 'INC US GL CONSULTAS LOCAL'; t_tab(669).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(669).backup_mail := ''; t_tab(669).wf_type := 'W';
t_tab(670).resp_name := 'INC US GL CONSULTAS USGAAP'; t_tab(670).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(670).backup_mail := ''; t_tab(670).wf_type := 'W';
t_tab(671).resp_name := 'INC US GL GERENTE CORP'; t_tab(671).approver_name := 'carolina.rodrigues@despegar.com'; t_tab(671).backup_mail := ''; t_tab(671).wf_type := 'W';
t_tab(672).resp_name := 'Integrated SOA Gateway'; t_tab(672).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(672).backup_mail := ''; t_tab(672).wf_type := 'W';
t_tab(673).resp_name := 'LAINC AR GL CONSULTAS CORP'; t_tab(673).approver_name := ''; t_tab(673).backup_mail := ''; t_tab(673).wf_type := '1';
t_tab(674).resp_name := 'ORDER MANAGEMENT de Argentina'; t_tab(674).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(674).backup_mail := ''; t_tab(674).wf_type := 'W';
t_tab(675).resp_name := 'SATYLCA UY GL ANALISTA CORP'; t_tab(675).approver_name := 'ldippolito@despegar.com'; t_tab(675).backup_mail := ''; t_tab(675).wf_type := 'W';
t_tab(676).resp_name := 'SATYLCA UY GL ANALISTA USGAAP'; t_tab(676).approver_name := 'ldippolito@despegar.com'; t_tab(676).backup_mail := ''; t_tab(676).wf_type := 'W';
t_tab(677).resp_name := 'SATYLCA UY GL CONSULTAS CORP'; t_tab(677).approver_name := 'ldippolito@despegar.com'; t_tab(677).backup_mail := ''; t_tab(677).wf_type := 'W';
t_tab(678).resp_name := 'SATYLCA UY GL CONSULTAS USGAAP'; t_tab(678).approver_name := 'ldippolito@despegar.com'; t_tab(678).backup_mail := ''; t_tab(678).wf_type := 'W';
t_tab(679).resp_name := 'SATYLCA UY GL GERENTE CORP'; t_tab(679).approver_name := 'ldippolito@despegar.com'; t_tab(679).backup_mail := ''; t_tab(679).wf_type := 'W';
t_tab(680).resp_name := 'SSWA de Preferencias'; t_tab(680).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(680).backup_mail := ''; t_tab(680).wf_type := 'W';
t_tab(681).resp_name := 'TECNO UY GL CONSULTAS CORP'; t_tab(681).approver_name := 'ldippolito@despegar.com'; t_tab(681).backup_mail := ''; t_tab(681).wf_type := 'W';
t_tab(682).resp_name := 'TECNO UY GL CONSULTAS USGAAP'; t_tab(682).approver_name := 'ldippolito@despegar.com'; t_tab(682).backup_mail := ''; t_tab(682).wf_type := 'W';
t_tab(683).resp_name := 'USER MANAGEMENT'; t_tab(683).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(683).backup_mail := ''; t_tab(683).wf_type := 'W';
t_tab(684).resp_name := 'Web Applications de Administrador de Workflow'; t_tab(684).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(684).backup_mail := ''; t_tab(684).wf_type := 'W';
t_tab(685).resp_name := 'Web Applications Usuario Workflow'; t_tab(685).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(685).backup_mail := ''; t_tab(685).wf_type := 'W';
t_tab(686).resp_name := 'Web de Administrador de Workflow (Nuevo)'; t_tab(686).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(686).backup_mail := ''; t_tab(686).wf_type := 'W';
t_tab(687).resp_name := 'XX Customizaciones'; t_tab(687).approver_name := 'daniel.vartabedian@despegar.com'; t_tab(687).backup_mail := ''; t_tab(687).wf_type := 'W';
  DBMS_OUTPUT.PUT_LINE('- Carga tabla');
  -- ---------------------------------------------------------------------------
  -- Recorro la tabla.
  -- ---------------------------------------------------------------------------
  DBMS_OUTPUT.PUT_LINE('+ APPROVERS');
  i := t_tab.FIRST;
  LOOP
--    DBMS_OUTPUT.PUT_LINE('i = '||i||); --' - app_mail = '||t_tab(i).approver_name);
    IF NVL(t_tab(i).approver_name,'') = '' THEN
       DBMS_OUTPUT.PUT_LINE('NO tiene mail - NO lo proceso');
    ELSE
       BEGIN
         SELECT COUNT(1)
           INTO l_existe
           FROM xx_sod_approvers
          WHERE person_id = (SELECT person_id 
                               FROM per_people_f 
                              WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(t_tab(i).approver_name)) AND SYSDATE BETWEEN effective_start_date AND effective_end_date
                                AND (UPPER(full_name) NOT LIKE '%FONDO%' AND UPPER(full_name) NOT LIKE '%FUNDO%'));
       EXCEPTION
         WHEN others THEN
              l_existe := -1;
              DBMS_OUTPUT.PUT_LINE('ERROR al buscar si existe el aprobador: '||t_tab(i).approver_name||' en la ocurrencia: '||i||'; '||SQLERRM);
       END;
       IF l_existe = 0 THEN
          DBMS_OUTPUT.PUT_LINE('approver_name = '||t_tab(i).approver_name||' - backup_mail = '||t_tab(i).backup_mail);
          BEGIN
            SELECT person_id
              INTO l_person_id
              FROM per_people_f
             WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(t_tab(i).approver_name)) AND SYSDATE BETWEEN effective_start_date AND effective_end_date
               AND (UPPER(full_name) NOT LIKE '%FONDO%' AND UPPER(full_name) NOT LIKE '%FUNDO%');
          EXCEPTION
            WHEN no_data_found THEN
                 DBMS_OUTPUT.PUT_LINE('El email: '||t_tab(i).approver_name||' no se encontr�.');
                 l_person_id := TO_NUMBER(NULL);
            WHEN others THEN
                 DBMS_OUTPUT.PUT_LINE('ERROR al buscar el person_id para el email: '||t_tab(i).approver_name||'; '||SQLERRM);
                 l_person_id := TO_NUMBER(NULL);
          END;
          --
          BEGIN
            SELECT person_id
              INTO l_backup_id
              FROM per_people_f
             WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(t_tab(i).backup_mail)) AND SYSDATE BETWEEN effective_start_date AND effective_end_date
               AND (UPPER(full_name) NOT LIKE '%FONDO%' AND UPPER(full_name) NOT LIKE '%FUNDO%');
          EXCEPTION
            WHEN no_data_found THEN
                 DBMS_OUTPUT.PUT_LINE('El email: '||t_tab(i).backup_mail||' no se encontr�.');
                 l_backup_id := 2863; --> 'Daniel Vartabedian'
            WHEN others THEN
                 DBMS_OUTPUT.PUT_LINE('ERROR al buscar el person_id para el email: '||t_tab(i).backup_mail||'; '||SQLERRM);
                 l_backup_id := TO_NUMBER(NULL);
          END;
          --
          DBMS_OUTPUT.PUT_LINE('i = '||i||' - person_id = '||l_person_id||' - backup_id = '||l_backup_id);
          IF NVL(l_person_id,0) <> 0 THEN
             DBMS_OUTPUT.PUT_LINE('i = '||i||' - '||t_tab(i).resp_name||' - '||t_tab(i).approver_name||' - '||NVL(t_tab(i).backup_mail,'NULL'));
             SELECT NVL(MAX(approver_id),0)+1
               INTO l_id
               FROM xx_sod_approvers;
             --
             BEGIN
               INSERT INTO xx_sod_approvers
                         ( approver_id
                          ,person_id
                          ,backup_person_id
                          ,backup_from_date
                          ,backup_to_date
                          ,second_person_id
                          ,enabled_flag
                          ,creation_date
                          ,created_by
                          ,last_update_date
                          ,last_updated_by )
                  VALUES ( l_id
                          ,l_person_id
                          ,l_backup_id
                          ,NULL
                          ,NULL
                          ,NULL
                          ,'Y'
                          ,SYSDATE
                          ,fnd_global.user_id
                          ,SYSDATE
                          ,fnd_global.user_id );
                l_k := l_k + 1;
             EXCEPTION
               WHEN others THEN
                    DBMS_OUTPUT.PUT_LINE('ERROR al grabar xx_sod_approvers; '||SQLERRM);
             END;
             --
          END IF;
       END IF;
    END IF;
    --
    i := t_tab.NEXT(i);
    EXIT WHEN i IS NULL;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('- APPROVERS');
  DBMS_OUTPUT.PUT_LINE('  Se dieron de alta '||NVL(l_k,0)||' aprobadores.');
  --
  DBMS_OUTPUT.PUT_LINE('+ ROLES');
  i := t_tab.FIRST;
  l_k := 0;
  LOOP
    DBMS_OUTPUT.PUT_LINE('i = '||i); --||' - '||t_tab(i).resp_name||' - '||t_tab(i).approver_name);
    -- Recupero datos de la respo, pero tomo los datos en ingl�s (el array informa respos en espa�ol).
    BEGIN
      SELECT fri.responsibility_name, fri.description, fri.responsibility_id
        INTO l_resp_name, l_resp_description, l_resp_id
        FROM fnd_responsibility_tl  fri
            ,fnd_responsibility_tl  frs
       WHERE UPPER(TRIM(frs.responsibility_name)) = UPPER(TRIM(t_tab(i).resp_name))
         AND frs.LANGUAGE = 'ESA'
         AND fri.responsibility_id = frs.responsibility_id
         AND fri.LANGUAGE = 'US';
    EXCEPTION
      WHEN OTHERS THEN
           l_resp_name := NULL;
           l_resp_description := NULL;
           l_resp_id := NULL;
           DBMS_OUTPUT.PUT_LINE('ERROR al buscar la respo: '||t_tab(i).resp_name||' con aprobador: '||t_tab(i).approver_name||'; '||SQLERRM);
    END;
    -- Busco el approver_id del mail que viene en el array.
    BEGIN
      SELECT ap.approver_id
        INTO l_approver_id
        FROM per_people_f     pp
            ,xx_sod_approvers ap
       WHERE 1=1
         AND LOWER(TRIM(pp.email_address)) = LOWER(TRIM(t_tab(i).approver_name)) 
         AND SYSDATE BETWEEN pp.effective_start_date AND pp.effective_end_date
         AND ap.person_id = pp.person_id;
    EXCEPTION
      WHEN no_data_found THEN
           l_approver_id := NULL;
           DBMS_OUTPUT.PUT_LINE('NO se encontr� el aprobador para el mail: '||t_tab(i).approver_name);
      WHEN too_many_rows THEN
           l_approver_id := NULL;
           DBMS_OUTPUT.PUT_LINE('Hay m�s de 1 ocurrencia de aprobador para el mail: '||t_tab(i).approver_name);
      WHEN others THEN
           l_approver_id := NULL;
           DBMS_OUTPUT.PUT_LINE('ERROR al buscar el approbador para el mail: '||t_tab(i).approver_name||'; '||SQLERRM);
    END;
    --
--    IF NVL(l_approver_id,0) > 0 AND NVL(l_resp_id,0) > 0 THEN 
    IF NVL(l_resp_id,0) > 0 THEN 
       BEGIN
         SELECT NVL(MAX(role_id),0)+1
           INTO l_id
           FROM xx_sod_roles;
         --
         INSERT INTO xx_sod_roles
                   ( appl_id
                    ,role_id
                    ,role_name 
                    ,role_description
                    ,original_role_id
                    ,approval_type
                    ,approver_id
                    ,enabled_flag
                    ,creation_date
                    ,created_by
                    ,last_update_date
                    ,last_updated_by )
            VALUES ( 1
                    ,l_id
                    ,l_resp_name
                    ,l_resp_description
                    ,l_resp_id
                    ,DECODE( t_tab(i).wf_type, 'W', 'W', DECODE( t_tab(i).wf_type, '1', 'R', 'A' ) )
                    ,l_approver_id
                    ,'Y'
                    ,SYSDATE
                    ,fnd_global.user_id
                    ,SYSDATE
                    ,fnd_global.user_id );
           l_k := l_k + 1;
       EXCEPTION
         WHEN OTHERS THEN
              DBMS_OUTPUT.PUT_LINE('ERROR al grabar xx_sod_roles para la respo: '||t_tab(i).resp_name||' DEL aprobador: '||t_tab(i).approver_name||'; '||SQLERRM);
              RAISE_APPLICATION_ERROR(-20001,'ERROR al grabar xx_sod_roles para la respo: '||t_tab(i).resp_name||' DEL aprobador: '||t_tab(i).approver_name||'; '||SQLERRM);
       END;
    END IF;
    --
    i := t_tab.NEXT(i);
    EXIT WHEN i IS NULL;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('- ROLES');
  DBMS_OUTPUT.PUT_LINE('Se dieron de alta '||l_k||' respos.');
  --------
  COMMIT;
  --------
  DBMS_OUTPUT.PUT_LINE('*** FIN ***');
END;
/

SHOW ERRORS

SPOOL OFF

EXIT
