SPOOL xx_idmb_pk.log

PROMPT =====================================================================
PROMPT Script xx_idmb_pk.sql - Body de package xx_idm_pkg
PROMPT =====================================================================

CREATE OR REPLACE PACKAGE BODY APPS.xx_idm_pkg AS
/* $Id: XX_IDM_PKG.sql 1 2018-08-09 12:07:11Z seguridad informatica $ */

--******************************************************************************\
-- Name   : get_user_id
-- Purpose: Valida si un usuario esta activo y devuelve el User_Id.
-- Params : p_email_address: direccion de email del usuario
-- Notes  :   
-- History: 21/09/2018  DVartabedian  Created
--
--******************************************************************************/
FUNCTION get_user_id( p_email_address  IN VARCHAR2
                     ,x_user_name     OUT VARCHAR2
                     ,x_errmsg        OUT VARCHAR2 ) RETURN NUMBER
IS
  -- Variables
  l_procname            VARCHAR2(70) := c_procname||'.GET_USER_ID';
  l_user_id             fnd_user.user_id%TYPE;
  l_user_name           fnd_user.user_name%TYPE;
  l_end_date            fnd_responsibility_vl.end_date%TYPE;
  l_errmsg              VARCHAR2(2000);
  e_error               EXCEPTION;
BEGIN
  print_log('  + '||l_procname);
  IF p_email_address IS NULL THEN
     l_errmsg := 'eMail vacio - Proceso Cancelado';
     RAISE e_error;
  ELSE
     BEGIN
       SELECT user_id, user_name, end_date
         INTO l_user_id, l_user_name, l_end_date
         FROM fnd_user 
        WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(p_email_address));
     EXCEPTION
       WHEN no_data_found THEN
            l_errmsg := 'Usuario Inexistente - Proceso Cancelado';
            RAISE e_error;
       WHEN others THEN
            l_errmsg := 'Error al buscar el User_Name; '||SQLERRM;
            RAISE e_error;
     END;
     print_log('  User_Name = '||l_user_name||'; User_Id = '||l_user_id||'; End_Date = '||NVL(TO_CHAR(l_end_date,'dd/mm/yyyy'),'(NULL)'));
     --
     IF NVL(l_end_date,SYSDATE) <= TRUNC(SYSDATE) THEN
        l_errmsg := 'El usuario '||l_user_name||' se encuentra dado de baja (fecha de baja: '||TO_CHAR(l_end_date,'dd/mm/yyyy')||') - Proceso Cancelado';
        RAISE e_error;
     END IF;
  END IF;
  print_log('  - '||l_procname);
  --
  x_user_name := l_user_name;
  RETURN( l_user_id );
EXCEPTION
  WHEN e_error THEN
       x_errmsg := l_errmsg;
       print_log(l_errmsg);
       RETURN( TO_NUMBER(NULL) );
  WHEN others THEN
       x_errmsg := NVL(l_errmsg,'')||' ERROR General en '||l_procname||'; '||SQLERRM;
       print_log(x_errmsg);
       RETURN( TO_NUMBER(NULL) );
END get_user_id;

--******************************************************************************\
-- Name   : get_resp_id
-- Purpose: Valida si una respo existe y devuelve el Responsibility_Id.
-- Params : p_resp_name: Responsibility_Name
-- Notes  :   
-- History: 21/09/2018  DVartabedian  Created
--
--******************************************************************************/
FUNCTION get_resp_id( p_resp_name  IN VARCHAR2
                     ,x_errmsg    OUT VARCHAR2 ) RETURN NUMBER
IS
  -- Variables
  l_procname            VARCHAR2(70) := c_procname||'.GET_RESP_ID';
  l_resp_id             fnd_responsibility_vl.responsibility_id%TYPE;
  l_end_date            fnd_responsibility_vl.end_date%TYPE;
  l_errmsg              VARCHAR2(2000);
  e_error               EXCEPTION;
BEGIN
  print_log('  + '||l_procname);
  print_log('+ Verifico si la Responsabilidad existe.');
  IF p_resp_name IS NULL THEN
     l_errmsg := 'Respnsabilidad NO informada - Proceso Cancelado';
     RAISE e_error;
  ELSE
     BEGIN
       SELECT responsibility_id, end_date
         INTO l_resp_id, l_end_date
         FROM fnd_responsibility_vl 
        WHERE UPPER(TRIM(responsibility_name)) = UPPER(TRIM(p_resp_name));
     EXCEPTION
       WHEN no_data_found THEN
            l_errmsg := 'Responsabilidad Inexistente - Proceso Cancelado';
            RAISE e_error;
       WHEN others THEN
            l_errmsg := 'ERROR al buscar el Resp_Id; '||SQLERRM;
            RAISE e_error;
     END;
     print_log('  Resp_Id = '||l_resp_id||'; End_Date = '||NVL(TO_CHAR(l_end_date,'dd/mm/yyyy'),'(NULL)') );
     --     
     IF NVL(l_end_date,SYSDATE) <= TRUNC(SYSDATE) THEN
        l_errmsg := 'La responsabilidad '||p_resp_name||' esta dada de baja - Proceso Cancelado';
        RAISE e_error;
     END IF;
  END IF;
  print_log('  - '||l_procname);
  --
  RETURN( l_resp_id );
EXCEPTION
  WHEN e_error THEN
       x_errmsg := l_errmsg;
       print_log(l_errmsg);
       RETURN( TO_NUMBER(NULL) );
  WHEN others THEN
       x_errmsg := NVL(l_errmsg,'')||' ERROR General en '||l_procname||'; '||SQLERRM;
       print_log(x_errmsg);
       RETURN( TO_NUMBER(NULL) );
END get_resp_id;

--******************************************************************************\
--| Name   : SOD_Matrix
--| Purpose: Valida si una Aplicacion/Rol tiene incompatibilidades con
--|          lo que el usuario ya tiene asignado (para esa Aplicacion).
--| Params : p_email_address: direccion de email del usuario
--|          p_resp_name: nombre de la responsabilidad
--|          p_end_date: fecha de baja (para asignaciones temporales)
--| Notes  : El proceso de Alta ejecuta las validaciones de la matriz de 
--|          incompatibilidades.  
--| History: 21/09/2018  DVartabedian  Created
--|
--******************************************************************************/
PROCEDURE sod_matrix( p_email_address  IN VARCHAR2
                     ,p_appl_name      IN VARCHAR2
                     ,p_role_name      IN DATE
                     ,x_errmsg        OUT VARCHAR2 )
IS
  -- Variables
  l_procname            VARCHAR2(70) := c_procname||'.SOD_MATRIX';
  l_user_id             fnd_user.user_id%TYPE;
  l_user_name           fnd_user.user_name%TYPE;
  l_appl_id             xx_sod_matrix.appl_id%TYPE;
  l_role_id             xx_sod_matrix.role_id%TYPE;
  l_incomp_appl_id      xx_sod_matrix.incomp_appl_id%TYPE;
  l_incomp_role_id      xx_sod_matrix.incomp_role_id%TYPE;
  l_errmsg              VARCHAR2(2000);
  e_error               EXCEPTION;
BEGIN
  ENABLE_DEBUG;
  print_log('+ '||l_procname);
  print_log('Params: ');
  print_log('+ p_email_address = '||NVL(p_email_address,'NULL'));
  print_log('+ p_appl_name = '||NVL(p_appl_name,'NULL'));
  print_log('+ p_role_name = '||NVL(p_role_name,'NULL'));
  --
  -- Inicializo la sesion.
  INITIALIZE( x_errmsg => l_errmsg );
  IF x_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si el usuario existe.
  l_user_id := GET_USER_ID( p_email_address => p_email_address
                           ,x_user_name     => l_user_name
                           ,x_errmsg        => l_errmsg );
  IF l_user_id IS NULL OR l_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si existe la aplicacion.
  BEGIN
    SELECT appl_id
      INTO l_appl_id
      FROM xx_sod_applications
     WHERE UPPER(TRIM(appl_name)) = UPPER(TRIM(p_appl_name))
       AND enabled_flag = 'Y';  
  EXCEPTION
    WHEN no_data_found THEN
         l_errmsg := 'Aplicacion Inexistente';
         RAISE e_error;
    WHEN others THEN
         l_errmsg := 'Error al buscar el Appl_Id; '||SQLERRM;
         RAISE e_error;
  END;
  --
  -- Verifico si existe el rol.
  BEGIN
    SELECT role_id
      INTO l_role_id
      FROM xx_sod_roles
     WHERE UPPER(TRIM(role_name)) = UPPER(TRIM(p_role_name))
       AND enabled_flag = 'Y';  
  EXCEPTION
    WHEN no_data_found THEN
         l_errmsg := 'Rol Inexistente';
         RAISE e_error;
    WHEN others THEN
         l_errmsg := 'Error al buscar el Role_Id; '||SQLERRM;
         RAISE e_error;
  END;
  
  /*
  
  VERIFICO SI EL USUARIO YA TIENE ESTA COMBINACION DE APPL_ID+ROLE_ID.
  Si la tiene, mensaje de error y sale con (R)eject. 
  (en este proceso, antes de hacer la verificacion, hay que traer la lista de appl_id/role_id que ya tiene asignados el usuario en el IdM).
  
  */
 
  --
  -- Verifico si existe la Aplic/Rol en la Matriz SOD (busco el rol incompatible)
  BEGIN
    SELECT incomp_appl_id, incomp_role_id
      INTO l_incomp_appl_id, l_incomp_role_id
      FROM xx_sod_matrix
     WHERE appl_id = l_appl_id
       AND role_id = l_role_id
       AND enabled_flag = 'Y';
  EXCEPTION
    WHEN no_data_found THEN
         NULL; --> no tiene incompatibilidades
    WHEN others THEN
         l_errmsg := 'Error al buscar el Appl_Id/Role_Id; '||SQLERRM;
         RAISE e_error;
  END;
  -- 
  -- Si no encontro ninguna incompatibilidad, hago la verificacion al reves: tomando lo que me pasan como el rol incompatible, busco si tiene el rol principal.
  IF l_incomp_appl_id IS NULL OR l_incomp_role_id IS NULL THEN
     BEGIN
       SELECT appl_id, role_id
         INTO l_incomp_appl_id, l_incomp_role_id
         FROM xx_sod_matrix
        WHERE incomp_appl_id = l_appl_id
          AND incomp_role_id = l_role_id
          AND enabled_flag = 'Y';
     EXCEPTION
       WHEN no_data_found THEN
            NULL; --> no tiene incompatibilidades
       WHEN others THEN
            l_errmsg := 'Error al buscar el Incomp_Appl_Id/Incomp_Role_Id; '||SQLERRM;
            RAISE e_error;
     END;
  END IF;
  --
/*
  Si tiene incompatibilidades, hay que ir a ver que appl_id/role_id ya tiene asignados el usuario (viene del idm).
  
  Si es compatible, hay que ver que tipo de aprobacion tiene el rol: si (W) o (A).
  Si lo que tiene es incompatible, hay que rechazar: sale con (R).
*/
  --
EXCEPTION
  WHEN e_error THEN
       x_errmsg := l_errmsg;
       print_log(l_errmsg);
  WHEN others THEN
       x_errmsg := NVL(l_errmsg,'')||' ERROR General en '||l_procname||'; '||SQLERRM;
       print_log(x_errmsg);
END sod_matrix;
--/******************************************************************************\
--| Name   : Add_Resp
--| Purpose: Valida y procesa el alta de responsabilidades a usuarios.
--| Params : p_email_address: direccion de email del usuario
--|          p_resp_name: nombre de la responsabilidad
--|          p_end_date: fecha de baja (para asignaciones temporales)
--| Notes  : El proceso de Alta ejecuta las validaciones de la matriz de 
--|          incompatibilidades.  
--| Casos  : furg.end_date: es la fecha fin de la asignacion (fnd_user_resp_groups_direct)
--|          p_end_date: es la fecha fin del parametro
--|-----------------------------------------------------------------------------------------------------
--| furg.end_date       | p_end_date           | diagnostic                                     | case |
--|----------------------------------------------------------------------------------------------------- 
--| no existe           | null                 | alta normal                                    | 1.1  |
--| no existe           | p_end_date > sysdate | alta con fecha fin futura                      | 1.2  |
--| no existe           | p_end_date < sysdate | rechazar (es la baja de un alta)               | 1.3  |
--| null                | null                 | ya la tiene - no hace nada                     | 2.1  |
--| null                | p_end_date > sysdate | alta con fecha fin futura                      | 2.2  |
--| null                | p_end_date < sysdate | es una baja - rechazar                         | 2.3  |
--| end_date > sysdate  | null                 | tiene fecha fin pero se la saca                | 3.1  |
--| end_date > sysdate  | p_end_date > sysdate | tiene fecha fin pero la tira para mas adelante | 3.2  |
--| end_date > sysdate  | p_end_date < sysdate | es una baja - rechazar                         | 3.3  |
--| end_date <= sysdate | null                 | es una baja pero la rehabilta                  | 4.1  |
--| end_date <= sysdate | p_end_date > sysdate | es una baja pero le pone fecha fin (futura)    | 4.2  |
--| end_date <= sysdate | p_end_date < sysdate | rechazar (no tiene sentido)                    | 4.3  |
--|-----------------------------------------------------------------------------------------------------
--|
--| History: 21/09/2018  DVartabedian  Created
--|
--\******************************************************************************/
PROCEDURE add_resp( p_email_address  IN VARCHAR2
                   ,p_resp_name      IN VARCHAR2
                   ,p_end_date       IN DATE     DEFAULT NULL
                   ,x_errmsg        OUT VARCHAR2 )
IS
  -- Variables
  l_procname            VARCHAR2(70) := c_procname||'.ADD_RESP';
  l_user_id             fnd_user.user_id%TYPE;
  l_user_name           fnd_user.user_name%TYPE;
  l_resp_id             fnd_responsibility_vl.responsibility_id%TYPE;
  l_start_date          fnd_user_resp_groups_direct.start_date%TYPE;
  l_end_date            fnd_user_resp_groups_direct.end_date%TYPE;
  l_errmsg              VARCHAR2(2000);
  e_error               EXCEPTION;
  -- Cursores
  CURSOR ccur IS
         SELECT fr.responsibility_id, fr.responsibility_key, fr.application_id, fs.security_group_id, fs.security_group_key, fa.application_short_name
           FROM fnd_application        fa
               ,fnd_security_groups    fs
               ,fnd_responsibility_vl  fr
          WHERE UPPER(fr.responsibility_name) = UPPER(TRIM(p_resp_name))
            AND fs.security_group_id = fr.data_group_id
            AND fa.application_id = fr.application_id;
--            AND fa.application_id = fr.group_application_id;
BEGIN
  ENABLE_DEBUG;
  print_log('+ '||l_procname);
  print_log('Params: ');
  print_log('+ p_email_address = '||NVL(p_email_address,'NULL'));
  print_log('+ p_resp_name = '||NVL(p_resp_name,'NULL'));
  --
  -- Inicializo la sesion.
  INITIALIZE( x_errmsg => l_errmsg );
  IF x_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si el usuario existe.
  l_user_id := GET_USER_ID( p_email_address => p_email_address
                           ,x_user_name     => l_user_name
                           ,x_errmsg        => l_errmsg );
  IF l_user_id IS NULL OR l_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si la respo existe.
  l_resp_id := GET_RESP_ID( p_resp_name => p_resp_name
                           ,x_errmsg    => l_errmsg );
  IF l_resp_id IS NULL OR l_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  print_log('+ Verifico si ya tiene esta respo asignada.');
  BEGIN
    SELECT end_date, start_date
      INTO l_end_date, l_start_date
      FROM fnd_user_resp_groups_direct
     WHERE user_id = l_user_id
       AND responsibility_id = l_resp_id;
    print_log('- Verifico si ya tiene esta respo asignada - l_end_date = '||NVL(TO_CHAR(l_end_date,'dd/mm/yyyy'),'(NULL)'));
    IF l_end_date IS NULL THEN
       -- ===========================================
       print_log('  Tiene la respo y esta activa');
       -- ===========================================
       IF p_end_date > TRUNC(SYSDATE) THEN
          -- ----------------------------------------------------------------------------------------
          print_log('  (2.2) Si la fecha de fin es futura, asigno la respo con fecha de fin futura');
          -- ----------------------------------------------------------------------------------------
          FOR rcur IN ccur LOOP
              BEGIN
                print_log('  + fnd_user_resp_groups_api.update_assignment');
                fnd_user_resp_groups_api.update_assignment( user_id                       => l_user_id
                                                           ,responsibility_id             => rcur.responsibility_id
                                                           ,responsibility_application_id => rcur.application_id
                                                           ,security_group_id             => rcur.security_group_id
                                                           ,start_date                    => l_start_date
                                                           ,end_date                      => p_end_date  
                                                           ,description                   => TO_CHAR(NULL) );
                print_log('  - fnd_user_resp_groups_api.update_assignment');
                print_log('  Se actualizo la responsabilidad solicitada con fecha '||NVL(TO_CHAR(p_end_date,'dd/mm/yyyy'),'NULL'));
              EXCEPTION
                WHEN others THEN
                     l_errmsg := 'ERROR al ejecutar fnd_user_pkg.addresp; '||SQLERRM;
                     RAISE e_error;
              END;
          END LOOP; 
       ELSE
          -- ---------------------------------------------------------------------------------------------------------------------------------------
          print_log('  (2.1 y 2.3) Si la fecha de fin esta vacia NO cambia nada, y si es menor a la fecha del dia es una baja => hay que rechazar');
          -- ---------------------------------------------------------------------------------------------------------------------------------------
       END IF;
    ELSIF l_end_date > TRUNC(SYSDATE) THEN
       -- ===========================================================================================
       print_log('  La fecha de fin de la respo asignada es > sysdate (tiene fecha de fin futura)');
       -- ===========================================================================================
       IF NVL(p_end_date,SYSDATE) > TRUNC(SYSDATE) THEN
          -- ------------------------------------------------------------------------------------------
          print_log('  (3.1 y 3.2) Tiene fecha de fin pero se la saca o le pone fecha de fin futura');
          -- ------------------------------------------------------------------------------------------
          FOR rcur IN ccur LOOP
              BEGIN
                print_log('  + fnd_user_resp_groups_api.update_assignment');
                fnd_user_resp_groups_api.update_assignment( user_id                       => l_user_id
                                                           ,responsibility_id             => rcur.responsibility_id
                                                           ,responsibility_application_id => rcur.application_id
                                                           ,security_group_id             => rcur.security_group_id
                                                           ,start_date                    => l_start_date
                                                           ,end_date                      => p_end_date  
                                                           ,description                   => TO_CHAR(NULL) );
                print_log('  - fnd_user_resp_groups_api.update_assignment');
                print_log('  Se modifico la responsabilidad solicitada');
              EXCEPTION
                WHEN others THEN
                     l_errmsg := 'ERROR al ejecutar fnd_user_resp_groups_api.update_assignment; '||SQLERRM;
                     RAISE e_error;
              END;
          END LOOP;
       ELSE
          -- -------------------------------------------------------------------------------------------------
          print_log('  (3.3) Si la fecha de fin es menor a la fecha del dia es una baja => hay que rechazar');
          -- -------------------------------------------------------------------------------------------------
       END IF;
    -- =================================================================================================================
    print_log('  La respo esta dada de baja; podria ser que la quiera rehabilitar o que le ponga fecha de fin futura');
    -- =================================================================================================================
    ELSIF l_end_date <= TRUNC(SYSDATE) THEN
       IF NVL(p_end_date,SYSDATE) > TRUNC(SYSDATE) THEN
          -- ------------------------------------------------------------------------------------------------
          print_log('  (4.1 y 4.2) Tiene fecha de baja pero puede rehabilitar o poner fecha de fin futura');
          -- ------------------------------------------------------------------------------------------------
          FOR rcur IN ccur LOOP
              BEGIN
                print_log('  + fnd_user_resp_groups_api.update_assignment');
                fnd_user_resp_groups_api.update_assignment( user_id                       => l_user_id
                                                           ,responsibility_id             => rcur.responsibility_id
                                                           ,responsibility_application_id => rcur.application_id
                                                           ,security_group_id             => rcur.security_group_id
                                                           ,start_date                    => l_start_date
                                                           ,end_date                      => p_end_date  
                                                           ,description                   => TO_CHAR(NULL) );
                print_log('  - fnd_user_resp_groups_api.update_assignment');
                print_log('  Se modifico la responsabilidad solicitada');
              EXCEPTION
                WHEN others THEN
                     l_errmsg := 'ERROR al ejecutar fnd_user_resp_groups_api.update_assignment; '||SQLERRM;
                     RAISE e_error;
              END;
          END LOOP;
       ELSE
          -- --------------------------------------------------------------------------------------------------
          print_log('  (4.3) Si la fecha de fin es menor a la fecha del dia es una baja => hay que rechazar');
          -- --------------------------------------------------------------------------------------------------
       END IF;
    END IF;
    ------
    COMMIT;
    ------
  EXCEPTION
    WHEN no_data_found THEN
         -- ===============================
         print_log('  Es un alta normal');
         -- ===============================
         print_log('  -----------------------------------------------------------------');
         print_log('  OK! el usuario NO tiene la respo asignada => hay que asignarsela.');
         print_log('  -----------------------------------------------------------------');
         FOR rcur IN ccur LOOP
             BEGIN
               IF NVL(p_end_date,SYSDATE) >= TRUNC(SYSDATE) THEN
                  -- --------------------------------------------------------------------------------------------------------------------------
                  print_log('  (1.1 y 1.2) La fecha de fin puede ser vacia o posterior a la fecha del dia (si es anterior, hay que rechazar)');
                  -- --------------------------------------------------------------------------------------------------------------------------
                  l_end_date := p_end_date;
                  print_log('  + fnd_user_pkg.addresp'); 
                  fnd_user_pkg.addresp( username       => l_user_name
                                       ,resp_app       => rcur.application_short_name
                                       ,resp_key       => rcur.responsibility_key
                                       ,security_group => rcur.security_group_key
                                       ,description    => NULL
                                       ,start_date     => SYSDATE
                                       ,end_date       => l_end_date ); 
                  print_log('  - fnd_user_pkg.addresp'); 
                  print_log('  Se asigno la responsabilidad solicitada');
                  -------
                  COMMIT;
                  -------
               ELSE
                  -- -----------------------------------------------------------------------
                  print_log('  (1.3) Seria un alta con fecha anterior al dia de la fecha');
                  -- -----------------------------------------------------------------------
                  l_errmsg := 'No se puede dar de alta una responsabilidad con fecha anterior al dia de la fecha - Proceso Cancelado';
                  RAISE e_error;
               END IF;
             EXCEPTION
               WHEN others THEN
                    l_errmsg := 'ERROR al ejecutar fnd_user_pkg.addresp; '||SQLERRM;
                    RAISE e_error;
             END;
         END LOOP;
    WHEN others THEN
         l_errmsg := 'ERROR al buscar si el usuario tiene la respo asignada; '||SQLERRM;
         RAISE e_error;
  END;
  --     
  print_log('- '||l_procname);
EXCEPTION
  WHEN e_error THEN
       x_errmsg := l_errmsg;       
       print_log(l_errmsg);
  WHEN OTHERS THEN
       x_errmsg := NVL(l_errmsg,'ERROR General en '||l_procname)||'; '||SQLERRM;
       print_log(l_errmsg);
END add_resp;
--/******************************************************************************\
--| Name   : Del_Resp
--| Purpose: Valida y procesa la Baja de responsabilidades a usuarios.
--| Params : p_email_address: direccion de email del usuario
--|          p_resp_name: nombre de la responsabilidad
--| Notes  :   
--| Casos  : furg.end_date: es la fecha fin de la asignacion (fnd_user_resp_groups_direct)
--|          p_end_date: es la fecha fin del parametro
--|---------------------------------------------------------------------------
--| furg.end_date        |  diagnostic                                | case |
--|--------------------------------------------------------------------------- 
--| no existe            | rechazar (no puede bajar lo que no tiene)  | 1.1  |
--| null                 | baja normal                                | 1.2  |
--| end_date > sysdate   | tiene fecha de fin futura, pero se la saca | 1.3  |
--| end_date <= sysdate  | ya esta dado de baja - no hace nada        | 1.3  |
--|---------------------------------------------------------------------------
--|
--| History: 21/09/2018  DVartabedian  Created
--|
--\******************************************************************************/
PROCEDURE del_resp( p_email_address  IN VARCHAR2
                   ,p_resp_name      IN VARCHAR2
                   ,x_errmsg        OUT VARCHAR2 )
IS
  -- Variables
  l_procname            VARCHAR2(70) := c_procname||'.DEL_RESP';
  l_user_id             fnd_user.user_id%TYPE;
  l_user_name           fnd_user.user_name%TYPE;
  l_resp_id             fnd_responsibility_vl.responsibility_id%TYPE;
  l_end_date            fnd_responsibility_vl.end_date%TYPE;
  l_errmsg              VARCHAR2(2000);
  e_error               EXCEPTION;
  -- Cursores
  CURSOR ccur IS
         SELECT fr.responsibility_id, fr.responsibility_name, fr.responsibility_key, fr.application_id, fs.security_group_key, fa.application_short_name
           FROM fnd_application        fa
               ,fnd_security_groups    fs
               ,fnd_responsibility_vl  fr
          WHERE UPPER(fr.responsibility_name) = UPPER(TRIM(p_resp_name))
            AND fs.security_group_id = fr.data_group_id
            AND fa.application_id = fr.application_id;
BEGIN
  ENABLE_DEBUG;
  print_log('+ '||l_procname);
  print_log('Params: ');
  print_log('+ p_email_address = '||NVL(p_email_address,'NULL'));
  print_log('+ p_resp_name = '||NVL(p_resp_name,'NULL'));
  --
  -- Inicializo la sesion.
  INITIALIZE( x_errmsg => l_errmsg );
  IF x_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si el usuario existe.
  l_user_id := GET_USER_ID( p_email_address => p_email_address
                           ,x_user_name     => l_user_name
                           ,x_errmsg        => l_errmsg );
  IF l_user_id IS NULL OR l_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si la respo existe.
  l_resp_id := GET_RESP_ID( p_resp_name => p_resp_name
                           ,x_errmsg    => l_errmsg );
  IF l_resp_id IS NULL OR l_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Verifico si ya tiene esta respo asignada.
  BEGIN
    SELECT end_date
      INTO l_end_date
      FROM fnd_user_resp_groups_direct
     WHERE user_id = l_user_id
       AND responsibility_id = l_resp_id;
    --
    IF NVL(l_end_date,SYSDATE) <= TRUNC(SYSDATE) THEN
       print_log('  --------------------------------------------------------------');
       print_log('  El usuario ya tiene la respo desasignada - Sale sin hacer nada');
       print_log('  --------------------------------------------------------------');
       l_errmsg := 'El usuario '||l_user_name||' ya tiene la responsabilidad '||p_resp_name||' dada de baja - Proceso Cancelado';
    ELSE
       print_log('  ----------------------------------------------------------------------------------------------');
       print_log('  OK! el usuario tiene la respo asignada (sin fecha de fin o con fecha futura) => se da de baja.');
       print_log('  ----------------------------------------------------------------------------------------------');
       FOR rcur IN ccur LOOP         
           BEGIN
             print_log('  + fnd_user_pkg.DelResp');
             fnd_user_pkg.DelResp( username       => l_user_name 
                                  ,resp_app       => rcur.application_short_name
                                  ,resp_key       => rcur.responsibility_key
                                  ,security_group => rcur.security_group_key );
             print_log('  - fnd_user_pkg.DelResp');
             -------
             COMMIT;
             -------
             print_log('  Se desasigno la respo solicitada');
           EXCEPTION
             WHEN OTHERS THEN
                  l_errmsg := 'ERROR al desasignar la responsabilidad; '||SQLERRM||' - La responsabilidad NO pudo darse de baja';
                  RAISE e_error;                
           END;
       END LOOP;
    END IF;
  EXCEPTION
    WHEN no_data_found THEN
         l_errmsg := 'El usuario '||l_user_name||' NO tiene asignada la responsabilidad '||p_resp_name||'; NO se puede dar de baja - Proceso Cancelado';
         RAISE e_error;
    WHEN others THEN
         l_errmsg := 'ERROR al buscar si el usuario tiene la respo asignada; '||SQLERRM;
         RAISE e_error;
  END;
  --     
  print_log('- '||l_procname);
EXCEPTION
  WHEN e_error THEN
       x_errmsg := l_errmsg;    
       print_log(l_errmsg);
  WHEN OTHERS THEN
       x_errmsg := NVL(l_errmsg,'ERROR General en '||l_procname)||'; '||SQLERRM;
       print_log(l_errmsg);
END del_resp;

--/******************************************************************************\
--| Name...: INITIALIZE                                                          |
--| Purpose: Inicializa con User "IDM"                                           |
--| Notes..:                                                                     |
--| History: 17/08/2018 Created DVartabedian                                     |
--|                                                                              |
--\******************************************************************************/
PROCEDURE initialize( x_errmsg  OUT VARCHAR2 )
IS
  l_procname             VARCHAR2(70) := c_procname||'.INITIALIZE';
  l_user_id              fnd_user.user_id%TYPE;
  l_responsibility_id    fnd_responsibility_tl.responsibility_id%TYPE;
  l_application_id       fnd_responsibility_tl.application_id%TYPE;
BEGIN
  print_log('+ '||l_procname);
  apps_ddl.apps_ddl('ALTER SESSION SET CURRENT_SCHEMA = "APPS"');
  --
  -- Busco el usuario IDM.
  BEGIN
    SELECT user_id
      INTO l_user_id
      FROM fnd_user
     WHERE user_name = g_idm_user_name;
  EXCEPTION
    WHEN no_data_found THEN 
         x_errmsg := 'Usuario '||g_idm_user_name||' NO fue creado - Proceso Cancelado';
         RETURN;
    WHEN others THEN
         x_errmsg := 'ERROR General al buscar el usuario '||g_idm_user_name||'; '||SQLERRM;
         RETURN;
  END; 
  --
  -- Busco la respo "DSP Administrador de Personal".
  BEGIN
    SELECT responsibility_id, application_id
      INTO l_responsibility_id, l_application_id
      FROM fnd_responsibility_tl
     WHERE responsibility_name = g_resp_adm_personal
       AND LANGUAGE = 'US';
  EXCEPTION
    WHEN no_data_found THEN 
         x_errmsg := 'Responsabilidad '||g_resp_adm_personal||' NO existe - Proceso Cancelado';
         RETURN;
    WHEN others THEN
         x_errmsg := 'ERROR General al buscar la responsabilidad '||g_resp_adm_personal||'; '||SQLERRM;
         RETURN;
  END;
--  print_log('  USER = '||l_user_id||'; Responsibility_Id = '||l_responsibility_id||'; Appl_Id = '||l_application_id); 
  --
  -- Inicializo la sesion.  
  BEGIN
    print_log('  + apps_initialize; l_user_id = '||TO_CHAR(l_user_id)||'; l_resp_id = '||TO_CHAR(l_responsibility_id)||'; l_appl_id = '||TO_CHAR(l_application_id));
    fnd_global.apps_initialize(l_user_id,l_responsibility_id,l_application_id);
    print_log('  - apps_initialize');
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'ERROR al ejecutar APPS_INITIALIZE; '||SQLERRM;
         RETURN;
  END;
  BEGIN
    print_log('  + set nls_language');
    apps_ddl.apps_ddl('ALTER SESSION SET NLS_LANGUAGE = ''AMERICAN''');
    print_log('  - set nls_language');
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'ERROR al cambiar el lenguaje; '||SQLERRM;
         RETURN;
  END;
  --
  -- Agregamos esta llamada.
  BEGIN
    print_log('  + arp_standard.init_standard');
    arp_standard.init_standard( p_org_id => TO_NUMBER(NULL) );
    print_log('  - arp_standard.init_standard');
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'ERROR al ejecutar ARP_STANDARD.INIT_STANDARD; '||SQLERRM;
         BEGIN
           print_log('  + arp_standard.init_standard por 2a vez');
           arp_standard.init_standard; --> lo vuelvo a ejecutar!
           print_log('  - arp_standard.init_standard por 2a vez');
         EXCEPTION
           WHEN others THEN
                x_errmsg := 'ERROR al ejecutar ARP_STANDARD.INIT_STANDARD por 2a vez; '||SQLERRM;
         END;
  END;
  -- 
  BEGIN    
    print_log('  + arp_global.init_global');
    arp_global.init_global( p_org_id => TO_NUMBER(NULL) );
    print_log('  - arp_global.init_global');
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'ERROR al ejecutar el init_global; '||SQLERRM;
         RETURN;
  END;
--  BEGIN    
--    print_log('  + arp_standard.init_standard');
--    arp_standard.init_standard( p_org_id => TO_NUMBER(NULL) );
--    print_log('  - arp_standard.init_standard');
--  EXCEPTION
--    WHEN others THEN
--         x_errmsg := 'ERROR al ejecutar el init_standard; '||SQLERRM;
--         RETURN;
--  END;
  -- Verifico.
--  print_log('  Usuario logueado: '||fnd_global.user_name);
--  IF NVL(fnd_global.org_id,-1) <= 0 THEN
--     x_errmsg := 'NO se pudo hacer el Initialize - Proceso Cancelado';
--     RETURN;
--  END IF;
  print_log('  User_Name = '||fnd_global.user_name);
--  print_log('  User_Id = '||TO_CHAR(fnd_global.user_id));
  print_log('  Resp_Name = '||fnd_global.resp_name);
--  print_log('  Resp_Id = '||TO_CHAR(fnd_global.resp_id));
--  print_log('  Org_Id = '||TO_CHAR(fnd_global.org_id));
--  print_log('  Org_Id (PROFILE) = '||fnd_profile.VALUE('ORG_ID') );
  print_log('- '||l_procname);
EXCEPTION
  WHEN OTHERS THEN
       x_errmsg := 'ERROR General en '||l_procname||'; '||SQLERRM;
END initialize;

--/******************************************************************************\
-- Name   : main_employees
-- Purpose: Toma los datos de los parametros y determina si es un Alta/Baja/Modif.
-- Notes  : Este proceso graba 1 registro en la XX_ADI y de ahi en mas ejecuta
--          el proceso de ABM Empleados y Usuarios, a partir de los datos de la 
--          tabla. Los errores del proceso se guardan en el mismo registro.
--          En los casos de usuarios tercerizados, puede no grabar el Empleado
--          pero siempre tiene que crear el Usuario. En estos casos la fecha de
--          baja es obligatoria.
-- Params : p_worker_id: Required
--          p_email_address: Required
--          p_fh_baja: si se informa, no se controla el resto de los parametros
--                     (excepto los obligatorios, que siempre deben estar).
-- History: 21/09/2016  DVartabedian  Created
--
--\******************************************************************************/
PROCEDURE main_employees( p_worker_id             IN NUMBER
                         ,p_employee_num          IN VARCHAR2
                         ,p_full_name             IN VARCHAR2
                         ,p_email_address         IN VARCHAR2
                         ,p_country               IN VARCHAR2
                         ,p_fh_nacim              IN VARCHAR2
                         ,p_fh_ingreso            IN VARCHAR2
                         ,p_fh_baja               IN VARCHAR2
                         ,p_depto                 IN VARCHAR2 DEFAULT NULL
                         ,p_puesto                IN VARCHAR2 DEFAULT NULL
                         ,p_superv_email          IN VARCHAR2
                         ,p_adi                   IN VARCHAR2
                         ,x_errmsg               OUT VARCHAR2 )
IS
  l_procname             VARCHAR2(70) := c_procname||'.MAIN_EMPLOYEES';
  l_end_date             fnd_user.end_date%TYPE;
  l_creation_date        fnd_user.creation_date%TYPE;
  l_max_id               NUMBER := -1; --> para que no grabe en el exception, si es que sale por algun error de parametro o initialize.
  l_country              VARCHAR2(3);
  l_user_type            VARCHAR2(1);
--  l_org_id               NUMBER;
  l_errmsg_emp           VARCHAR2(2000);
  l_errmsg_usr           VARCHAR2(2000);
  e_error                EXCEPTION;
  --
  FUNCTION valida_input RETURN VARCHAR2
  IS
    l_fh_nacim             DATE;
    l_fh_baja              DATE;
    l_fh_ingreso           DATE;
    l_errmsg               VARCHAR2(2000);
    e_end                  EXCEPTION;
  BEGIN
    IF p_email_address IS NULL THEN
       l_errmsg := 'Email_Address esta vacio';
       RAISE e_end;
    END IF;
    IF p_country IS NULL THEN
       l_errmsg := 'Country esta vacio';
       RAISE e_end;
    ELSE
       CASE
         WHEN p_country = 'Argentina'      THEN l_country := 'ARG';
         WHEN p_country = 'Brasil'         THEN l_country := 'BRA';
         WHEN p_country = 'Chile'          THEN l_country := 'CHL';
         WHEN p_country = 'Colombia'       THEN l_country := 'COL';
         WHEN p_country = 'Costa Rica'     THEN l_country := 'CRI';
         WHEN p_country = 'Ecuador'        THEN l_country := 'ECU';
         WHEN p_country = 'Estados Unidos' THEN l_country := 'USA';
         WHEN p_country = 'M�xico'         THEN l_country := 'MEX';
         WHEN p_country = 'Panam�'         THEN l_country := 'PAN';
         WHEN p_country = 'Per�'           THEN l_country := 'PER';
         WHEN p_country = 'Uruguay'        THEN l_country := 'URY';
         WHEN p_country = 'Venezuela'      THEN l_country := 'VEN';
                                           ELSE l_country := NULL;                                         
       END CASE;
       /*******************************************************************************************************

                          OJO! FALTA COMPLETAR EL ADI (LE FALTA EL 1er SEGMENTO).

       \*******************************************************************************************************/
       IF l_country IS NULL THEN
          l_errmsg := 'Country: '||NVL(p_country,'NULL')||' NO configurado en Oracle EBS ';
          RAISE e_end;
       END IF;
    END IF;
    IF p_fh_ingreso IS NULL THEN
       l_errmsg := 'Fh_Ingreso esta vacio';
       RAISE e_end;
    ELSE
       BEGIN
         l_fh_ingreso := TO_DATE(p_fh_ingreso,'dd/mm/yyyy');
       EXCEPTION
         WHEN others THEN
              l_errmsg := 'La Fh Ingreso NO tiene formato fecha DD/MM/YYYY; ('||p_fh_ingreso||')';
              RAISE e_end;
       END;
    END IF;
    IF p_fh_baja IS NULL THEN
       NULL;
    ELSE
       BEGIN
         l_fh_baja := TO_DATE(p_fh_baja,'dd/mm/yyyy');
       EXCEPTION
         WHEN others THEN
              l_errmsg := 'La Fh Baja NO tiene formato fecha DD/MM/YYYY; ('||p_fh_baja||')';
              RAISE e_end;
       END;
    END IF;
    IF p_fh_nacim IS NULL THEN
  --           l_errmsg := 'Fh_Nacim esta vacio';
  --           RAISE e_end;
       NULL; --> fh_nacim no es campo obligatorio.
    ELSE
       BEGIN
         l_fh_nacim := TO_DATE(p_fh_nacim,'dd/mm/yyyy');
       EXCEPTION
         WHEN others THEN
              l_errmsg := 'La Fh Nacim NO tiene formato fecha DD/MM/YYYY; ('||p_fh_nacim||')';
              RAISE e_end;
       END;
    END IF;
    IF p_superv_email IS NULL THEN
       l_errmsg := 'Superv_eMail esta vacio';
       RAISE e_end;
    END IF;
    IF p_adi IS NULL THEN
       l_errmsg := 'ADI esta vacio';
       RAISE e_end;
    END IF;
    RETURN( TO_CHAR(NULL) );
  EXCEPTION
    WHEN e_end THEN
         RETURN( l_errmsg );
    WHEN others THEN
         RETURN( 'ERROR al ejecutar funcion valida_input; '||SQLERRM );
  END valida_input;
  --
BEGIN
  ENABLE_DEBUG;
  print_log('+ '||l_procname);
  --
  -- Si es un usuario tercerizado, no tiene worker_id ni employee_num, y viene con fecha de baja.
  IF NVL(p_worker_id,0) <= 0 THEN
     IF p_employee_num IS NULL THEN
        IF p_fh_baja IS NOT NULL THEN
           l_user_type := 'T'; --> es un Tercerizado, pero tiene que tener el resto de los campos.
        ELSE
           x_errmsg := 'Si es un tercerizado, debe tener fecha de baja';
           RAISE e_error;
        END IF;
     ELSE
        x_errmsg := 'Si es tercerizado, NO debe tener Worker_Id ni Nro Empleado, y debe tener Fecha de Baja';
        RAISE e_error;
     END IF;
  ELSE -- Estos usuarios son los que vienen de RRHH (son Empleados).
     IF p_employee_num IS NULL THEN
        x_errmsg := 'Employee_Num esta vacio';
        RAISE e_error;
     END IF;
     l_user_type := 'E'; --> es un Empleado.
  END IF;
  print_log('  l_user_type = '||l_user_type);
  --
  -- Campos genericos.
  IF l_user_type = 'E' THEN
     IF p_fh_baja IS NOT NULL THEN
        NULL; --> es una baja de Empleado; no hacen falta mas datos.
     ELSE
        x_errmsg := VALIDA_INPUT;
        IF x_errmsg IS NOT NULL THEN
           RAISE e_error;  
        END IF;
     END IF;
  ELSE -- Si es un (T)ercerizado.      
     x_errmsg := VALIDA_INPUT;
     IF x_errmsg IS NOT NULL THEN
        RAISE e_error;  
     END IF;
  END IF;
  -- ---------------------
  -- Inicializo la sesion.
  -- ---------------------
  INITIALIZE( x_errmsg => x_errmsg );
  IF x_errmsg IS NOT NULL THEN
     RAISE e_error;
  END IF;
  --
  -- Si la modificacion es para un usuario dado de baja, no hago nada.
  BEGIN
    SELECT end_date, TRUNC(creation_date)
      INTO l_end_date, l_creation_date
      FROM fnd_user
     WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(p_email_address));
  EXCEPTION
    WHEN no_data_found THEN
         l_end_date := SYSDATE; --> no hago nada, es un alta.
    WHEN others THEN
         x_errmsg := 'ERROR al verificar el estado DEL usuario; '||SQLERRM;
         RAISE e_error;
  END;
  print_log('  l_end_date = '||TO_CHAR(l_end_date,'dd/mm/yyyy'));
  print_log('  l_creation_date = '||TO_CHAR(l_creation_date,'dd/mm/yyyy'));
  --
  SELECT NVL(MAX(ID),0)+1 INTO l_max_id FROM xx_adi;
  --
  print_log('  + Inserta Registro en xx_adi con ID = '||l_max_id);
  BEGIN
    INSERT INTO xx_adi
          (
           ID                      --NUMBER(5),
          ,STATUS                  --VARCHAR2(7 BYTE),
          ,WORKER_ID               --NUMBER(15),
          ,UPDATE_FUNCTION         --NUMBER(1),
          ,EMPLOYEE_NUM            --VARCHAR2(30 BYTE),
          ,FULL_NAME               --VARCHAR2(50 BYTE),
          ,EMAIL_ADDRESS           --VARCHAR2(70 BYTE),
          ,REGION                  --VARCHAR2(3 BYTE),
          ,ERRMSG                  --VARCHAR2(2000 BYTE),
          ,NRO_DOCUMENTO           --VARCHAR2(20 BYTE),
          ,FH_NACIM                --VARCHAR2(11 BYTE),
          ,FH_INGRESO              --VARCHAR2(10 BYTE),
          ,USER_TYPE               --VARCHAR2(1 BYTE),
          ,DEPTO                   --VARCHAR2(40 BYTE),
          ,PUESTO                  --VARCHAR2(240 BYTE),
          ,SUPERV_NUM              --VARCHAR2(11 BYTE),
          ,SUPERV_NAME             --VARCHAR2(70 BYTE),
          ,SUPERV_EMAIL            --VARCHAR2(70 BYTE),
          ,OLD_SUPERV_ID           --VARCHAR2(11 BYTE),
          ,OLD_SUPERV_NAME         --VARCHAR2(70 BYTE),
          ,ADI                     --VARCHAR2(50 BYTE),
          ,OLD_ADI                 --VARCHAR2(50 BYTE),
          ,OLD_SOB_ID              --NUMBER(15),
          ,ESTADO                  --VARCHAR2(1 BYTE),
          ,FH_BAJA                 --VARCHAR2(10 BYTE),
          ,PERSON_ID               --NUMBER(15),
          ,REQUEST_ID              --NUMBER(15),
          ,CREATION_DATE           --DATE
          )
    VALUES 
          (
           l_max_id                --ID             
          ,'NEW'                   --STATUS   
          ,p_worker_id             --WORKER_ID      
          ,NULL                    --UPDATE_FUNCTION
          ,p_employee_num          --EMPLOYEE_NUM   
          ,p_full_name             --FULL_NAME      
          ,p_email_address         --EMAIL          
          ,l_country               --REGION         
          ,NULL                    --ERRMSG         
          ,NULL                    --NRO_DOCUMENTO  
          ,p_fh_nacim              --FH_NACIM       
          ,p_fh_ingreso            --FH_INGRESO 
          ,l_user_type             --USER_TYPE (puede ser (T)ercerizado o (E)mpleado.    
          ,p_depto                 --DEPTO          
          ,p_puesto                --PUESTO         
          ,NULL                    --SUPERV_NUM     
          ,NULL                    --SUPERV_NAME    
          ,p_superv_email          --SUPERV_EMAIL
          ,NULL                    --OLD_SUPERV_ID  
          ,NULL                    --OLD_SUPERV_NAME
          ,p_adi                   --ADI            
          ,NULL                    --OLD_ADI        
          ,NULL                    --OLD_SOB_ID     
          ,NULL                    --ESTADO         
          ,p_fh_baja               --FH_BAJA        
          ,NULL                    --PERSON_ID      
          ,NULL                    --REQUEST_ID     
          ,SYSDATE                 --CREATION_DATE  
          );
    -------
    COMMIT;
    -------
    print_log('  - Inserta Registro en xx_adi con ID = '||l_max_id);
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'ERROR al insertar en XX_ADI (1); '||SQLERRM;
         --
         -- Actualizo el estado de la xx_adi.
         UPDATE xx_adi 
            SET status = 'ERROR'
               ,errmsg = x_errmsg
          WHERE ID = l_max_id;
         -------
         COMMIT;
         -------
         RAISE e_error;
  END;
  --
  IF l_end_date = l_creation_date THEN
     NULL; -- es un usuario creado por proceso; no esta de baja sino que nunca fue habilitado.
  ELSIF l_end_date <= TRUNC(SYSDATE) THEN
     x_errmsg := 'NO se puede modificar modificar un usuario dado de baja';
     BEGIN
       UPDATE xx_adi
          SET status = 'ERROR'
             ,errmsg = x_errmsg
        WHERE ID = l_max_id;
       -------
       COMMIT;
       -------
     EXCEPTION
       WHEN others THEN
            x_errmsg := NVL(x_errmsg,'')||'; No se pudo grabar el estado en xx_adi; '||SQLERRM;
            RAISE e_error;
     END;
  END IF;
  --
  -- ---------------------------------------
  -- Inserto el Empleado (no tercerizados).
  -- ---------------------------------------
  IF l_user_type = 'E' THEN
     PROCESS_EMPLOYEE( p_id     => l_max_id 
                      ,x_errmsg => l_errmsg_emp );
  END IF;
  -- -------------------------------------------------------------------------------------------
  -- Inserto el Usuario (por ahora, le creo el usuario solo al Empleado, no a los Tercerizados;
  -- en caso de tener que crearlo, modificar la fecha de baja: debe ser la del contrato).
  -- Si el proceso anterior tuvo algun error, no proceso el usuario.
  ----------------------------------------------------------------------------------------------
  IF l_user_type = 'E' AND l_errmsg_emp IS NULL THEN  
     PROCESS_USER( p_id     => l_max_id
                  ,x_errmsg => l_errmsg_usr );
  END IF;
  ------------------------------------------
  IF l_errmsg_emp IS NOT NULL OR l_errmsg_usr IS NOT NULL THEN
     x_errmsg := NVL(l_errmsg_emp,'')||' '||NVL(l_errmsg_usr,' ');
  END IF;
  --
  -- Por las dudas, por si quedo alguna salida sin grabar.
  BEGIN
    UPDATE xx_adi
       SET status = 'PROC'
          ,errmsg = NVL(errmsg,'')||' Salida de proceso sin status' 
     WHERE ID = l_max_id
       AND status = 'NEW';
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'No se pudo grabar xx_adi; '||SQLERRM;
  END;
  -------
  COMMIT;
  -------
EXCEPTION
  WHEN e_error THEN
       x_errmsg := NVL(x_errmsg,'')||' - Proceso Cancelado';
  WHEN others THEN
       x_errmsg := NVL(x_errmsg,'')||' - ERROR General al insertar en XX_ADI (2); '||SQLERRM;
END main_employees;

--/******************************************************************************\
-- Name   : Process_Employee
-- Purpose: Toma los datos de los parametros y determina si es un Alta/Baja/Modif.
-- Params : p_country: son los paises segun se informan en la planilla ADI.
-- Notes  : Este proceso toma los datos de la tabla xx_adi y los compara con los
--          datos de la per_assignments_v7; si encuentra diferencias, actualiza.
--          Los valores originales se guardan en la tabla xx_adi (en campos _old)
--          como auditoria y origen de reportes, y por si hay que volver atras.
-- History: 21/09/2016  DVartabedian  Created
--
--\******************************************************************************/
PROCEDURE process_employee( p_id       IN NUMBER
                           ,x_errmsg  OUT VARCHAR2 )
IS
  l_procname               VARCHAR2(70) := c_procname||'.PROCESS_EMPLOYEE';  
  l_count                  NUMBER;
  l_adi                    gl_code_combinations_kfv.concatenated_segments%TYPE;
  l_ccid                   gl_code_combinations.code_combination_id%TYPE;
  l_sob_id                 gl_ledgers.ledger_id%TYPE;
  l_superv_id              per_assignments_f.supervisor_id%TYPE;
  l_status                 VARCHAR2(7);
  l_errmsg                 VARCHAR2(4000);
--  l_errmsg_sup             VARCHAR2(4000);
--  l_errmsg_adi             VARCHAR2(4000);
--  l_errmsg_sob             VARCHAR2(4000);
  l_operation              VARCHAR2(1);
  l_err_format             VARCHAR2(4000);
  l_chart_of_accounts_id   gl_ledgers.chart_of_accounts_id%TYPE;
  l_person_id              per_all_people_f.person_id%TYPE;
  l_assign_id              per_assignments_f.assignment_id%TYPE;
  l_user_id                fnd_user.user_id%TYPE;
  e_error                  EXCEPTION;
  --
  CURSOR cebs( p_email     IN VARCHAR2
              ,p_worker_id IN NUMBER ) IS
         SELECT (SELECT fu.user_name FROM fnd_user fu WHERE fu.employee_id = pp.person_id AND LOWER(TRIM(fu.email_address)) = LOWER(TRIM(pp.email_address))) user_name
               ,pp.employee_number, pp.full_name, pp.email_address, pp.start_date
               ,(SELECT fu.end_date FROM fnd_user fu WHERE fu.employee_id = pp.person_id AND LOWER(TRIM(fu.email_address)) = LOWER(TRIM(pp.email_address))) end_date
               ,pp.date_of_birth, pa.supervisor_id, pa.d_supervisor_id
               ,(SELECT ps.email_address FROM per_all_people_f ps WHERE ps.person_id = pa.supervisor_id) superv_email
               ,pa.set_of_books_id, pa.d_set_of_books_id, TO_NUMBER(pp.attribute2) worker_id, pa.default_code_comb_id
               ,NVL((SELECT concatenated_segments FROM gl_code_combinations_kfv WHERE code_combination_id = pa.default_code_comb_id),'.') adi, pp.person_id
               ,pa.assignment_id, (SELECT fu.user_id FROM fnd_user fu WHERE fu.employee_id = pp.person_id AND LOWER(TRIM(fu.email_address)) = LOWER(TRIM(pp.email_address))) user_id
           FROM per_assignments_v7 pa
               ,per_all_people_f   pp
          WHERE LOWER(TRIM(pp.email_address)) = LOWER(TRIM(p_email))
            AND pa.person_id = pp.person_id
            AND SYSDATE BETWEEN pa.effective_start_date AND pa.effective_end_date
            AND SYSDATE BETWEEN pp.effective_start_date AND pp.effective_end_date
--            AND pp.d_termination_date IS NULL
--            AND ROWNUM = 1  --> porque pueden venir mails que esten en mas de 1 empleado; si hay mas de 1, se detecta en get_supervisor_id (sale por exception).
--            AND NOT EXISTS (SELECT 1
--                              FROM fnd_user fu 
--                             WHERE fu.employee_id = pp.person_id 
--                               AND NVL(fu.end_date,SYSDATE) <= TRUNC(SYSDATE))            
            AND UPPER(pp.full_name) NOT LIKE 'FONDO%FIJO%'
            AND UPPER(pp.full_name) NOT LIKE 'FUNDO%FIXO%'
         UNION
         SELECT (SELECT fu.user_name FROM fnd_user fu WHERE fu.employee_id = pp.person_id AND LOWER(TRIM(fu.email_address)) = LOWER(TRIM(pp.email_address))) user_name
               ,pp.employee_number, pp.full_name, pp.email_address, pp.start_date
               ,(SELECT fu.end_date FROM fnd_user fu WHERE fu.employee_id = pp.person_id AND LOWER(TRIM(fu.email_address)) = LOWER(TRIM(pp.email_address))) end_date               
               ,pp.date_of_birth, pa.supervisor_id, pa.d_supervisor_id
               ,(SELECT ps.email_address FROM per_all_people_f ps WHERE ps.person_id = pa.supervisor_id) superv_email
               ,pa.set_of_books_id, pa.d_set_of_books_id, TO_NUMBER(pp.attribute2) worker_id, pa.default_code_comb_id
               ,NVL((SELECT concatenated_segments FROM gl_code_combinations_kfv WHERE code_combination_id = pa.default_code_comb_id),'.') adi, pp.person_id
               ,pa.assignment_id, (SELECT fu.user_id FROM fnd_user fu WHERE fu.employee_id = pp.person_id AND LOWER(TRIM(fu.email_address)) = LOWER(TRIM(pp.email_address))) user_id
           FROM per_assignments_v7 pa
               ,per_all_people_f   pp
          WHERE TO_NUMBER(NVL(pp.attribute2,'0')) = p_worker_id
            AND pa.person_id = pp.person_id
            AND SYSDATE BETWEEN pa.effective_start_date AND pa.effective_end_date
            AND SYSDATE BETWEEN pp.effective_start_date AND pp.effective_end_date
--            AND pp.d_termination_date IS NULL
--            AND NOT EXISTS (SELECT 1 
--                              FROM fnd_user fu 
--                             WHERE fu.employee_id = pp.person_id 
--                               AND NVL(fu.end_date,SYSDATE) <= TRUNC(SYSDATE))
            AND UPPER(pp.full_name) NOT LIKE 'FONDO%FIJO%'
            AND UPPER(pp.full_name) NOT LIKE 'FUNDO%FIXO%';

  --
  PROCEDURE post_update( p_assignment_id  IN NUMBER
                        ,x_errmsg        OUT VARCHAR2 )
  IS
    l_procname             VARCHAR2(70) := c_procname||'.POST_UPDATE';
    l_asg_rec              per_asg_shd.g_rec_type;
  BEGIN
    FOR rcur IN (SELECT * FROM per_assignments_f WHERE assignment_id = p_assignment_id ) LOOP
        hr_security_internal.add_to_person_list(rcur.Effective_Start_Date,rcur.Assignment_Id);
        --
        l_asg_rec.assignment_id        := rcur.Assignment_Id;
        l_asg_rec.position_id          := rcur.Position_Id;
        l_asg_rec.person_id            := rcur.Person_Id;
        l_asg_rec.effective_start_date := rcur.Effective_Start_Date;
        l_asg_rec.effective_end_date   := rcur.Effective_End_Date;
        --
        per_pqh_shr.per_asg_wf_sync( p_event                 => NULL
                                    ,p_rec                   => l_asg_rec
                                    ,p_old_position_id       => rcur.position_id --> tomo el de base porque en este proc no esta previsto cambiarlo (no hay ni old ni new).
                                    ,p_effective_date        => TRUNC(SYSDATE)
                                    ,p_validation_start_date => NULL
                                    ,p_validation_end_date   => NULL
                                    ,p_datetrack_mode        => 'CORRECTION' );
    END LOOP;
    --
    IF l_asg_rec.assignment_id IS NULL THEN
       x_errmsg := 'ERROR: NO se encontro el Assignment_Id = '||p_assignment_id||'|'||l_procname||'|NO se proceso el Post_Update';
    END IF;
  END post_update;
  --
  FUNCTION formateo( x IN VARCHAR2 DEFAULT NULL, y IN VARCHAR2 DEFAULT NULL, z IN VARCHAR2 DEFAULT NULL ) RETURN VARCHAR2
  IS
    r      VARCHAR2(4000);
  BEGIN
    CASE
      WHEN x IS NULL AND y IS NULL AND z IS NULL             THEN r := '';
      WHEN x IS NULL AND y IS NULL AND z IS NOT NULL         THEN r := z;
      WHEN x IS NULL AND y IS NOT NULL AND z IS NULL         THEN r := y;
      WHEN x IS NULL AND y IS NOT NULL AND z IS NOT NULL     THEN r := y||'; '||z;
      WHEN x IS NOT NULL AND y IS NULL AND z IS NULL         THEN r := x;
      WHEN x IS NOT NULL AND y IS NULL AND z IS NOT NULL     THEN r := x||'; '||z;
      WHEN x IS NOT NULL AND y IS NOT NULL AND z IS NULL     THEN r := x||'; '||y;
      WHEN x IS NOT NULL AND y IS NOT NULL AND z IS NOT NULL THEN r := x||'; '||y||'; '||z;
    END CASE;
    RETURN( r );
  END formateo;
  --
  PROCEDURE write_adi( p_id                 IN NUMBER
                      ,p_old_supervisor_id  IN NUMBER   DEFAULT NULL
                      ,p_old_superv_name    IN VARCHAR2 DEFAULT NULL
                      ,p_old_adi            IN VARCHAR2 DEFAULT NULL
                      ,p_old_sob_id         IN NUMBER   DEFAULT NULL
                      ,p_operation          IN VARCHAR2
                      ,p_status             IN VARCHAR2
                      ,p_errmsg             IN VARCHAR2 DEFAULT NULL
                      ,p_person_id          IN NUMBER   DEFAULT NULL
                      ,p_assignment_id      IN NUMBER   DEFAULT NULL
                      ,p_user_id            IN NUMBER   DEFAULT NULL
                      ,x_errmsg            OUT VARCHAR2 )
  IS
    PRAGMA autonomous_transaction;
  BEGIN
    UPDATE xx_adi
       SET old_superv_id    = p_old_supervisor_id
          ,old_superv_name  = p_old_superv_name
          ,old_adi          = p_old_adi
          ,old_sob_id       = p_old_sob_id
          ,operation        = p_operation
          ,errmsg           = p_errmsg
          ,status           = p_status
          ,person_id        = p_person_id
          ,assignment_id    = p_assignment_id
          ,user_id          = p_user_id
     WHERE ID = p_id;
    -------
    COMMIT;
    -------
  EXCEPTION
    WHEN others THEN
         x_errmsg := 'ERROR al grabar xx_adi con ID = '||p_id||'; '||SQLERRM;
         ROLLBACK;
  END write_adi;
  --
  FUNCTION get_adi( p_entidad_legal IN VARCHAR2
                   ,p_adi           IN VARCHAR2 ) RETURN VARCHAR2
  IS
    l_org_id        NUMBER(15);
    l_adi           gl_code_combinations_kfv.concatenated_segments%TYPE;
  BEGIN
    CASE
      WHEN p_entidad_legal = 'Decolar.com Ltda'                          THEN l_org_id := 104;
      WHEN p_entidad_legal = 'Despegar Colombia S.A.S'                   THEN l_org_id := 116;
      WHEN p_entidad_legal = 'Despegar Colombia S.A.S(DES_COL_002)'      THEN l_org_id := 116;
      WHEN p_entidad_legal = 'Despegar Ecuador S.A'                      THEN l_org_id := 127;
      WHEN p_entidad_legal = 'Despegar Servicios S.A. de C.V.,'          THEN l_org_id := 102;
      WHEN p_entidad_legal = 'Despegar.com Chile S.A'                    THEN l_org_id := 108;
      WHEN p_entidad_legal = 'Despegar.com O.N.L.I.N.E. S.A.'            THEN l_org_id := 124;
      WHEN p_entidad_legal = 'Viajes Despegar.com O.N.L.I.N.E S.A'       THEN l_org_id := 124;
      WHEN p_entidad_legal = 'Despegar.com Panam� SA'                    THEN l_org_id := 114;
      WHEN p_entidad_legal = 'Despegar.com Per� S.A.C.'                  THEN l_org_id := 115;
      WHEN p_entidad_legal = 'Despegar.com USA, Inc'                     THEN l_org_id := 105;
      WHEN p_entidad_legal = 'Despegar.com.ar�S.A.'                      THEN l_org_id := 101;
      WHEN p_entidad_legal = 'Holidays S.A.'                             THEN l_org_id := 125;
      WHEN p_entidad_legal = 'La INC S.A.'                               THEN l_org_id := 602;
      WHEN p_entidad_legal = 'Servicios ON Line 3351 de Venezuela, C.A.' THEN l_org_id := 619;
      WHEN p_entidad_legal = 'Servicios ONLINE 3351 de Venezuela, C.A.'  THEN l_org_id := 619;
      WHEN p_entidad_legal = 'Servicios ONLINE S.A.S'                    THEN l_org_id := 605;
      WHEN p_entidad_legal = 'Servicios ONLINE SAS- Despegar.com'        THEN l_org_id := 605;
      WHEN p_entidad_legal = 'Servicios ONLINE S.A.S.'                   THEN l_org_id := 113;
      WHEN p_entidad_legal = 'Travel Reservations S.R.L'                 THEN l_org_id := 601;
    --WHEN p_entidad_legal = '' then l_org_id := 604; -- Espa�a
      ELSE l_org_id := 0;
    END CASE;
    --
    IF l_org_id <> 0 THEN
       l_adi := TO_CHAR(l_org_id)||'.'||REPLACE(p_adi,'61010','69999');
       RETURN( l_adi );
    ELSE
       RETURN( NULL );
    END IF;
  END get_adi;
  --
BEGIN
  ENABLE_DEBUG;
  print_log('+ '||l_procname);
  print_log('+ Params: p_id = '||p_id);
  --
  -- LOOP PRINCIPAL (XX_ADI).
  FOR radi IN ( SELECT * FROM xx_adi WHERE ID = p_id /*AND status = 'NEW'*/ ) LOOP
      print_log('  + Entro al LOOP ADI');
      -- LOOP Secundario (EBS).
      FOR rebs IN cebs ( p_email     => radi.email_address
                        ,p_worker_id => radi.worker_id ) LOOP   --> si no entra en este loop, intentara crear al empleado y usuario (si no esta en ebs, hay que crearlo).
          print_log('  + Entro al LOOP EBS');
          l_person_id := rebs.person_id;
          l_assign_id := rebs.assignment_id;
          l_user_id   := rebs.user_id;
          -- -------------------------------------------------------------------------------------------------
          -- Si el usuario ya estaba dado de baja, y la fecha de baja es posdatada, entonces podria tener una modificacon
          -- de datos; en cambio, si la fecha de baja < sysdate, entonces es una baja real => no se toca nada.
          -- -------------------------------------------------------------------------------------------------
          print_log('  Fecha de Baja (fnd_user.end_date) = '||radi.fh_baja);
          IF NVL(TO_DATE(radi.fh_baja,'dd/mm/yyyy'),SYSDATE) <= TRUNC(SYSDATE) THEN
             l_operation := 'B';  --> esto se resuelve en el usuario (procedure process_user).
          ELSE
             -- ----------------------------------------------------------------
             -- MODIFICACIoN: si no tiene Fh_Baja, entonces es una Modificacion.
             -- ----------------------------------------------------------------
             l_operation := 'M';
             l_superv_id := get_supervisor_id( p_superv_email => radi.superv_email
                                              ,x_errmsg       => l_errmsg );
             IF l_errmsg IS NOT NULL THEN
                RAISE e_error;
             END IF;
             l_adi := get_adi( radi.entidad_legal, radi.adi );
             l_ccid := get_ccid( p_concatenated_segments => l_adi
                                ,x_errmsg                => l_errmsg );
             IF l_errmsg IS NOT NULL THEN
                RAISE e_error;
             END IF;
             l_sob_id := get_sob_id( p_adi                  => l_adi
                                    ,x_chart_of_accounts_id => l_chart_of_accounts_id
                                    ,x_errmsg               => l_errmsg );
             IF l_errmsg IS NOT NULL THEN
                RAISE e_error;
             END IF;
             -- Actualizo solo si encuentro cambios en el full_name, employee_num, fh_nacim, fh_ingreso o email_address.
             IF radi.full_name <> rebs.full_name OR radi.employee_num <> rebs.employee_number OR radi.fh_ingreso <> rebs.start_date OR
                radi.fh_nacim <> rebs.date_of_birth OR LOWER(TRIM(radi.email_address)) <> LOWER(TRIM(rebs.email_address)) THEN
                UPDATE_EMPLOYEE( p_id     => radi.ID
                                ,x_errmsg => l_errmsg );
                IF l_errmsg IS NOT NULL THEN
                   RAISE e_error;
                END IF;
                l_status := 'PROC';
             END IF;
             -- Actualizo solo si encuentro cambios en el supervisor_id, ccid, o sob_id.
             IF (NVL(l_superv_id,0) > 0 AND NVL(l_ccid,0) > 0 AND NVL(l_sob_id,0) > 0) AND 
                (NVL(l_superv_id,0) <> rebs.supervisor_id OR NVL(l_ccid,0) <> rebs.default_code_comb_id OR NVL(l_sob_id,0) <> rebs.set_of_books_id) THEN
                -- Actualiza Per_Assignments_F.
                BEGIN
                  UPDATE per_assignments_f
                     SET supervisor_id        = l_superv_id
                        ,default_code_comb_id = l_ccid
                        ,set_of_books_id      = l_sob_id
                        ,last_update_date     = SYSDATE
                        ,last_updated_by      = fnd_global.user_id
                   WHERE assignment_id = rebs.assignment_id;
                EXCEPTION
                  WHEN others THEN
                       l_errmsg := 'ERROR al actualizar per_assignments_f con assignment_id = '||rebs.assignment_id||'; '||SQLERRM;
                       RAISE e_error;
                END; 
                --
                -- Lanza la sincronizacion del WF.
                POST_UPDATE( p_assignment_id => rebs.assignment_id
                            ,x_errmsg        => l_errmsg );
--             ELSE
--                l_err_format := formateo(l_errmsg_sup,l_errmsg_adi,l_errmsg_sob); -- elimina el ";" si no es necesario
--                l_status := 'ERROR';
             END IF;
             --
             WRITE_ADI( p_id                 => radi.ID
                       ,p_old_supervisor_id  => rebs.supervisor_id
                       ,p_old_superv_name    => rebs.d_supervisor_id
                       ,p_old_adi            => rebs.adi
                       ,p_old_sob_id         => rebs.set_of_books_id
                       ,p_operation          => 'M'
                       ,p_status             => 'PROC'
                       ,p_errmsg             => NULL
                       ,p_person_id          => rebs.person_id
                       ,p_assignment_id      => rebs.assignment_id
                       ,p_user_id            => rebs.user_id
                       ,x_errmsg             => l_errmsg );
             IF l_errmsg IS NOT NULL THEN
                RAISE e_error;
             END IF;
          END IF;
          print_log('  - Entro al LOOP EBS');
      END LOOP;
      -- -----------------------------------------------------------------------
      -- ALTA: si no lo encontro en EBS, entonces es un Alta.
      -- -----------------------------------------------------------------------
      IF l_operation IS NULL THEN
         l_operation := 'A';
         INSERT_EMPLOYEE( p_id        => radi.ID
                         ,x_person_id => l_person_id
                         ,x_assign_id => l_assign_id
--                         ,x_user_id   => l_user_id
                         ,x_errmsg    => l_errmsg );
         --
         IF NVL(l_person_id,0) > 0 AND NVL(l_assign_id,0) > 0 /*AND NVL(l_user_id,0) > 0*/ THEN
            WRITE_ADI( p_id                 => radi.ID
                      ,p_operation          => 'A'
                      ,p_status             => 'PROC'
                      ,p_person_id          => l_person_id
                      ,p_assignment_id      => l_assign_id
                      ,p_user_id            => NULL --l_user_id
                      ,x_errmsg             => l_errmsg );
             IF l_errmsg IS NOT NULL THEN
                RAISE e_error;
             END IF;
         ELSE
            BEGIN
              UPDATE XX_ADI
                 SET operation = 'A' --> Alta
                    ,status    = 'ERROR'  --> para que pueda procesar nuevamente.
                    ,errmsg    = NVL(l_errmsg,'NO se recupero el person_id y/o el assignment_id (NO significa que NO lo haya creado')
               WHERE ID = radi.ID;
            EXCEPTION
              WHEN others THEN
                   l_errmsg := 'ERROR en Alta (2) al grabar xx_adi con ID = '||p_id||'; '||SQLERRM;
                   RAISE e_error;
            END; 
         END IF;
      END IF;
      print_log('  - Entro al LOOP ADI');
  END LOOP;
  -------
  COMMIT;
  -------
  print_log('  l_operation = '||l_operation);
  print_log('- '||l_procname);
EXCEPTION
  WHEN e_error THEN
       x_errmsg := l_errmsg;
       print_log(l_errmsg);
       WRITE_ADI( p_id                 => p_id
                 ,p_operation          => l_operation
                 ,p_status             => 'ERROR'
                 ,p_errmsg             => l_errmsg
                 ,p_person_id          => l_person_id
                 ,p_assignment_id      => l_assign_id
                 ,p_user_id            => l_user_id
                 ,x_errmsg             => l_errmsg );
       IF l_errmsg IS NOT NULL THEN
          print_log('ERROR al grabar XX_ADI; l_errmsg = '||l_errmsg);
       END IF;
  WHEN others THEN
       x_errmsg := NVL(l_errmsg,'')||' ERROR General en '||l_procname||'; '||SQLERRM;
       print_log(x_errmsg);
END process_employee;
  
--/******************************************************************************\
-- Name   : Insert_Employee
-- Purpose: Crea un nuevo Empleado.
-- Params : p_id: es el ID de la tabla XX_ADI que se debe procesar.
-- Notes  : Este proceso es llamado desde el process_adi, cuando se detecta que
--          un empleado informado en planilla no existe en EBS.
-- History: 28/12/2016  DVartabedian  Created
--
--\******************************************************************************/
PROCEDURE insert_employee( p_id         IN NUMBER
                          ,x_person_id OUT NUMBER
                          ,x_assign_id OUT NUMBER
--                          ,x_user_id   OUT NUMBER
                          ,x_errmsg    OUT VARCHAR2)
IS
  -- Constantes.
  l_procname           CONSTANT VARCHAR2(70)  := c_procname||'.INSERT_EMPLOYEE';
  -- Variables.
  l_first_name                  per_people_f.first_name%TYPE;
  l_last_name                   per_people_f.last_name%TYPE;
  l_full_name                   per_people_f.full_name%TYPE;
  l_order_name                  per_people_f.order_name%TYPE;
  l_global_name                 per_people_f.GLOBAL_NAME%TYPE;
  l_local_name                  per_people_f.local_name%TYPE;
  l_duplicate_flag              VARCHAR2(1);
  l_existe                      VARCHAR2(1);
  l_business_group_id           per_people_f.business_group_id%TYPE := TO_NUMBER(fnd_profile.VALUE('PER_BUSINESS_GROUP_ID'));
  l_rowid                       VARCHAR2(256);
  l_person_id                   per_people_f.person_id%TYPE;
  l_person_type_id              per_person_types.person_type_id%TYPE;
  l_current_employee_flag       per_startup_person_types.current_employee_flag%TYPE;
  l_current_applicant_flag      per_startup_person_types.current_applicant_flag%TYPE;
  l_current_emp_or_apl_flag     per_startup_person_types.current_emp_or_apl_flag%TYPE;
--  l_session_date                DATE;
  l_end_of_time                 DATE;
  l_assignment_id               per_assignments.assignment_id%TYPE;
  l_assignment_status_type_id   per_assignments.assignment_status_type_id%TYPE;
  l_assignment_sequence         per_assignments.assignment_sequence%TYPE;
  l_primary_flag                VARCHAR2(1);
  l_assignment_number           per_assignments.assignment_number%TYPE;
  l_period_of_service_id        per_periods_of_service.period_of_service_id%TYPE;
  l_superv_id                   per_assignments_f.supervisor_id%TYPE;
  l_ccid                        gl_code_combinations.code_combination_id%TYPE;
  l_sob_id                      gl_sets_of_books.set_of_books_id%TYPE;
  l_chart_of_accounts_id        gl_ledgers.chart_of_accounts_id%TYPE;
--  l_sob_name                    gl_sets_of_books.NAME%TYPE;
  l_errmsg                      VARCHAR2(2000);
  l_asg_rec                     per_asg_shd.g_rec_type;
  l_user_id                     fnd_user.user_id%TYPE;
  l_user_name                   fnd_user.user_name%TYPE;
  exc_person                    EXCEPTION;
  exc_assign                    EXCEPTION;
  exc_user                      EXCEPTION;
BEGIN
--  enable_debug( p_type => 'LOG' );
  print_log('+ '||l_procname);
--  print_out('Empleados dados de Alta el '||TO_CHAR(SYSDATE,'dd/mm/yyyy hh24:mi'));
--  print_out(' ');
--  print_out('NUMERO|NOMBRE|EMAIL|SUPERVISOR|ADI|USUARIO EBS');
--  print_log('Los siguientes Empleados NO pudieron ser dados de Alta');
--  print_log(' ');
--  print_log('FULL_NAME|EMAIL|SUPERVISOR|PERSON_ID|ASSIGN_ID|USER_NAME|USER_ID|ERROR');
  --
  FOR radi IN ( SELECT * FROM xx_adi WHERE ID = p_id /*AND status = 'NEW'*/ ) LOOP
      --
      -- Bloque Principal
      BEGIN
        -- =======================================
        -- Comprueba si el Empleado existe.
        -- =======================================
        SELECT DECODE( COUNT(1), 0, 'N', 'Y' )
          INTO l_existe
          FROM per_all_people_f
         WHERE TO_NUMBER(NVL(attribute2,'0')) = radi.worker_id;
--         WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(radi.email_address));
        --
--        IF l_existe = 'N' AND get_supervisor_id( p_superv_email => radi.superv_email
--                                                ,x_errmsg       => l_errmsg ) IS NULL THEN --> no me interesa lo que dice l_errmsg, porque seguro dice que no encontro al supervisor.
--           l_existe := 'N';
--        ELSE
--           l_existe := 'Y';
--        END IF;
        --
        IF l_existe = 'Y' THEN
           l_errmsg := 'Empleado Existente (worker_id repetido: '||TO_CHAR(radi.worker_id)||')';
           RAISE exc_person;
        END IF;
        -- =============================
        -- PRE-INSERT PER_PEOPLE_F
        -- =============================
        l_first_name := TRIM(SUBSTR(radi.full_name,INSTR(radi.full_name,',')+1));
        l_last_name  := TRIM(SUBSTR(radi.full_name,1,INSTR(radi.full_name,',')-1));
        print_log('+ Verifica si el Nombre DEL Empleado esta duplicado: full_name = '||NVL(radi.full_name,'NULL')||'; l_last_name = '||NVL(l_last_name,'NULL')||'; l_first_name = '||NVL(l_first_name,'NULL'));
        BEGIN
          hr_person_name.derive_person_names
                       ( p_format_name         => NULL
                        ,p_business_group_id   => l_business_group_id
                        ,p_person_id           => NULL
                        ,p_first_name          => l_first_name
                        ,p_middle_names        => NULL
                        ,p_last_name           => l_last_name
                        ,p_known_as            => NULL
                        ,p_title               => NULL
                        ,p_suffix              => NULL
                        ,p_pre_name_adjunct    => NULL
                        ,p_date_of_birth       => TO_DATE(radi.fh_nacim,'dd/mm/yyyy')
                        ,p_full_name           => l_full_name      -- OUT
                        ,p_order_name          => l_order_name     -- OUT
                        ,p_global_name         => l_global_name    -- OUT
                        ,p_local_name          => l_local_name     -- OUT
                        ,p_duplicate_flag      => l_duplicate_flag -- OUT
                       );
          print_log('- Verifica si el Nombre DEL Empleado esta duplicado; l_existe = '||l_existe);
          IF l_duplicate_flag = 'Y' THEN
             l_errmsg := 'El nombre '||radi.full_name||' ya existe - NO se procesa';
--             print_log(x_errmsg);
             RAISE exc_person;
          END IF;
        END;
        --
        -- Verifica si el Nro Empleado está duplicado (esto reemplaza al proc hr_person.validate_unique_number)');
        BEGIN
          print_log('+ Verifica si el Nro Empleado esta duplicado; employee_number = '||radi.employee_num);
          SELECT DECODE( COUNT(1), 0, 'N', 'Y' )
            INTO l_existe
            FROM per_all_people_f  pp
           WHERE 1=1
             AND pp.business_group_id = l_business_group_id
             AND (   (pp.employee_number = radi.employee_num)
                  OR (pp.npw_number = radi.employee_num AND EXISTS (SELECT NULL
                                                                      FROM per_business_groups pbg
                                                                     WHERE pbg.business_group_id = l_business_group_id
                                                                       AND NVL(method_of_generation_cwk_num,hr_api.g_varchar2) = 'E'))
                 );
          print_log('- Verifica si el Nro Empleado esta duplicado; l_existe = '||l_existe);
          IF l_existe = 'Y' THEN
             l_errmsg := 'El Nro Empleado '||radi.employee_num||' de '||radi.full_name||' ya existe - No se procesa';
--             print_log(x_errmsg);
             RAISE exc_person;
          END IF;
        END;
        -- =================================
        -- PRE-INSERT ASSIGNMENTS
        -- =================================
  --      print_log('+ Get_Supervisor_Id');
        l_superv_id := get_supervisor_id( p_superv_email => radi.superv_email
                                         ,x_errmsg       => l_errmsg );
  --      print_log('- Get_Supervisor_Id; l_superv_id = '||l_superv_id);
        IF NVL(l_superv_id,0) = 0 THEN
           l_errmsg := 'NO se encontro el Supervisor de '||radi.full_name||'; ID = '||radi.ID||'; '||l_errmsg;
--           print_log(x_errmsg);
           RAISE exc_assign;
        END IF;
        --
  --      print_log('+ Get_CCID');
        l_ccid := get_ccid( p_concatenated_segments => radi.adi
                           ,x_errmsg                => l_errmsg );
  --      print_log('- Get_CCID; l_ccid = '||l_ccid);
        IF NVL(l_ccid,0) = 0 THEN
           l_errmsg := 'NO se encontro el CCID de '||radi.full_name||'; ID = '||radi.ID||'; '||l_errmsg;
  --         print_log(x_errmsg);
           RAISE exc_assign;
        END IF;
        --
  --      print_log('+ Get_SOB_Id');
        l_sob_id := get_sob_id( p_adi                  => radi.adi
                               ,x_chart_of_accounts_id => l_chart_of_accounts_id
                               ,x_errmsg               => l_errmsg );
  --      print_log('- Get_SOB_Id; l_sob_id = '||l_sob_id);
        IF NVL(l_sob_id,0) = 0 THEN
           l_errmsg := 'NO se encontro el Set of Books de '||radi.full_name||'; ID = '||radi.ID||'; '||l_errmsg;
  --         print_log(x_errmsg);
           RAISE exc_assign;
        END IF;
        --
        -- =================================
        -- PERSON_EVENT => 'PRE-INSERT'
        -- =================================
        print_log('+ PRE-INSERT');
        BEGIN
          SELECT ppt.person_type_id
                ,pst.current_employee_flag
                ,pst.current_applicant_flag
                ,pst.current_emp_or_apl_flag
--                ,TRUNC(SYSDATE)
                ,TO_DATE('31/12/4712','DD/MM/YYYY')
            INTO l_person_type_id
                ,l_current_employee_flag
                ,l_current_applicant_flag
                ,l_current_emp_or_apl_flag
--                ,l_session_date
                ,l_end_of_time
            FROM per_person_types ppt
                ,per_startup_person_types pst
           WHERE ppt.business_group_id = l_business_group_id
             AND ppt.system_person_type = pst.system_person_type
             AND ppt.system_person_type = DECODE(fnd_profile.VALUE('RESP_APPL_ID'),810,'OTHER','EMP')
             AND ppt.default_flag = 'Y'
             AND pst.default_flag = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
               l_errmsg := 'Error al buscar el Person_Type_Id para '||radi.full_name||' (Id = '||radi.ID||'); '||REPLACE(SQLERRM,CHR(10),'; ');
  --             print_log(x_errmsg);
               RAISE exc_person;
        END;
        print_log('- PRE-INSERT');
        -- =================================
        -- ON-INSERT PER_PEOPLE_F
        -- =================================
        BEGIN
          print_log('+ PER_PEOPLE_V14_PKG.Insert_Row');
          PER_PEOPLE_V14_PKG.Insert_Row
                           ( X_Rowid                       => l_rowid                                   --> IN OUT
                            ,X_Person_Id                   => l_person_id                               --> IN OUT
                            ,X_Party_Id                    => NULL                                      -- :CTL.Party_Id -- Default NULL
                            ,X_Effective_Start_Date        => TO_DATE(radi.fh_ingreso,'dd/mm/yyyy')     -- :person.Effective_Start_Date,
                            ,X_Effective_End_Date          => l_end_of_time                             -- :person.Effective_End_Date,
                            ,X_Business_Group_Id           => l_business_group_id                       -- :person.Business_Group_Id,
                            ,X_Person_Type_Id              => l_person_type_id                          -- :person.Person_Type_Id,
                            ,X_Last_Name                   => l_last_name                               -- :person.Last_Name,
                            ,X_Start_Date                  => TO_DATE(radi.fh_ingreso,'dd/mm/yyyy')     -- :person.Start_Date,
                            ,X_Applicant_Number            => NULL                                      -- :person.Applicant_Number,
                            ,X_Comment_Id                  => NULL                                      -- :person.Comment_Id,
                            ,X_Current_Applicant_Flag      => l_current_applicant_flag                  -- :person.Current_Applicant_Flag,
                            ,X_Current_Emp_Or_Apl_Flag     => l_current_emp_or_apl_flag                 -- :person.Current_Emp_Or_Apl_Flag,
                            ,X_Current_Employee_Flag       => l_current_employee_flag                   -- :person.Current_Employee_Flag,
                            ,X_Date_Employee_Data_Verified => NULL                                      -- :person.Date_Employee_Data_Verified,
                            ,X_Date_Of_Birth               => TO_DATE(radi.fh_nacim,'dd/mm/yyyy')       -- :person.Date_Of_Birth,
                            ,X_Email_Address               => radi.email_address                        -- :person.Email_Address,
                            ,X_Employee_Number             => radi.employee_num                         -- :person.Employee_Number,
                            ,X_Expense_Check_To_Address    => NULL                                      -- :person.Expense_Check_Send_To_Address,
                            ,X_First_Name                  => l_first_name                              -- :person.First_Name,
                            ,X_Full_Name                   => l_full_name                               -- :person.Full_Name,
                            ,X_Known_As                    => NULL                                      -- :person.Known_As,
                            ,X_Marital_Status              => NULL                                      -- :person.Marital_Status,
                            ,X_Middle_Names                => NULL                                      -- :person.Middle_Names,
                            ,X_Nationality                 => NULL                                      -- :person.Nationality,
                            ,X_National_Identifier         => NULL                                      -- :person.National_Identifier,
                            ,X_Previous_Last_Name          => NULL                                      -- :person.Previous_Last_Name,
                            ,X_Registered_Disabled_Flag    => NULL                                      -- :person.Registered_Disabled_Flag,
                            ,X_Sex                         => NULL                                      -- :person.Sex,
                            ,X_Title                       => NULL                                      -- :person.Title,
                            ,X_Vendor_Id                   => NULL                                      -- :person.Vendor_Id,
                            ,X_Work_Telephone              => NULL                                      -- :person.Work_Telephone,
                            ,X_Attribute_Category          => NULL                                      -- :person.Attribute_Category,
                            ,X_Attribute1                  => NULL                                      -- :person.Attribute1,
                            ,X_Attribute2                  => TO_CHAR(radi.worker_id)                   -- :person.Attribute2,
                            ,X_Attribute3                  => NULL                                      -- :person.Attribute3,
                            ,X_Attribute4                  => NULL                                      -- :person.Attribute4,
                            ,X_Attribute5                  => NULL                                      -- :person.Attribute5,
                            ,X_Attribute6                  => NULL                                      -- :person.Attribute6,
                            ,X_Attribute7                  => NULL                                      -- :person.Attribute7,
                            ,X_Attribute8                  => NULL                                      -- :person.Attribute8,
                            ,X_Attribute9                  => NULL                                      -- :person.Attribute9,
                            ,X_Attribute10                 => NULL                                      -- :person.Attribute10,
                            ,X_Attribute11                 => NULL                                      -- :person.Attribute11,
                            ,X_Attribute12                 => NULL                                      -- :person.Attribute12,
                            ,X_Attribute13                 => NULL                                      -- :person.Attribute13,
                            ,X_Attribute14                 => NULL                                      -- :person.Attribute14,
                            ,X_Attribute15                 => NULL                                      -- :person.Attribute15,
                            ,X_Attribute16                 => NULL                                      -- :person.Attribute16,
                            ,X_Attribute17                 => NULL                                      -- :person.Attribute17,
                            ,X_Attribute18                 => NULL                                      -- :person.Attribute18,
                            ,X_Attribute19                 => NULL                                      -- :person.Attribute19,
                            ,X_Attribute20                 => NULL                                      -- :person.Attribute20,
                            ,X_Attribute21                 => NULL                                      -- :person.Attribute21,
                            ,X_Attribute22                 => NULL                                      -- :person.Attribute22,
                            ,X_Attribute23                 => NULL                                      -- :person.Attribute23,
                            ,X_Attribute24                 => NULL                                      -- :person.Attribute24,
                            ,X_Attribute25                 => NULL                                      -- :person.Attribute25,
                            ,X_Attribute26                 => NULL                                      -- :person.Attribute26,
                            ,X_Attribute27                 => NULL                                      -- :person.Attribute27,
                            ,X_Attribute28                 => NULL                                      -- :person.Attribute28,
                            ,X_Attribute29                 => NULL                                      -- :person.Attribute29,
                            ,X_Attribute30                 => NULL                                      -- :person.Attribute30,
                            ,X_Per_Information_Category    => NULL                                      -- :person.Per_Information_Category,
                            ,X_Per_Information1            => NULL                                      -- :person.Per_Information1,
                            ,X_Per_Information2            => NULL                                      -- :person.Per_Information2,
                            ,X_Per_Information3            => NULL                                      -- :person.Per_Information3,
                            ,X_Per_Information4            => NULL                                      -- :person.Per_Information4,
                            ,X_Per_Information5            => NULL                                      -- :person.Per_Information5,
                            ,X_Per_Information6            => NULL                                      -- :person.Per_Information6,
                            ,X_Per_Information7            => NULL                                      -- :person.Per_Information7,
                            ,X_Per_Information8            => NULL                                      -- :person.Per_Information8,
                            ,X_Per_Information9            => NULL                                      -- :person.Per_Information9,
                            ,X_Per_Information10           => NULL                                      -- :person.Per_Information10,
                            ,X_Per_Information11           => NULL                                      -- :person.Per_Information11,
                            ,X_Per_Information12           => NULL                                      -- :person.Per_Information12,
                            ,X_Per_Information13           => NULL                                      -- :person.Per_Information13,
                            ,X_Per_Information14           => NULL                                      -- :person.Per_Information14,
                            ,X_Per_Information15           => NULL                                      -- :person.Per_Information15,
                            ,X_Per_Information16           => NULL                                      -- :person.Per_Information16,
                            ,X_Per_Information17           => NULL                                      -- :person.Per_Information17,
                            ,X_Per_Information18           => NULL                                      -- :person.Per_Information18,
                            ,X_Per_Information19           => NULL                                      -- :person.Per_Information19,
                            ,X_Per_Information20           => NULL                                      -- :person.Per_Information20,
                            ,X_Per_Information21           => NULL                                      -- :person.Per_Information21,
                            ,X_Per_Information22           => NULL                                      -- :person.Per_Information22,
                            ,X_Per_Information23           => NULL                                      -- :person.Per_Information23,
                            ,X_Per_Information24           => NULL                                      -- :person.Per_Information24,
                            ,X_Per_Information25           => NULL                                      -- :person.Per_Information25,
                            ,X_Per_Information26           => NULL                                      -- :person.Per_Information26,
                            ,X_Per_Information27           => NULL                                      -- :person.Per_Information27,
                            ,X_Per_Information28           => NULL                                      -- :person.Per_Information28,
                            ,X_Per_Information29           => NULL                                      -- :person.Per_Information29,
                            ,X_Per_Information30           => NULL                                      -- :person.Per_Information30,
                            ,X_Last_Update_Date            => SYSDATE                                   -- :person.Last_Update_Date,
                            ,X_Last_Updated_By             => fnd_global.user_id                        -- :person.Last_Updated_By,
                            ,X_Last_Update_Login           => fnd_global.login_id                       -- :person.Last_Update_Login,
                            ,X_Created_By                  => fnd_global.user_id                        -- :person.Created_By,
                            ,X_Creation_Date               => SYSDATE                                   -- :person.Creation_Date,
                            ,X_Order_Name                  => l_order_name                              -- :person.order_name,
                            ,X_Global_Name                 => l_global_name                             -- :person.global_name,
                            ,X_Local_Name                  => l_local_name                              -- :person.local_name
                            ,X_Period_Of_Service_Id        => l_period_of_service_id );
          print_log('- PER_PEOPLE_V14_PKG.Insert_Row');
          print_log('  l_rowid = '||l_rowid);
          print_log('  l_person_id = '||l_person_id);
          print_log('  l_period_of_service_id = '||l_period_of_service_id);
          -- Lleno la variable de salida.
          IF NVL(l_person_id,0) > 0 THEN
             x_person_id := l_person_id;
          ELSE
             l_errmsg := 'No se pudo crear el Empleado (Per_People_F); '||REPLACE(SQLERRM,CHR(10),'; ');
             RAISE exc_person;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
               l_errmsg := 'No se pudo crear el Empleado (Per_People_F); '||REPLACE(SQLERRM,CHR(10),'; ');
               RAISE exc_person;
        END;
        -- =================================
        -- ON-INSERT PER_ASSIGNMENTS_F
        -- =================================
        BEGIN
        print_log('+ PER_ASSIGNMENTS_V7_PKG.Insert_Row');
          PER_ASSIGNMENTS_V7_PKG.Insert_Row
                               ( X_Rowid                        => l_rowid                              -- :assignment.Row_Id,
                                ,X_Assignment_Id                => l_assignment_id                      -- :assignment.Assignment_Id,
                                ,X_Effective_Start_Date         => TO_DATE(radi.fh_ingreso,'dd/mm/yyyy')-- :assignment.Effective_Start_Date,
                                ,X_Effective_End_Date           => l_end_of_time                        -- :assignment.Effective_End_Date,
                                ,X_Business_Group_Id            => l_business_group_id                  -- :assignment.Business_Group_Id,
                                ,X_Recruiter_Id                 => NULL                                 -- :assignment.Recruiter_Id,
                                ,X_Grade_Id                     => NULL                                 -- :assignment.Grade_Id,
                                ,X_Position_Id                  => NULL                                 -- :assignment.Position_Id,
                                ,X_Job_Id                       => NULL                                 -- :assignment.Job_Id,
                                ,X_Assignment_Status_Type_Id    => l_assignment_status_type_id          -- :assignment.Assignment_Status_Type_Id,
                                ,X_Payroll_Id                   => NULL                                 -- :assignment.Payroll_Id,
                                ,X_Location_Id                  => NULL                                 -- :assignment.Location_Id,
                                ,X_Person_Referred_By_Id        => NULL                                 -- :assignment.Person_Referred_By_Id,
                                ,X_Supervisor_Id                => l_superv_id                          -- :assignment.Supervisor_Id,
                                ,X_Special_Ceiling_Step_Id      => NULL                                 -- :assignment.Special_Ceiling_Step_Id,
                                ,X_Person_Id                    => l_person_id                          -- :assignment.Person_Id,
                                ,X_Employee_Number              => radi.employee_num                    -- :PERSON.Employee_Number, per_assignments_f
                                ,X_Recruitment_Activity_Id      => NULL                                 -- :assignment.Recruitment_Activity_Id,
                                ,X_Source_Organization_Id       => NULL                                 -- :assignment.Source_Organization_Id,
                                ,X_Organization_Id              => l_business_group_id                  -- :assignment.Organization_Id,
                                ,X_People_Group_Id              => NULL                                 -- :assignment.People_Group_Id,
                                ,X_Soft_Coding_Keyflex_Id       => NULL                                 -- :assignment.Soft_Coding_Keyflex_Id,
                                ,X_Vacancy_Id                   => NULL                                 -- :assignment.Vacancy_Id,
                                ,X_Pay_Basis_Id                 => NULL                                 -- :assignment.Pay_Basis_Id,
                                ,X_Assignment_Sequence          => l_assignment_sequence                -- :assignment.Assignment_Sequence,
                                ,X_Assignment_Type              => 'E'                                  -- :assignment.Assignment_Type,
                                ,X_Primary_Flag                 => l_primary_flag                       -- :assignment.Primary_Flag,
                                ,X_Application_Id               => NULL                                 -- :assignment.Application_Id,
                                ,X_Assignment_Number            => l_assignment_number                  -- :assignment.Assignment_Number,
                                ,X_Change_Reason                => NULL                                 -- :assignment.Change_Reason,
                                ,X_Comment_Id                   => NULL                                 -- :assignment.Comment_Id,
                                ,X_Date_Probation_End           => NULL                                 -- :assignment.Date_Probation_End,
                                ,X_Default_Code_Comb_Id         => l_ccid                               -- :assignment.Default_Code_Comb_Id,
                                ,X_Employment_Category          => NULL                                 -- :assignment.Employment_Category,
                                ,X_Frequency                    => NULL                                 -- :assignment.Frequency,
                                ,X_Internal_Address_Line        => NULL                                 -- :assignment.Internal_Address_Line,
                                ,X_Manager_Flag                 => NULL                                 -- :assignment.Manager_Flag,
                                ,X_Normal_Hours                 => NULL                                 -- :assignment.Normal_Hours,
                                ,X_Perf_Review_Period           => NULL                                 -- :assignment.Perf_Review_Period,
                                ,X_Perf_Review_Period_Frequency => NULL                                 -- :assignment.Perf_Review_Period_Frequency,
                                ,X_Period_Of_Service_Id         => l_period_of_service_id               -- :assignment.Period_Of_Service_Id,
                                ,X_Probation_Period             => NULL                                 -- :assignment.Probation_Period,
                                ,X_Probation_Unit               => NULL                                 -- :assignment.Probation_Unit,
                                ,X_Sal_Review_Period            => NULL                                 -- :assignment.Sal_Review_Period,
                                ,X_Sal_Review_Period_Frequency  => NULL                                 -- :assignment.Sal_Review_Period_Frequency,
                                ,X_Set_Of_Books_Id              => l_sob_id                             -- :assignment.Set_Of_Books_Id,
                                ,X_Source_Type                  => NULL                                 -- :assignment.Source_Type,
                                ,X_Time_Normal_Finish           => NULL                                 -- :assignment.Time_Normal_Finish,
                                ,X_Time_Normal_Start            => NULL                                 -- :assignment.Time_Normal_Start,
                                ,X_Ass_Attribute_Category       => NULL                                 -- :assignment.Ass_Attribute_Category,
                                ,X_Ass_Attribute1               => NULL                                 -- :assignment.Ass_Attribute1,
                                ,X_Ass_Attribute2               => NULL                                 -- :assignment.Ass_Attribute2,
                                ,X_Ass_Attribute3               => NULL                                 -- :assignment.Ass_Attribute3,
                                ,X_Ass_Attribute4               => NULL                                 -- :assignment.Ass_Attribute4,
                                ,X_Ass_Attribute5               => NULL                                 -- :assignment.Ass_Attribute5,
                                ,X_Ass_Attribute6               => NULL                                 -- :assignment.Ass_Attribute6,
                                ,X_Ass_Attribute7               => NULL                                 -- :assignment.Ass_Attribute7,
                                ,X_Ass_Attribute8               => NULL                                 -- :assignment.Ass_Attribute8,
                                ,X_Ass_Attribute9               => NULL                                 -- :assignment.Ass_Attribute9,
                                ,X_Ass_Attribute10              => NULL                                 -- :assignment.Ass_Attribute10,
                                ,X_Ass_Attribute11              => NULL                                 -- :assignment.Ass_Attribute11,
                                ,X_Ass_Attribute12              => NULL                                 -- :assignment.Ass_Attribute12,
                                ,X_Ass_Attribute13              => NULL                                 -- :assignment.Ass_Attribute13,
                                ,X_Ass_Attribute14              => NULL                                 -- :assignment.Ass_Attribute14,
                                ,X_Ass_Attribute15              => NULL                                 -- :assignment.Ass_Attribute15,
                                ,X_Ass_Attribute16              => NULL                                 -- :assignment.Ass_Attribute16,
                                ,X_Ass_Attribute17              => NULL                                 -- :assignment.Ass_Attribute17,
                                ,X_Ass_Attribute18              => NULL                                 -- :assignment.Ass_Attribute18,
                                ,X_Ass_Attribute19              => NULL                                 -- :assignment.Ass_Attribute19,
                                ,X_Ass_Attribute20              => NULL                                 -- :assignment.Ass_Attribute20,
                                ,X_Ass_Attribute21              => NULL                                 -- :assignment.Ass_Attribute21,
                                ,X_Ass_Attribute22              => NULL                                 -- :assignment.Ass_Attribute22,
                                ,X_Ass_Attribute23              => NULL                                 -- :assignment.Ass_Attribute23,
                                ,X_Ass_Attribute24              => NULL                                 -- :assignment.Ass_Attribute24,
                                ,X_Ass_Attribute25              => NULL                                 -- :assignment.Ass_Attribute25,
                                ,X_Ass_Attribute26              => NULL                                 -- :assignment.Ass_Attribute26,
                                ,X_Ass_Attribute27              => NULL                                 -- :assignment.Ass_Attribute27,
                                ,X_Ass_Attribute28              => NULL                                 -- :assignment.Ass_Attribute28,
                                ,X_Ass_Attribute29              => NULL                                 -- :assignment.Ass_Attribute29,
                                ,X_Ass_Attribute30              => NULL                                 -- :assignment.Ass_Attribute30,
                                ,X_Last_Update_Date             => SYSDATE                              -- :assignment.Last_Update_Date,
                                ,X_Last_Updated_By              => fnd_global.user_id                   -- :assignment.Last_Updated_By,
                                ,X_Last_Update_Login            => fnd_global.login_id                  -- :assignment.Last_Update_Login,
                                ,X_Created_By                   => fnd_global.user_id                   -- :assignment.Created_By,
                                ,X_Creation_Date                => SYSDATE                              -- :assignment.Creation_Date,
                                ,X_Title                        => NULL );                              -- :assignment.Title
          print_log('- PER_ASSIGNMENTS_V7_PKG.Insert_Row');
          print_log('  l_assignment_id = '||l_assignment_id);
--          print_log('  l_assignment_status_type_id = '||l_assignment_status_type_id);
--          print_log('  l_assignment_sequence = '||l_assignment_sequence);
--          print_log('  l_primary_flag = '||l_primary_flag);
          print_log('  l_assignment_number = '||l_assignment_number);
          IF NVL(l_assignment_id,0) > 0 THEN
             x_assign_id := l_assignment_id;
          ELSE
             l_errmsg := 'No se pudo crear las asignaciones del Empleado (Per_Assignment_F); Person_Id = '||l_person_id||'); '||REPLACE(SQLERRM,CHR(10),'; ');
             RAISE exc_assign;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
               l_errmsg := 'No se pudo crear las asignaciones del Empleado (Per_Assignment_F); Person_Id = '||l_person_id||'); '||REPLACE(SQLERRM,CHR(10),'; ');
               RAISE exc_assign;
        END;
        --
        BEGIN
          l_asg_rec.assignment_id        := l_Assignment_Id;
          l_asg_rec.position_id          := NULL;
          l_asg_rec.person_id            := l_Person_Id;
          l_asg_rec.effective_start_date := TO_DATE(radi.fh_ingreso,'dd/mm/yyyy');
          l_asg_rec.effective_end_date   := l_end_of_time;
          --
          -- Lleno la variable de salida.
--          x_assign_id := l_assignment_id;
          --
          print_log('+ Per_Pqh_Shr.Per_Asg_Wf_Sync');
          per_pqh_shr.per_asg_wf_sync( p_event                 => NULL
                                      ,p_rec                   => l_asg_rec
                                      ,p_old_position_id       => NULL              -- :ASSIGNMENT.S_POSITION_ID,
                                      ,p_effective_date        => TRUNC(SYSDATE)
                                      ,p_validation_start_date => NULL
                                      ,p_validation_end_date   => NULL
                                      ,p_datetrack_mode        => NULL );
          print_log('- Per_Pqh_Shr.Per_Asg_Wf_Sync');
        EXCEPTION
          WHEN OTHERS THEN
               l_errmsg := 'Error al sincronizar el Empleado; Person_Id = '||l_person_id||'; '||REPLACE(SQLERRM,CHR(10),'; ');
               RAISE exc_assign;
        END;
      EXCEPTION
        WHEN exc_person OR exc_assign THEN
             x_errmsg := l_errmsg;
             print_log(l_errmsg);
        WHEN exc_user THEN
             x_errmsg := l_errmsg;
             print_log(l_errmsg);
        WHEN OTHERS THEN
             l_errmsg := 'ERROR General; '||REPLACE(SQLERRM,CHR(10),'; ');
             x_errmsg := l_errmsg;
             print_log(l_errmsg);
      END;  -- Bloque Principal
  END LOOP;
END insert_employee;

--/******************************************************************************\
-- Name   : Update_Employee
-- Purpose: Actualiza datos de un Empleado.
-- Params : p_id: es el ID de la tabla XX_ADI que se debe procesar.
-- Notes  : Este proceso es llamado desde el process_adi, cuando se detecta que
--          un empleado informado en planilla no existe en EBS.
--          --  X_Hire_Date         - Modified Hire Date.
--          --  X_orig_hire_date    - Original Hire Date.
-- History: 28/12/2016  DVartabedian  Created
--
--\******************************************************************************/
PROCEDURE update_employee( p_id         IN NUMBER
                          ,x_errmsg    OUT VARCHAR2)
IS
  -- Constantes.
  l_procname           CONSTANT VARCHAR2(70)  := c_procname||'.UPDATE_EMPLOYEE';
  l_email_unique                NUMBER;
  l_current_appl_id             fnd_responsibility.data_group_application_id%TYPE;
  l_fh_ingreso                  DATE;
  l_fh_nacim                    DATE;
  l_start_date                  DATE;
  l_errmsg                      VARCHAR2(2000);
  l_full_name                   per_people_f.full_name%TYPE;
  l_order_name                  per_people_f.order_name%TYPE;
  l_global_name                 per_people_f.GLOBAL_NAME%TYPE;
  l_local_name                  per_people_f.local_name%TYPE;
  l_duplicate_flag              VARCHAR2(1);
  l_business_group_id           per_people_f.business_group_id%TYPE := TO_NUMBER(fnd_profile.VALUE('PER_BUSINESS_GROUP_ID'));
  l_assign_id                   per_assignments_f.assignment_id%TYPE;
  l_effective_end_date          per_people_f.effective_end_date%TYPE;
--  d_termination_date            per_periods_of_service.actual_termination_date%TYPE;
  l_first_name                  per_people_f.first_name%TYPE;
  l_last_name                   per_people_f.last_name%TYPE;
  e_error                       EXCEPTION;
  --
  CURSOR ccur( --p_email_address IN VARCHAR2 ) IS
               p_worker_id IN NUMBER ) IS 
         SELECT ROWIDTOCHAR(pp.ROWID) row_id
               ,ps.actual_termination_date  d_termination_date
               ,ps.date_start  hire_date
               ,ps.period_of_service_id
               ,pp.* 
           FROM per_periods_of_service ps
               ,per_people_f           pp 
          WHERE 1=1
            AND TO_NUMBER(NVL(pp.attribute2,'0')) = p_worker_id
--            and LOWER(TRIM(email_address)) = LOWER(TRIM(p_email_address))
            AND ps.person_id(+) = pp.person_id;
  --
  PROCEDURE derive_person_names( x_duplicate_flag  OUT VARCHAR2 )
  IS
    l_first_name                per_people_f.first_name%TYPE;
    l_last_name                 per_people_f.last_name%TYPE;
    l_full_name                 per_people_f.full_name%TYPE;
    l_order_name                per_people_f.order_name%TYPE;
    l_global_name               per_people_f.GLOBAL_NAME%TYPE;
    l_local_name                per_people_f.local_name%TYPE;
  BEGIN
    FOR radi IN ( SELECT * FROM xx_adi WHERE ID = p_id AND status IN ('NEW','ERROR') ) LOOP
--        FOR rcur IN ( SELECT * FROM per_all_people_f WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(radi.email_address)) ) LOOP
        FOR rcur IN ( SELECT * FROM per_all_people_f WHERE TO_NUMBER(NVL(attribute2,'0')) = radi.worker_id ) LOOP
            l_first_name := LTRIM(RTRIM(SUBSTR(radi.full_name,INSTR(radi.full_name,',')+1)));
            l_last_name  := SUBSTR(radi.full_name,1,INSTR(radi.full_name,',')-1);
            -- Le paso como parametros los valores que pudieron haber cambiado (x.e., full_name).
            hr_person_name.derive_person_names  -- #3889584
                         ( p_format_name        =>  NULL    -- derive all names
                          ,p_business_group_id  =>  rcur.business_group_id    --l_business_group_id
                          ,p_person_id          =>  rcur.person_id
                          ,p_first_name         =>  l_first_name
                          ,p_middle_names       =>  rcur.middle_names
                          ,p_last_name          =>  l_last_name
                          ,p_known_as           =>  rcur.known_as
                          ,p_title              =>  rcur.title
                          ,p_suffix             =>  rcur.suffix
                          ,p_pre_name_adjunct   =>  rcur.pre_name_adjunct
                          ,p_date_of_birth      =>  radi.fh_nacim
                          ,p_previous_last_name =>  rcur.previous_last_name  
                          ,p_email_address      =>  radi.email_address  
                          ,p_employee_number    =>  radi.employee_num 
                          ,p_applicant_number   =>  rcur.applicant_number  
                          ,p_npw_number         =>  NULL --  :CTL.c_npw_number 
                          ,p_per_information1   =>  rcur.per_information1  
                          ,p_per_information2   =>  rcur.per_information2  
                          ,p_per_information3   =>  rcur.per_information3  
                          ,p_per_information4   =>  rcur.per_information4 
                          ,p_per_information5   =>  rcur.per_information5  
                          ,p_per_information6   =>  rcur.per_information6  
                          ,p_per_information7   =>  rcur.per_information7  
                          ,p_per_information8   =>  rcur.per_information8  
                          ,p_per_information9   =>  rcur.per_information9  
                          ,p_per_information10  =>  rcur.per_information10  
                          ,p_per_information11  =>  rcur.per_information11  
                          ,p_per_information12  =>  rcur.per_information12  
                          ,p_per_information13  =>  rcur.per_information13  
                          ,p_per_information14  =>  rcur.per_information14  
                          ,p_per_information15  =>  rcur.per_information15  
                          ,p_per_information16  =>  rcur.per_information16  
                          ,p_per_information17  =>  rcur.per_information17  
                          ,p_per_information18  =>  rcur.per_information18  
                          ,p_per_information19  =>  rcur.per_information19  
                          ,p_per_information20  =>  rcur.per_information20  
                          ,p_per_information21  =>  rcur.per_information21  
                          ,p_per_information22  =>  rcur.per_information22  
                          ,p_per_information23  =>  rcur.per_information23  
                          ,p_per_information24  =>  rcur.per_information24  
                          ,p_per_information25  =>  rcur.per_information25  
                          ,p_per_information26  =>  rcur.per_information26  
                          ,p_per_information27  =>  rcur.per_information27  
                          ,p_per_information28  =>  rcur.per_information28  
                          ,p_per_information29  =>  rcur.per_information29  
                          ,p_per_information30  =>  rcur.per_information30  
                          ,p_attribute1         =>  rcur.attribute1  
                          ,p_attribute2         =>  rcur.attribute2  
                          ,p_attribute3         =>  rcur.attribute3  
                          ,p_attribute4         =>  rcur.attribute4  
                          ,p_attribute5         =>  rcur.attribute5  
                          ,p_attribute6         =>  rcur.attribute6  
                          ,p_attribute7         =>  rcur.attribute7  
                          ,p_attribute8         =>  rcur.attribute8  
                          ,p_attribute9         =>  rcur.attribute9  
                          ,p_attribute10        =>  rcur.attribute10  
                          ,p_attribute11        =>  rcur.attribute11  
                          ,p_attribute12        =>  rcur.attribute12  
                          ,p_attribute13        =>  rcur.attribute13  
                          ,p_attribute14        =>  rcur.attribute14  
                          ,p_attribute15        =>  rcur.attribute15  
                          ,p_attribute16        =>  rcur.attribute16  
                          ,p_attribute17        =>  rcur.attribute17  
                          ,p_attribute18        =>  rcur.attribute18  
                          ,p_attribute19        =>  rcur.attribute19  
                          ,p_attribute20        =>  rcur.attribute20  
                          ,p_attribute21        =>  rcur.attribute21  
                          ,p_attribute22        =>  rcur.attribute22  
                          ,p_attribute23        =>  rcur.attribute23
                          ,p_attribute24        =>  rcur.attribute24
                          ,p_attribute25        =>  rcur.attribute25
                          ,p_attribute26        =>  rcur.attribute26
                          ,p_attribute27        =>  rcur.attribute27
                          ,p_attribute28        =>  rcur.attribute28
                          ,p_attribute29        =>  rcur.attribute29
                          ,p_attribute30        =>  rcur.attribute30
                          ,p_full_name          =>  l_full_name          --> out
                          ,p_order_name         =>  l_order_name         --> out
                          ,p_global_name        =>  l_global_name        --> out
                          ,p_local_name         =>  l_local_name         --> out
                          ,p_duplicate_flag     =>  x_duplicate_flag );  --> out
        END LOOP;
    END LOOP;
  END derive_person_names;
  --
  PROCEDURE raise_person_business_event( p_person_id IN NUMBER ) 
  IS
    l_ovn                   NUMBER;
    l_party_id              NUMBER;
    l_effective_date        DATE := SYSDATE;
    --
    CURSOR csr_get_per_ovn IS
           SELECT ppf.object_version_number, ppf.party_id
             FROM per_all_people_f ppf
            WHERE ppf.person_id = p_person_id
              AND l_effective_date BETWEEN ppf.effective_start_date AND ppf.effective_end_date;
  BEGIN
    FOR rcur IN (SELECT * FROM per_people_v7 WHERE person_id = p_person_id ) LOOP
        FOR rovn IN csr_get_per_ovn LOOP
            HR_PERSON_BUSINESS_EVENT.person_business_event
                                    ( P_EVENT                        => 'UPDATE'
                                     ,P_DATETRACK_UPDATE_MODE        => 'CORRECTION'
                                     ,P_SYSTEM_PERSON_TYPE           => rcur.SYSTEM_PERSON_TYPE
                                     ,P_EFFECTIVE_DATE               => l_effective_date
                                     ,P_LAST_NAME                    => rcur.LAST_NAME
                                     ,P_SEX                          => rcur.SEX
                                     ,P_PERSON_TYPE_ID               => rcur.PERSON_TYPE_ID
                                     ,P_COMMENTS                     => NULL
                                     ,P_DATE_EMPLOYEE_DATA_VERIFIED  => rcur.date_employee_data_verified
                                     ,P_DATE_OF_BIRTH                => rcur.DATE_OF_BIRTH
                                     ,P_EMAIL_ADDRESS                => rcur.EMAIL_ADDRESS
                                     ,P_APPLICANT_NUMBER             => rcur.APPLICANT_NUMBER
                                     ,P_EMPLOYEE_NUMBER              => rcur.EMPLOYEE_NUMBER
                                     ,P_NPW_NUMBER                   => NULL
                                     ,P_EXPENSE_CHECK_SEND_TO_ADDRES => rcur.EXPENSE_CHECK_SEND_TO_ADDRESS
                                     ,P_FIRST_NAME                   => rcur.FIRST_NAME
                                     ,P_KNOWN_AS                     => rcur.KNOWN_AS
                                     ,P_MARITAL_STATUS               => rcur.D_MARITAL_STATUS
                                     ,P_MIDDLE_NAMES                 => rcur.MIDDLE_NAMES
                                     ,P_NATIONALITY                  => rcur.D_NATIONALITY
                                     ,P_NATIONAL_IDENTIFIER          => rcur.NATIONAL_IDENTIFIER
                                     ,P_PREVIOUS_LAST_NAME           => rcur.PREVIOUS_LAST_NAME
                                     ,P_REGISTERED_DISABLED_FLAG     => rcur.REGISTERED_DISABLED_FLAG -- Changed from D_REGISTERED_DISABLED_FLAG is available
                                     ,P_TITLE                        => rcur.D_TITLE
                                     ,P_VENDOR_ID                    => rcur.VENDOR_ID
                                     ,P_ATTRIBUTE_CATEGORY           => rcur.ATTRIBUTE_CATEGORY
                                     ,P_ATTRIBUTE1                   => rcur.ATTRIBUTE1
                                     ,P_ATTRIBUTE2                   => rcur.ATTRIBUTE2
                                     ,P_ATTRIBUTE3                   => rcur.ATTRIBUTE3
                                     ,P_ATTRIBUTE4                   => rcur.ATTRIBUTE4
                                     ,P_ATTRIBUTE5                   => rcur.ATTRIBUTE5
                                     ,P_ATTRIBUTE6                   => rcur.ATTRIBUTE6
                                     ,P_ATTRIBUTE7                   => rcur.ATTRIBUTE7
                                     ,P_ATTRIBUTE8                   => rcur.ATTRIBUTE8
                                     ,P_ATTRIBUTE9                   => rcur.ATTRIBUTE9
                                     ,P_ATTRIBUTE10                  => rcur.ATTRIBUTE10
                                     ,P_ATTRIBUTE11                  => rcur.ATTRIBUTE11
                                     ,P_ATTRIBUTE12                  => rcur.ATTRIBUTE12
                                     ,P_ATTRIBUTE13                  => rcur.ATTRIBUTE13
                                     ,P_ATTRIBUTE14                  => rcur.ATTRIBUTE14
                                     ,P_ATTRIBUTE15                  => rcur.ATTRIBUTE15
                                     ,P_ATTRIBUTE16                  => rcur.ATTRIBUTE16
                                     ,P_ATTRIBUTE17                  => rcur.ATTRIBUTE17
                                     ,P_ATTRIBUTE18                  => rcur.ATTRIBUTE18
                                     ,P_ATTRIBUTE19                  => rcur.ATTRIBUTE19
                                     ,P_ATTRIBUTE20                  => rcur.ATTRIBUTE20
                                     ,P_ATTRIBUTE21                  => rcur.ATTRIBUTE21
                                     ,P_ATTRIBUTE22                  => rcur.ATTRIBUTE22
                                     ,P_ATTRIBUTE23                  => rcur.ATTRIBUTE23
                                     ,P_ATTRIBUTE24                  => rcur.ATTRIBUTE24
                                     ,P_ATTRIBUTE25                  => rcur.ATTRIBUTE25
                                     ,P_ATTRIBUTE26                  => rcur.ATTRIBUTE26
                                     ,P_ATTRIBUTE27                  => rcur.ATTRIBUTE27
                                     ,P_ATTRIBUTE28                  => rcur.ATTRIBUTE28
                                     ,P_ATTRIBUTE29                  => rcur.ATTRIBUTE29
                                     ,P_ATTRIBUTE30                  => rcur.ATTRIBUTE30
                                     ,P_PER_INFORMATION_CATEGORY     => rcur.PER_INFORMATION_CATEGORY
                                     ,P_PER_INFORMATION1             => rcur.PER_INFORMATION1
                                     ,P_PER_INFORMATION2             => rcur.PER_INFORMATION2
                                     ,P_PER_INFORMATION3             => rcur.PER_INFORMATION3
                                     ,P_PER_INFORMATION4             => rcur.PER_INFORMATION4
                                     ,P_PER_INFORMATION5             => rcur.PER_INFORMATION5
                                     ,P_PER_INFORMATION6             => rcur.PER_INFORMATION6
                                     ,P_PER_INFORMATION7             => rcur.PER_INFORMATION7
                                     ,P_PER_INFORMATION8             => rcur.PER_INFORMATION8
                                     ,P_PER_INFORMATION9             => rcur.PER_INFORMATION9
                                     ,P_PER_INFORMATION10            => rcur.PER_INFORMATION10
                                     ,P_PER_INFORMATION11            => rcur.PER_INFORMATION11
                                     ,P_PER_INFORMATION12            => rcur.PER_INFORMATION12
                                     ,P_PER_INFORMATION13            => rcur.PER_INFORMATION13
                                     ,P_PER_INFORMATION14            => rcur.PER_INFORMATION14
                                     ,P_PER_INFORMATION15            => rcur.PER_INFORMATION15
                                     ,P_PER_INFORMATION16            => rcur.PER_INFORMATION16
                                     ,P_PER_INFORMATION17            => rcur.PER_INFORMATION17
                                     ,P_PER_INFORMATION18            => rcur.PER_INFORMATION18
                                     ,P_PER_INFORMATION19            => rcur.PER_INFORMATION19
                                     ,P_PER_INFORMATION20            => rcur.PER_INFORMATION20
                                     ,P_PER_INFORMATION21            => rcur.PER_INFORMATION21
                                     ,P_PER_INFORMATION22            => rcur.PER_INFORMATION22
                                     ,P_PER_INFORMATION23            => rcur.PER_INFORMATION23
                                     ,P_PER_INFORMATION24            => rcur.PER_INFORMATION24
                                     ,P_PER_INFORMATION25            => rcur.PER_INFORMATION25
                                     ,P_PER_INFORMATION26            => rcur.PER_INFORMATION26
                                     ,P_PER_INFORMATION27            => rcur.PER_INFORMATION27
                                     ,P_PER_INFORMATION28            => rcur.PER_INFORMATION28
                                     ,P_PER_INFORMATION29            => rcur.PER_INFORMATION29
                                     ,P_PER_INFORMATION30            => rcur.PER_INFORMATION30
                                     ,P_DATE_OF_DEATH                => NULL
                                     ,p_hold_applicant_date_until    => NULL
                                     ,P_BACKGROUND_CHECK_STATUS      => NULL
                                     ,P_BACKGROUND_DATE_CHECK        => NULL
                                     ,P_BLOOD_TYPE                   => NULL
                                     ,P_CORRESPONDENCE_LANGUAGE      => NULL
                                     ,P_FAST_PATH_EMPLOYEE           => NULL
                                     ,P_FTE_CAPACITY                 => NULL
                                     ,P_HONORS                       => NULL
                                     ,P_INTERNAL_LOCATION            => NULL
                                     ,P_LAST_MEDICAL_TEST_BY         => NULL
                                     ,P_LAST_MEDICAL_TEST_DATE       => NULL
                                     ,P_MAILSTOP                     => NULL
                                     ,P_OFFICE_NUMBER                => NULL
                                     ,P_ON_MILITARY_SERVICE          => NULL
                                     ,P_PRE_NAME_ADJUNCT             => rcur.PRE_NAME_ADJUNCT
                                     ,P_REHIRE_REASON                => NULL
                                     ,p_rehire_authorizor            => NULL
                                     ,P_REHIRE_RECOMMENDATION        => NULL
                                     ,P_PROJECTED_START_DATE         => NULL
                                     ,P_RESUME_EXISTS                => NULL
                                     ,P_RESUME_LAST_UPDATED          => NULL
                                     ,P_SECOND_PASSPORT_EXISTS       => NULL
                                     ,P_STUDENT_STATUS               => NULL
                                     ,P_WORK_SCHEDULE                => NULL
                                     ,P_SUFFIX                       => rcur.SUFFIX
                                     ,P_BENEFIT_GROUP_ID             => NULL
                                     ,P_RECEIPT_OF_DEATH_CERT_DATE   => NULL
                                     ,P_COORD_BEN_MED_PLN_NO         => NULL
                                     ,P_COORD_BEN_NO_CVG_FLAG        => NULL
                                     ,P_COORD_BEN_MED_EXT_ER         => NULL
                                     ,P_COORD_BEN_MED_PL_NAME        => NULL
                                     ,P_COORD_BEN_MED_INSR_CRR_NAME  => NULL
                                     ,P_COORD_BEN_MED_INSR_CRR_IDENT => NULL
                                     ,P_COORD_BEN_MED_CVG_STRT_DT    => NULL
                                     ,P_COORD_BEN_MED_CVG_END_DT     => NULL
                                     ,P_USES_TOBACCO_FLAG            => NULL
                                     ,P_DPDNT_ADOPTION_DATE          => NULL
                                     ,P_DPDNT_VLNTRY_SVCE_FLAG       => NULL
                                     ,P_ORIGINAL_DATE_OF_HIRE        => NULL
                                     ,P_ADJUSTED_SVC_DATE            => NULL
                                     ,P_PERSON_ID                    => p_person_id
                                     ,P_EFFECTIVE_START_DATE         => rcur.EFFECTIVE_START_DATE
                                     ,P_EFFECTIVE_END_DATE           => rcur.EFFECTIVE_END_DATE
                                     ,P_FULL_NAME                    => rcur.FULL_NAME
                                     ,P_COMMENT_ID                   => NULL
                                     ,P_OBJECT_VERSION_NUMBER        => rovn.object_version_number
                                     ,P_TOWN_OF_BIRTH                => NULL
                                     ,P_REGION_OF_BIRTH              => NULL
                                     ,P_COUNTRY_OF_BIRTH             => NULL
                                     ,P_GLOBAL_PERSON_ID             => NULL
                                     ,P_PARTY_ID                     => rovn.party_id
                                     ,P_NAME_COMBINATION_WARNING     => NULL
                                     ,P_ASSIGN_PAYROLL_WARNING       => NULL
                                     ,P_ORIG_HIRE_WARNING            => NULL
                                     );
        END LOOP;
    END LOOP;
  END raise_person_business_event;  
  --
BEGIN
  print_log('+ '||l_procname);
--  print_log('  Va a buscar el current_appl_id (+)');
  BEGIN
    SELECT fr.data_group_application_id
      INTO l_current_appl_id
      FROM fnd_data_group_units dgu
          ,fnd_responsibility   fr
     WHERE fr.data_group_id = dgu.data_group_id
       AND fr.data_group_application_id = dgu.application_id
       AND fr.application_id = fnd_global.Resp_Appl_Id
       AND fr.responsibility_id = fnd_global.Resp_Id;
  EXCEPTION
    WHEN no_data_found THEN
         l_errmsg := 'NO se encontro el current_appl_id para la resp_id = '||fnd_global.resp_id||' y resp_appl_id = '||fnd_global.resp_appl_id;
         RAISE e_error;
    WHEN others THEN
         l_errmsg := 'ERROR al buscar el current_appl_id; '||SQLERRM;
         RAISE e_error;
  END;
--  print_log('  Va a buscar el current_appl_id (-)');
  print_log('  l_current_appl_id = '||l_current_appl_id);
  --  
  FOR radi IN (SELECT * FROM xx_adi WHERE ID = p_id AND status IN ('NEW','ERROR')) LOOP
      FOR rcur IN (SELECT * FROM per_people_v7 pp WHERE TO_NUMBER(NVL(pp.attribute2,'0')) = radi.worker_id ) LOOP
          -- =================================
          -- PRE-UPDATE PER_PEOPLE_F
          -- =================================
          l_full_name := rcur.full_name; -- keep old name to verify whether it has changed
          --------------------
          DERIVE_PERSON_NAMES( x_duplicate_flag  => l_duplicate_flag );
          --------------------
          print_log('  l_duplicate_flag = '||l_duplicate_flag);
          IF (l_full_name != radi.full_name OR l_full_name IS NULL) AND l_duplicate_flag = 'Y' THEN
             l_errmsg := 'Legajo duplicado - Proceso Cancelado';
             RAISE e_error;
          END IF;  
          --
          BEGIN
            hr_person.validate_unique_number( p_person_id         => rcur.person_id              --TO_NUMBER(name_in('PERSON.PERSON_ID'))
                                            , p_business_group_id => l_business_group_id         --TO_NUMBER(name_in('CTL_GLOBALS.BUSINESS_GROUP_ID'))
                                            , p_employee_number   => rcur.employee_number        --> OJO! ESTE VALOR NO LO CAMBIAMOS, NO TOMAMOS LO QUE VIENE DEL ADI  --name_in('PERSON.EMPLOYEE_NUMBER')
                                            , p_applicant_number  => rcur.applicant_number       --name_in('PERSON.APPLICANT_NUMBER')
                                            , p_npw_number        => NULL
                                            , p_current_employee  => rcur.current_employee_flag  --name_in('PERSON.CURRENT_EMPLOYEE_FLAG')
                                            , p_current_applicant => rcur.current_applicant_flag --name_in('PERSON.CURRENT_APPLICANT_FLAG')
                                            , p_current_npw       => NULL );
          EXCEPTION
            WHEN others THEN
                 l_errmsg := 'Error al ejecutar hr_person.validate_unique_number; '||SQLERRM;
                 RAISE e_error;
          END;
          --
          BEGIN
            SELECT assignment_id
              INTO l_assign_id
              FROM per_assignments_f
             WHERE person_id = rcur.person_id;
          EXCEPTION
            WHEN others THEN
                 l_assign_id := NULL;
          END;
          print_log('  l_assign_id = '||l_assign_id);
          --
          l_effective_end_date := rcur.effective_end_date;
          IF l_assign_id IS NOT NULL THEN
             IF rcur.d_termination_date IS NOT NULL THEN
                l_effective_end_date := rcur.d_termination_date;
             END IF;
          END IF;
          --
          -- =================================
          -- ON-UPDATE PER_PEOPLE_F (s_termination_date = rcur.termination_date; d_termination_date = radi.termination_date)
          -- =================================
          --
          -- ---------------------------------
          -- Update record as normal
          -- ---------------------------------
          print_log('  + PER_PEOPLE_V7_PKG.Update_Row');
          BEGIN
            l_first_name := LTRIM(RTRIM(SUBSTR(radi.full_name,INSTR(radi.full_name,',')+1)));
            l_last_name  := SUBSTR(radi.full_name,1,INSTR(radi.full_name,',')-1);
            l_fh_ingreso := TO_DATE(radi.fh_ingreso,'dd/mm/yyyy');
            l_fh_nacim   := TO_DATE(radi.fh_nacim,'dd/mm/yyyy');
            l_start_date := rcur.start_date;
            PER_PEOPLE_V7_PKG.Update_Row
                    ( X_Rowid                               => ROWIDTOCHAR(rcur.row_id)           -- VARCHAR2
                     ,X_Person_Id                           => rcur.person_id                     -- NUMBER
                     ,X_Effective_Start_Date                => l_fh_ingreso                       --> IN OUT NOCOPY DATE
                     ,X_Effective_End_Date                  => l_effective_end_date               --> IN OUT NOCOPY DATE
                     ,X_Business_Group_Id                   => rcur.business_group_id             -- NUMBER
                     ,X_Person_Type_Id                      => rcur.person_type_id                -- NUMBER
                     ,X_Last_Name                           => l_last_name                        -- VARCHAR2
                     ,X_Start_Date                          => l_start_date                       --> IN OUT NOCOPY DATE
                     ,X_Hire_date                           => l_fh_ingreso                       -- DATE
                     ,X_S_Hire_Date                         => rcur.hire_date                     -- DATE
                     ,X_Period_of_service_id                => rcur.period_of_service_id          -- NUMBER
                     ,X_Termination_Date                    => rcur.d_termination_date            -- DATE
                     ,X_S_Termination_Date                  => rcur.d_termination_date            -- DATE
                     ,X_Applicant_Number                    => rcur.applicant_number              -- VARCHAR2
                     ,X_Comment_Id                          => rcur.comment_id                    -- NUMBER
                     ,X_Current_Applicant_Flag              => rcur.current_applicant_flag        -- VARCHAR2
                     ,X_Current_Emp_Or_Apl_Flag             => rcur.current_emp_or_apl_flag       -- VARCHAR2
                     ,X_Current_Employee_Flag               => rcur.current_employee_flag         -- VARCHAR2
                     ,X_Date_Employee_Data_Verified         => rcur.date_employee_data_verified   -- DATE
                     ,X_Date_Of_Birth                       => TO_DATE(radi.fh_nacim,'dd/mm/yyyy')-- DATE
                     ,X_Email_Address                       => radi.email_address                 -- VARCHAR2
                     ,X_Employee_Number                     => rcur.employee_number               -- VARCHAR2  --> OJO! CON ESTE CAMPO: NO CAMBIARLO con lo que viene del ADI!!
                     ,X_Expense_Check_To_Address            => rcur.expense_check_send_to_address -- VARCHAR2
                     ,X_First_Name                          => l_first_name                       -- VARCHAR2
                     ,X_Full_Name                           => radi.full_name                     -- VARCHAR2
                     ,X_Known_As                            => rcur.known_as                      -- VARCHAR2
                     ,X_Marital_Status                      => rcur.marital_status                -- VARCHAR2
                     ,X_Middle_Names                        => rcur.middle_names                  -- VARCHAR2
                     ,X_Nationality                         => rcur.nationality                   -- VARCHAR2
                     ,X_National_Identifier                 => rcur.national_identifier           -- VARCHAR2
                     ,X_Previous_Last_Name                  => rcur.previous_last_name            -- VARCHAR2
                     ,X_Registered_Disabled_Flag            => rcur.registered_disabled_flag      -- VARCHAR2
                     ,X_Sex                                 => rcur.sex                           -- VARCHAR2
                     ,X_Title                               => rcur.title                         -- VARCHAR2
                     ,X_Vendor_Id                           => rcur.vendor_id                     -- NUMBER
                     ,X_Work_Telephone                      => rcur.work_telephone                -- VARCHAR2
                     ,X_Attribute_Category                  => rcur.attribute_category            -- VARCHAR2
                     ,X_Attribute1                          => rcur.attribute1                    -- VARCHAR2
                     ,X_Attribute2                          => TO_CHAR(radi.worker_id)            -- VARCHAR2
                     ,X_Attribute3                          => rcur.ATTRIBUTE3                    -- VARCHAR2
                     ,X_Attribute4                          => rcur.ATTRIBUTE4                    -- VARCHAR2
                     ,X_Attribute5                          => rcur.ATTRIBUTE5                    -- VARCHAR2
                     ,X_Attribute6                          => rcur.ATTRIBUTE6                    -- VARCHAR2
                     ,X_Attribute7                          => rcur.ATTRIBUTE7                    -- VARCHAR2
                     ,X_Attribute8                          => rcur.ATTRIBUTE8                    -- VARCHAR2
                     ,X_Attribute9                          => rcur.ATTRIBUTE9                    -- VARCHAR2
                     ,X_Attribute10                         => rcur.ATTRIBUTE10                   -- VARCHAR2
                     ,X_Attribute11                         => rcur.ATTRIBUTE11                   -- VARCHAR2
                     ,X_Attribute12                         => rcur.ATTRIBUTE12                   -- VARCHAR2
                     ,X_Attribute13                         => rcur.ATTRIBUTE13                   -- VARCHAR2
                     ,X_Attribute14                         => rcur.ATTRIBUTE14                   -- VARCHAR2
                     ,X_Attribute15                         => rcur.ATTRIBUTE15                   -- VARCHAR2
                     ,X_Attribute16                         => rcur.ATTRIBUTE16                   -- VARCHAR2
                     ,X_Attribute17                         => rcur.ATTRIBUTE17                   -- VARCHAR2
                     ,X_Attribute18                         => rcur.ATTRIBUTE18                   -- VARCHAR2
                     ,X_Attribute19                         => rcur.ATTRIBUTE19                   -- VARCHAR2
                     ,X_Attribute20                         => rcur.ATTRIBUTE20                   -- VARCHAR2
                     ,X_Attribute21                         => rcur.ATTRIBUTE21                   -- VARCHAR2
                     ,X_Attribute22                         => rcur.ATTRIBUTE22                   -- VARCHAR2
                     ,X_Attribute23                         => rcur.ATTRIBUTE23                   -- VARCHAR2
                     ,X_Attribute24                         => rcur.ATTRIBUTE24                   -- VARCHAR2
                     ,X_Attribute25                         => rcur.ATTRIBUTE25                   -- VARCHAR2
                     ,X_Attribute26                         => rcur.ATTRIBUTE26                   -- VARCHAR2
                     ,X_Attribute27                         => rcur.ATTRIBUTE27                   -- VARCHAR2
                     ,X_Attribute28                         => rcur.ATTRIBUTE28                   -- VARCHAR2
                     ,X_Attribute29                         => rcur.ATTRIBUTE29                   -- VARCHAR2
                     ,X_Attribute30                         => rcur.ATTRIBUTE30                   -- VARCHAR2
                     ,X_Per_Information_Category            => rcur.Per_Information_Category      -- VARCHAR2
                     ,X_Per_Information1                    => rcur.Per_Information1              -- VARCHAR2
                     ,X_Per_Information2                    => rcur.Per_Information2              -- VARCHAR2
                     ,X_Per_Information3                    => rcur.Per_Information3              -- VARCHAR2
                     ,X_Per_Information4                    => rcur.Per_Information4              -- VARCHAR2
                     ,X_Per_Information5                    => rcur.Per_Information5              -- VARCHAR2
                     ,X_Per_Information6                    => rcur.Per_Information6              -- VARCHAR2
                     ,X_Per_Information7                    => rcur.Per_Information7              -- VARCHAR2
                     ,X_Per_Information8                    => rcur.Per_Information8              -- VARCHAR2
                     ,X_Per_Information9                    => rcur.Per_Information9              -- VARCHAR2
                     ,X_Per_Information10                   => rcur.Per_Information10             -- VARCHAR2
                     ,X_Per_Information11                   => rcur.Per_Information11             -- VARCHAR2
                     ,X_Per_Information12                   => rcur.Per_Information12             -- VARCHAR2
                     ,X_Per_Information13                   => rcur.Per_Information13             -- VARCHAR2
                     ,X_Per_Information14                   => rcur.Per_Information14             -- VARCHAR2
                     ,X_Per_Information15                   => rcur.Per_Information15             -- VARCHAR2
                     ,X_Per_Information16                   => rcur.Per_Information16             -- VARCHAR2
                     ,X_Per_Information17                   => rcur.Per_Information17             -- VARCHAR2
                     ,X_Per_Information18                   => rcur.Per_Information18             -- VARCHAR2
                     ,X_Per_Information19                   => rcur.Per_Information19             -- VARCHAR2
                     ,X_Per_Information20                   => rcur.Per_Information20             -- VARCHAR2
                     ,X_Per_Information21                   => rcur.Per_Information21             -- VARCHAR2
                     ,X_Per_Information22                   => rcur.Per_Information22             -- VARCHAR2
                     ,X_Per_Information23                   => rcur.Per_Information23             -- VARCHAR2
                     ,X_Per_Information24                   => rcur.Per_Information24             -- VARCHAR2
                     ,X_Per_Information25                   => rcur.Per_Information25             -- VARCHAR2
                     ,X_Per_Information26                   => rcur.Per_Information26             -- VARCHAR2
                     ,X_Per_Information27                   => rcur.Per_Information27             -- VARCHAR2
                     ,X_Per_Information28                   => rcur.Per_Information28             -- VARCHAR2
                     ,X_Per_Information29                   => rcur.Per_Information29             -- VARCHAR2
                     ,X_Per_Information30                   => rcur.Per_Information30             -- VARCHAR2
                     ,X_Last_Update_Date                    => SYSDATE                            -- DATE
                     ,X_Last_Updated_By                     => fnd_global.user_id                 -- NUMBER
                     ,X_Last_Update_Login                   => fnd_global.login_id                -- NUMBER
                     ,X_Current_Application_Id              => fnd_global.resp_appl_id            -- NUMBER
                     ,X_Order_Name                          => rcur.order_name                    -- VARCHAR2
                     ,X_Global_Name                         => rcur.GLOBAL_NAME                   -- VARCHAR2
                     ,X_Local_Name                          => rcur.local_name                    -- VARCHAR2
                    );
          EXCEPTION
            WHEN others THEN
                 l_errmsg := 'ERROR al ejecutar PER_PEOPLE_V7_PKG.Update_Row; '||SQLERRM;
                 RAISE e_error;
          END;
          print_log('  - PER_PEOPLE_V7_PKG.Update_Row');
          --
          -- =================================
          -- POST-UPDATE PER_PEOPLE_F
          -- =================================
          RAISE_PERSON_BUSINESS_EVENT( p_person_id => rcur.person_id );
          --
      END LOOP;
  END LOOP;
  print_log('- '||l_procname);
EXCEPTION
  WHEN e_error THEN
       print_log(l_errmsg);
       x_errmsg := l_errmsg;
  WHEN others THEN
       l_errmsg := NVL(l_errmsg,'')||' ERROR General en '||l_procname||'; '||SQLERRM;
       print_log(l_errmsg);
       x_errmsg := l_errmsg;              
END Update_Employee;

--/******************************************************************************\
-- Name   : Process_User
-- Purpose: Crea al usuario en la fnd_user.
-- Params : p_id: es el ID de la tabla XX_ADI que se debe procesar.
-- Notes  : 
-- History: 05/10/2018  DVartabedian  Created
--
--\******************************************************************************/
PROCEDURE process_user( p_id       IN NUMBER
                       ,x_errmsg  OUT VARCHAR2 )
IS
  l_procname            VARCHAR2(70) := c_procname||'.PROCESS_USER';
  l_existe              VARCHAR2(1);
  l_fh_ingreso          DATE;
  l_fh_baja             DATE;
  l_person_id           per_all_people_f.person_id%TYPE;
  l_user_name           fnd_user.user_name%TYPE;
  l_user_id             fnd_user.user_id%TYPE;
  l_creation_date       DATE;
  l_email_address       fnd_user.email_address%TYPE;
  l_errmsg              VARCHAR2(2000);  
  l_unencrypted_pwd     VARCHAR2(30);
  l_resp_name           fnd_responsibility_vl.responsibility_name%TYPE;
  l_resp_key            fnd_responsibility_vl.responsibility_key%TYPE;
  l_app_short_name      fnd_application.application_short_name%TYPE;
  e_error               EXCEPTION;
  --
  -- Genera una clave dinamica, confidencial y unica.
  FUNCTION key_generate RETURN VARCHAR2
  IS
    l_return           VARCHAR2(30);
  BEGIN
    SELECT w1||w2||w3||w4||w5||w6||w7||w8||w9 pwd
      INTO l_return
      FROM ( SELECT CHR(48+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'dd')),10))    w1
                   ,CHR(65+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'ss')),26))    w2
                   ,CHR(97+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'ssss')),26))  w3
                   ,CHR(48+MOD(USERENV('sessionid'),10))                w4
                   ,CHR(65+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'hh24')),26))  w5
                   ,CHR(97+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'mi')),26))    w6
                   ,CHR(48+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'sssss')),10)) w7
                   ,CHR(65+MOD(TO_NUMBER(TO_CHAR(SYSDATE,'sssss')),26)) w8
                   ,CHR(97+MOD(USERENV('sessionid'),26))                w9
               FROM dual );
    RETURN( l_return );
  EXCEPTION
    WHEN OTHERS THEN
         l_return := 'INVALID';
         RETURN( l_return );
  END key_generate;
BEGIN
  print_log('+ '||l_procname);
  FOR radi IN (SELECT * FROM xx_adi WHERE ID = p_id) LOOP
      -- ----------------------------------------------------------------------------------------------
      -- Si el email cambio, es posible que me intente crear un nuevo user_name a partir del mail.
      -- Para evitar eso, primero me fijo si el user_name existe (relacionandolo por el employee_id).
      -- Ademas, puede ser que ya este de baja, entonces no modifico nada; pero si es fecha de baja
      -- posdatada, entonces puede ser que tenga que darle la baja (no hay otra modificacion en el user.
      -- ----------------------------------------------------------------------------------------------
      BEGIN
        SELECT user_id, employee_id, user_name, end_date, TRUNC(creation_date), email_address
          INTO l_user_id, l_person_id, l_user_name, l_fh_baja, l_creation_date, l_email_address
          FROM fnd_user
         WHERE employee_id = radi.person_id
        UNION
        SELECT user_id, employee_id, user_name, end_date, TRUNC(creation_date), email_address
          FROM fnd_user
         WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(radi.email_address));
        --
        print_log('  Usuario Existente: User_Id   = '||l_user_id);
        print_log('                     User_Name = '||l_user_name);
        print_log('                     Person_Id = '||NVL(l_person_id,0));
        print_log('                     End_Date  = '||TO_CHAR(l_fh_baja,'dd/mm/yyyy'));
        print_log('                     Creation_Date = '||TO_CHAR(l_creation_date,'dd/mm/yyyy'));
        print_log('                     Email_Address = '||l_email_address);
        l_existe := 'Y';
      EXCEPTION
        WHEN no_data_found THEN
             l_existe := 'N';
             l_person_id := radi.person_id;
             l_user_name := UPPER(LTRIM(RTRIM(SUBSTR(radi.email_address,1,(INSTR(radi.email_address,'@')-1)))));
             l_fh_baja   := TO_DATE(radi.fh_baja,'dd/mm/yyyy');
             l_email_address := radi.email_address;
             print_log('  Usuario Inexistente: User_Name (a dar de Alta): '||l_user_name);
        WHEN others THEN
             x_errmsg := 'ERROR al buscar el User_Name; '||SQLERRM;
             RAISE e_error;
      END;
      -- -----------------------------------------------------------------------------------------------------
      -- Si existe y esta de baja, verifico si la fecha de baja es posdatada: en este caso podria modificar esa fecha por otra.
      -- -----------------------------------------------------------------------------------------------------
      IF l_existe = 'Y' THEN 
         IF l_fh_baja > TRUNC(SYSDATE) THEN
            BEGIN
              SELECT user_id
                INTO l_user_id
                FROM fnd_user
               WHERE user_name = l_user_name 
                 AND employee_id = l_person_id --> agrego esto por si es un nuevo user_name y por ahi esta referenciando a otro usuario existente (caso, MPEREZ y MAPEREZ).
                 AND NOT EXISTS (SELECT 1
                                   FROM fnd_lookup_values_vl 
                                  WHERE lookup_type = 'XX_RESERVED_USERS'
                                    AND lookup_code = l_user_name
                                    AND enabled_flag = 'Y'
                                    AND NVL(end_date_active,SYSDATE) >= TRUNC(SYSDATE) );
            EXCEPTION
              WHEN no_data_found THEN
                   l_user_id := 0;
              WHEN others THEN
                   x_errmsg := 'ERROR al buscar el User_Id; '||SQLERRM;
                   RAISE e_error;
            END;
            --
            IF l_user_id > 0 THEN
               l_fh_baja := TO_DATE(radi.fh_baja,'dd/mm/yyyy');  --> se supone que al ser dato obligatorio para tercerizados, siempre viene (esta validado el formato en main).
               -- ------------------------------------------------------------------------------------------------
               -- Baja del Usuario (puede ser con fecha post datada, lo cual hace que el usuario sea transitorio o con fecha limite).
               -- ------------------------------------------------------------------------------------------------
               print_log('  + Baja del Usuario; fecha_baja = '||l_fh_baja);
               IF radi.email_address = l_email_address THEN
                  fnd_user_pkg.UpdateUser( x_user_name     => l_user_name
                                          ,x_owner         => NULL
                                          ,x_end_date      => l_fh_baja );
               ELSE
                  fnd_user_pkg.UpdateUser( x_user_name     => l_user_name
                                          ,x_owner         => NULL
                                          ,x_email_address => l_email_address
                                          ,x_end_date      => l_fh_baja );
               END IF;
               print_log('  - Baja del Usuario');
               --
               BEGIN
                 UPDATE xx_adi
                    SET status = 'PROC'
                       ,status_user = 'PROC'
                       ,operation_user = 'B'
                       ,user_id = l_user_id
                  WHERE ID = p_id;
                 -------
                 COMMIT;
                 -------
               EXCEPTION
                 WHEN others THEN
                      x_errmsg := 'ERROR al grabar xx_adi; Id = '||p_id||'; '||SQLERRM;
                      RAISE e_error;
               END;
            END IF;
         ELSE
            IF l_fh_baja = l_creation_date THEN
               print_log('  Esta de baja por proceso; no es una baja real sino un usuario que nunca se habilito');
               IF radi.email_address = l_email_address THEN
                  IF radi.fh_baja IS NOT NULL THEN
                     print_log('  + Actualiza Fh Baja; old = '||TO_CHAR(l_fh_baja,'dd/mm/yyyy'));
                     fnd_user_pkg.UpdateUser( x_user_name     => l_user_name
                                             ,x_owner         => NULL
                                             ,x_end_date      => TO_DATE(radi.fh_baja,'dd/mm/yyyy') );
                     print_log('  - Actualiza Fh Baja; new = '||radi.fh_baja);
                  END IF;
               ELSE
                  print_log('  + Actualiza email;  old = '||l_email_address);
                  fnd_user_pkg.UpdateUser( x_user_name     => l_user_name
                                          ,x_owner         => NULL
                                          ,x_email_address => radi.email_address
                                          ,x_end_date      => l_fh_baja );
                  print_log('  - Actualiza email; new = '||radi.email_address);
               END IF;
            ELSE
               IF l_fh_baja IS NULL THEN
                  NULL; --> no hace nada.
               ELSE
                  -- Si la fecha de baja < trunc(sysdate), entonces es una baja real => no toco nada.
                  print_log('  Usuario dado de baja; no se modifica');
               END IF;
            END IF;
            --
            BEGIN
              UPDATE xx_adi
                 SET status_user = 'PROC'
                    ,operation_user = 'M'
                    ,user_id = l_user_id
               WHERE ID = p_id;
              -------
              COMMIT;
              -------
            EXCEPTION
              WHEN others THEN
                   x_errmsg := 'ERROR al grabar xx_adi; Id = '||p_id||'; '||SQLERRM;
                   RAISE e_error;
            END;
         END IF;
      --
      -- Si el usuario no existe en ebs.
      ELSIF l_existe = 'N' THEN
        -- --------------------------
        -- Alta del Usuario.
        -- --------------------------
        IF l_user_id IS NOT NULL THEN
           x_errmsg  := 'El usuario '||l_user_name||' ya existe; user_id = '||l_user_id;
           -- Grabo xx_adi.
           BEGIN
             UPDATE xx_adi
                SET status_user = 'ERROR'
                   ,operation_user = 'A'
                   ,user_id = l_user_id
                   ,errmsg = x_errmsg
              WHERE ID = p_id;
             -------
             COMMIT;
             -------
           EXCEPTION
             WHEN others THEN
                  x_errmsg := 'ERROR al grabar xx_adi; Id = '||p_id||'; '||SQLERRM;
                  RAISE e_error;
           END;
        ELSE
           --
           -- Hay algun problema con el valor de xx_adi.person_id (tiene valor cero); por eso vuelvo a hacer la busqueda del person_id.
           BEGIN
             SELECT person_id
               INTO l_person_id
               FROM per_all_people_f
              WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(radi.email_address));
           EXCEPTION
             WHEN no_data_found THEN
                  l_person_id := NULL;
             WHEN others THEN
                  x_errmsg := 'ERROR al buscar el person_id; '||SQLERRM;
           END;
           IF NVL(radi.person_id,0) > 0 THEN
              l_person_id := radi.person_id; --> si existe el radi.person_id, le doy prioridad.
           END IF;
           --
           BEGIN
             l_unencrypted_pwd := key_generate;
--             l_unencrypted_pwd := 'despegar123';  -- clave debil
             l_fh_ingreso := TO_DATE(radi.fh_ingreso,'dd/mm/yyyy');
             l_fh_baja := TO_DATE(radi.fh_baja,'dd/mm/yyyy');  --> se supone que al ser dato obligatorio para tercerizados, siempre viene (esta validado el formato en main).
             IF NVL(l_fh_baja,TRUNC(SYSDATE)) <= TRUNC(SYSDATE) THEN
                l_fh_baja := TRUNC(SYSDATE);
             END IF;
             --
             print_log('  + Alta del Usuario');
             fnd_user_pkg.CreateUser ( x_user_name              => l_user_name
                                      ,x_owner                  => NULL
                                      ,x_unencrypted_password   => l_unencrypted_pwd
                                      ,x_start_date             => l_fh_ingreso -- SYSDATE
                                      ,x_end_date               => l_fh_baja    -- nace con fecha de baja
                                      ,x_description            => NULL
                                      ,x_password_lifespan_days => 60
                                      ,x_employee_id            => l_person_id
                                      ,x_email_address          => radi.email_address );
             print_log('  - Alta del Usuario');
           EXCEPTION
             WHEN OTHERS THEN
                  x_errmsg := 'ERROR al generar el Usuario '||l_user_name||'; '||REPLACE(SQLERRM,CHR(10),'; ');
                  RAISE e_error;
           END;
           -- Compruebo su creacion.
           BEGIN
             SELECT user_id
               INTO l_user_id
               FROM fnd_user
              WHERE user_name = l_user_name;
             print_log('  l_user_id = '||l_user_id);
           EXCEPTION
             WHEN OTHERS THEN
                  x_errmsg :=  'NO se pudo crear el Usuario '||l_user_name||'; '||REPLACE(SQLERRM,CHR(10),'; ');
                  RAISE e_error;
           END;     
           -- Grabo xx_adi.
           BEGIN
             UPDATE xx_adi
                SET status_user = 'PROC'
                   ,operation_user = 'A'
                   ,user_id = l_user_id
              WHERE ID = p_id;
             -------
             COMMIT;
             -------
           EXCEPTION
             WHEN others THEN
                  x_errmsg := 'ERROR al grabar xx_adi; Id = '||p_id||'; '||SQLERRM;
                  RAISE e_error;
           END;
        END IF;
      END IF;
      print_log('+ '||l_procname);
  END LOOP;
  print_log('- '||l_procname);
EXCEPTION
  WHEN e_error THEN
       x_errmsg := NVL(x_errmsg,'ERROR en Process_User; '||SQLERRM);
       UPDATE xx_adi
          SET status_user = 'ERROR'
             ,errmsg = x_errmsg
        WHERE ID = p_id;
       -------
       COMMIT;
       -------        
       print_log(x_errmsg);
  WHEN others THEN
       x_errmsg := NVL(x_errmsg,'ERROR en Process_User; '||SQLERRM);
       UPDATE xx_adi
          SET status_user = 'ERROR'
             ,errmsg = x_errmsg
        WHERE ID = p_id;
       -------
       COMMIT;
       -------        
       print_log(x_errmsg);
END process_user;
  
-- ---------------------------------------------------------------------------
-- Function: Get_Supervisor_Id
-- Purpose : Obtener el Person_Id de un Supervisor.
-- Params  : p_superv_email: email del Supervisor informado en planilla ADI.
--
-- ---------------------------------------------------------------------------
FUNCTION get_supervisor_id( p_superv_email  IN VARCHAR2
                           ,x_errmsg       OUT VARCHAR2 ) RETURN NUMBER
IS
  l_procname             VARCHAR2(70) := c_procname||'.GET_SUPERVISOR_ID';
  l_supervisor_id        per_people_f.person_id%TYPE;
BEGIN
  print_log('+ '||l_procname);
  BEGIN
    SELECT pp.person_id
      INTO l_supervisor_id
      FROM per_all_people_f pp
     WHERE LOWER(TRIM(email_address)) = LOWER(TRIM(p_superv_email))
       AND UPPER(pp.full_name) NOT LIKE 'FONDO%FIJO%'
       AND UPPER(pp.full_name) NOT LIKE 'FUNDO%FIXO%';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
         x_errmsg := 'NO se encontro el Supervisor; eMail del Supervisor = '||p_superv_email;
         RETURN( TO_NUMBER(NULL) );
    WHEN OTHERS THEN
         x_errmsg := 'ERROR al buscar el Supervisor_Id; eMail del Supervisor = '||p_superv_email||'; '||SQLERRM;
         RETURN( TO_NUMBER(NULL) );
  END;
  print_log('- '||l_procname||'; l_supervisor_id = '||l_supervisor_id);  
  RETURN( l_supervisor_id );
END get_supervisor_id;

FUNCTION get_new_concatenated_segment (p_new_acc   IN VARCHAR2
                                      ,p_conc_seg  IN VARCHAR2) RETURN VARCHAR2
IS

l_input_array          FND_FLEX_EXT.SegmentArray;
l_chart_of_acc_id      gl_sets_of_books.chart_of_accounts_id%TYPE;
l_delimiter            VARCHAR2(1);
l_number_of_segments   NUMBER;
l_output_combination   VARCHAR2(200);

BEGIN

  BEGIN
    SELECT gls.chart_of_accounts_id
      INTO l_chart_of_acc_id
      FROM gl_ledgers               gl
          ,gl_code_combinations     gcc_ret
          ,fnd_flex_values_vl       ffv
          ,gl_sets_of_books gls
     WHERE gls.set_of_books_id = gl.ledger_id
       AND ffv.flex_value = SUBSTR(p_conc_seg,1,3)
       AND ffv.flex_value_set_id = gl.bal_seg_value_set_id
       AND gcc_ret.code_combination_id = gl.ret_earn_code_combination_id
       AND gl.object_type_code = 'L'
       AND NVL(gl.complete_flag, 'Y') = 'Y'
       AND gcc_ret.segment1 = SUBSTR(p_conc_seg,1,3)
       AND INSTR(gl.NAME,'CORP') > 0
       AND ffv.enabled_flag = 'Y';

  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  l_delimiter := fnd_flex_ext.get_delimiter(
                     application_short_name  => 'SQLGL' ,
                     key_flex_code           => 'GL#' ,
                     structure_number        => l_chart_of_acc_id);

  l_number_of_segments:= FND_FLEX_EXT.breakup_segments(concatenated_segs => p_conc_seg
                                                      ,delimiter         => l_delimiter
                                                      ,segments          => l_input_array);

  l_input_array(2) := '69999';

  l_output_combination := FND_FLEX_EXT.concatenate_segments(l_number_of_segments,l_input_array,l_delimiter);

  RETURN l_output_combination;

EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END get_new_concatenated_segment;

FUNCTION get_ccid( p_concatenated_segments  IN VARCHAR2
                  ,x_errmsg                OUT VARCHAR2 ) RETURN NUMBER
IS
  l_procname              VARCHAR2(70) := c_procname||'.GET_CCID';
  l_ccid                  gl_code_combinations.code_combination_id%TYPE;
  l_chart_of_accounts_id  gl_ledgers.chart_of_accounts_id%TYPE;
  l_sob_id                gl_ledgers.ledger_id%TYPE;
  l_errmsg                VARCHAR2(2000);
  l_exc_coa               EXCEPTION;
  l_exc_api               EXCEPTION;
BEGIN
  print_log('+ '||l_procname);
  --
  l_sob_id := get_sob_id( p_adi                  => p_concatenated_segments
                         ,x_chart_of_accounts_id => l_chart_of_accounts_id
                         ,x_errmsg               => l_errmsg );
  IF l_errmsg IS NOT NULL THEN
     RAISE l_exc_coa;
  END IF;
  --
  l_ccid := fnd_flex_ext.get_ccid( 'SQLGL'
                                  ,'GL#'
                                  ,l_chart_of_accounts_id
                                  ,TO_CHAR (SYSDATE, 'YYYY/MM/DD HH24:MI:SS')
                                  ,p_concatenated_segments );
  IF l_ccid = 0 THEN
     -- Si el CCID no existe, entonces lo crea.
     IF NOT FND_FLEX_KEYVAL.VALIDATE_SEGS( 'CREATE_COMBINATION'
                                          ,'SQLGL'
                                          ,'GL#'
                                          ,l_chart_of_accounts_id
                                          ,p_concatenated_segments
                                          ,'V'
                                          ,SYSDATE
                                          ,'ALL', NULL, NULL, NULL, NULL
                                          ,FALSE, FALSE, NULL, NULL, NULL) THEN
        l_errmsg := fnd_flex_keyval.error_message;
        IF l_errmsg IS NOT NULL THEN
           RAISE l_exc_api;
        END IF;
        --
        l_ccid := fnd_flex_ext.get_ccid( 'SQLGL'
                                ,'GL#'
                                ,l_chart_of_accounts_id
                                ,TO_CHAR (SYSDATE, 'YYYY/MM/DD HH24:MI:SS')
                                ,p_concatenated_segments );
     END IF;
  END IF;
  --
  RETURN( l_ccid );
EXCEPTION
  WHEN NO_DATA_FOUND THEN
       x_errmsg := 'NO se encontro la cuenta '||p_concatenated_segments;
       RETURN( TO_NUMBER(NULL) );
  WHEN l_exc_coa THEN
       x_errmsg := 'ERROR obteniendo el chart_of_accounts_id|'||l_procname||'|concatenated_segments = '||p_concatenated_segments||'|'||REPLACE(SQLERRM,CHR(10),'; ');
       RETURN( TO_NUMBER(NULL) );
  WHEN l_exc_api THEN
       x_errmsg := 'ERROR al crear el CCID|'||l_procname||'|concatenated_segments = '||p_concatenated_segments||'|l_chart_of_accounts_id|'||l_chart_of_accounts_id||'|'||l_errmsg;
       RETURN( TO_NUMBER(NULL) );
  WHEN OTHERS THEN
       x_errmsg := 'ERROR al buscar el CCID|'||l_procname||'|concatenated_segments = '||p_concatenated_segments||'|'||REPLACE(SQLERRM,CHR(10),'; ');
       RETURN( TO_NUMBER(NULL) );
END get_ccid;

FUNCTION get_sob_id( p_adi                   IN VARCHAR2
                    ,x_chart_of_accounts_id OUT NUMBER
                    ,x_errmsg               OUT VARCHAR2 ) RETURN NUMBER
IS
  l_procname                  VARCHAR2(70) := c_procname||'.GET_SOB_ID';
  l_set_of_books_id           gl_ledgers.ledger_id%TYPE;
  l_segment1                  VARCHAR2(3) := SUBSTR(p_adi,1,3);
BEGIN
  --
  -- Agrego el fsp para que traiga solamente los paises configurados.
  SELECT gl.chart_of_accounts_id, gl.ledger_id
    INTO x_chart_of_accounts_id, l_set_of_books_id
    FROM gl_ledgers                   gl
        ,financials_system_params_all fsp
        ,gl_code_combinations         gcc_ret
        ,fnd_flex_values_vl           ffv
   WHERE 1=1
     AND ffv.flex_value = l_segment1
     AND ffv.flex_value_set_id = gl.bal_seg_value_set_id
     AND gcc_ret.code_combination_id = gl.ret_earn_code_combination_id
     AND gl.object_type_code = 'L'
     AND NVL(gl.complete_flag, 'Y') = 'Y'
     AND gcc_ret.segment1 = l_segment1
     AND INSTR(gl.NAME,'CORP') > 0
     AND ffv.enabled_flag = 'Y'
     AND gl.ledger_id = fsp.set_of_books_id;
  --
  RETURN( l_set_of_books_id );
EXCEPTION
  WHEN NO_DATA_FOUND THEN
       x_errmsg := 'NO esta configurado el sob_id para el adi = '||p_adi;
       RETURN( TO_NUMBER(NULL) );
  WHEN TOO_MANY_ROWS THEN
       x_errmsg := 'Se encontraron demasiados valores DEL sob_id para el adi = '||p_adi;
       RETURN( TO_NUMBER(NULL) );
  WHEN OTHERS THEN
       x_errmsg := 'ERROR al buscar el sob_id para el adi = '||p_adi||'; '||REPLACE(SQLERRM,CHR(10),'; ');
       RETURN( TO_NUMBER(NULL) );
END get_sob_id;

PROCEDURE enable_debug( p_type IN VARCHAR2 DEFAULT 'LOG' )
IS
BEGIN
  g_debug := 'Y';
  IF g_debug_type IS NULL THEN --> si se setea desde afuera, no debe cambiar el valor de g_debug_type.
     IF    p_type IS NULL THEN
           g_debug_type := 'LOG';
     ELSIF UPPER(p_type) IN ('OUT','LOG') THEN
           g_debug_type := UPPER(p_type);
     ELSE
           g_debug_type := 'LOG';
     END IF;
     print_log('DEBUG Habilitado tipo '||g_debug_type);
  END IF;
END enable_debug;

PROCEDURE disable_debug
IS
BEGIN
  g_debug := 'N';
  g_debug_type := NULL;
  Fnd_File.CLOSE;
END disable_debug;

PROCEDURE print_log( p_msg IN VARCHAR2 )
IS
BEGIN
  IF g_debug = 'Y' THEN
     IF g_debug_type = 'LOG' THEN
        Fnd_File.put_line(Fnd_File.LOG, p_msg);
     ELSIF g_debug_type = 'OUT' THEN
        DBMS_OUTPUT.PUT_LINE(p_msg);
     END IF;
  END IF;
END print_log;

PROCEDURE print_out( p_msg IN VARCHAR2 )
IS
BEGIN
  IF g_debug = 'Y' THEN
     IF g_debug_type = 'LOG' THEN
        Fnd_File.put_line(Fnd_File.output, p_msg);
     ELSIF g_debug_type = 'OUT' THEN
        DBMS_OUTPUT.PUT_LINE(p_msg);
     END IF;
  END IF;
END print_out;

END xx_idm_pkg;
/

SHOW ERRORS

SPOOL OFF

EXIT
