SPOOL xx_idms_pk.log

PROMPT =====================================================================
PROMPT Script xx_idms_pk.sql - Spec de package xx_idm_pkg
PROMPT =====================================================================

CREATE OR REPLACE PACKAGE APPS.xx_idm_pkg AS
/* $Id: XX_IDM_PKG.sql 1 2018-08-09 12:07:11Z seguridad informatica $ */
-- -------------------------------------------------------------------
-- 
----------------------------------------------------------------------

-- -------------------------------------------------------------------
-- CONSTANTS y GLOBALS.
-- -------------------------------------------------------------------
c_procname               CONSTANT VARCHAR2(30) := 'XX_IDM_PKG';
c_location               CONSTANT VARCHAR2(30) := 'ECX_UTL_LOG_DIR_OBJ';
g_debug                           VARCHAR2(1)  := 'N';
g_debug_type                      VARCHAR2(3)  := 'OUT';
g_expense_account        CONSTANT NUMBER       := 69999;
g_idm_user_name          CONSTANT VARCHAR2(30) := 'IDM';
g_resp_adm_personal      CONSTANT VARCHAR2(30) := 'DSP Administrador de Personal';

-- -------------------------------------------------------------------
-- FUNCTIONS PROCS.
-- -------------------------------------------------------------------
PROCEDURE sod_matrix( p_email_address  IN VARCHAR2
                     ,p_appl_name      IN VARCHAR2
                     ,p_role_name      IN DATE
                     ,x_errmsg        OUT VARCHAR2 );
                     
PROCEDURE main_employees( p_worker_id             IN NUMBER
                         ,p_employee_num          IN VARCHAR2
                         ,p_full_name             IN VARCHAR2
                         ,p_email_address         IN VARCHAR2
                         ,p_country               IN VARCHAR2
                         ,p_fh_nacim              IN VARCHAR2
                         ,p_fh_ingreso            IN VARCHAR2
                         ,p_fh_baja               IN VARCHAR2
                         ,p_depto                 IN VARCHAR2 DEFAULT NULL
                         ,p_puesto                IN VARCHAR2 DEFAULT NULL
                         ,p_superv_email          IN VARCHAR2
                         ,p_adi                   IN VARCHAR2
                         ,x_errmsg               OUT VARCHAR2 );
               
PROCEDURE add_resp( p_email_address  IN VARCHAR2
                   ,p_resp_name      IN VARCHAR2
                   ,p_end_date       IN DATE     DEFAULT NULL
                   ,x_errmsg        OUT VARCHAR2 );
                   
PROCEDURE del_resp( p_email_address  IN VARCHAR2
                   ,p_resp_name      IN VARCHAR2
                   ,x_errmsg        OUT VARCHAR2 );                                  
               
PROCEDURE process_employee( p_id       IN NUMBER
                           ,x_errmsg  OUT VARCHAR2 );
                           
FUNCTION get_new_concatenated_segment (p_new_acc   IN VARCHAR2
                                      ,p_conc_seg  IN VARCHAR2) RETURN VARCHAR2;                           

FUNCTION get_sob_id( p_adi                   IN VARCHAR2
                    ,x_chart_of_accounts_id OUT NUMBER
                    ,x_errmsg               OUT VARCHAR2 ) RETURN NUMBER;

FUNCTION get_ccid( p_concatenated_segments  IN VARCHAR2
                  ,x_errmsg                OUT VARCHAR2 ) RETURN NUMBER;

--
--FUNCTION get_sob_id( p_adi        IN VARCHAR2
--                    ,x_sob_name  OUT VARCHAR2
--                    ,x_errmsg    OUT VARCHAR2 ) RETURN NUMBER;


PROCEDURE insert_employee( p_id         IN NUMBER
                          ,x_person_id OUT NUMBER
                          ,x_assign_id OUT NUMBER
--                          ,x_user_id   OUT NUMBER
                          ,x_errmsg    OUT VARCHAR2);

PROCEDURE update_employee( p_id         IN NUMBER
                          ,x_errmsg    OUT VARCHAR2);

PROCEDURE process_user( p_id       IN NUMBER
                       ,x_errmsg  OUT VARCHAR2 );

FUNCTION get_supervisor_id( p_superv_email IN VARCHAR2
                           ,x_errmsg      OUT VARCHAR2 ) RETURN NUMBER;

PROCEDURE initialize( x_errmsg  OUT VARCHAR2 );

PROCEDURE enable_debug( p_type IN VARCHAR2 DEFAULT 'LOG' );
PROCEDURE disable_debug;
--PROCEDURE show_debug( p_msg IN VARCHAR2 );
PROCEDURE print_log( p_msg IN VARCHAR2 );
PROCEDURE print_out( p_msg IN VARCHAR2 );

END xx_idm_pkg;
/

SHOW ERRORS

SPOOL OFF

EXIT
